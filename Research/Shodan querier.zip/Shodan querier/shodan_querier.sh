#!/bin/bash
#
# shodan_querier.sh
#
# Automates the scanning of a given port on zmap and running the resulting IP addresses on shodan
#
# usage: ./shodan_querier.sh port

if [ $# -ne 1 ]; then
  echo error!
  exit 1
fi

echo "about to run"
sudo zmap -B 10M -p $1 -n 10000 -o results.csv

wc results.csv > temp
read lines words characters filename < temp
rm temp

for i in `seq 1 $lines`;
do
  sed "${i}q;d" results.csv > temp
  read ip < temp
  rm temp
  python ./shodan_intro.py $ip
done
