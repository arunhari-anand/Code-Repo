import shodan
import sys

SHODAN_API_KEY = "s5UCQeY5UNYZHpqWXgQp5h5pqROx15TN"

api = shodan.Shodan(SHODAN_API_KEY)

if len(sys.argv) != 2:
    print "invalid number of arguments"

else:
    # Lookup the host
    host = api.host(sys.argv[1])

    # Print general info
    print """
            IP: %s
            Organization: %s
            Operating System: %s
    """ % (host['ip_str'], host.get('org', 'n/a'), host.get('os', 'n/a'))

    # Print all banners
    for item in host['data']:
            print """
                    Port: %s
                    Banner: %s

            """ % (item['port'], item['data'])
