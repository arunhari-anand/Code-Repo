# CS50 Tiny Search Engine

Arun Hari Anand - Summer 2017

To build, run `make`.

To clean up, run `make clean`.

The CS50 playground is in
http://old-www.cs.dartmouth.edu/~cs50/data/tse

Currently supports the crawler and indexer modules.

Overview:
* Crawler - crawls through webpages at a specified depth starting from a seed url
* Indexer - indexes the crawls and produces an index file that contains information about
the frequency of each word in each document of the crawl.