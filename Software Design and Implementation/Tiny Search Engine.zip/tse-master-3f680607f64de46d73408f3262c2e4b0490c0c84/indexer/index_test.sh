#!/bin/bash

echo "Testing indexer on previously made crawler directories"
echo "Making index files and sorting them"
./indexer ../crawler/test1 index1
./indexer ../crawler/test2 index2
./indexer ../crawler/test3 index3
sort index1 > index1s
sort index2 > index2s
sort index3 > index3s
echo "Running indextest on the index files and sorting them"
./indextest index1 index1_test
./indextest index2 index2_test
./indextest index3 index3_test
sort index1_test > index1_tests
sort index2_test > index2_tests
sort index3_test > index3_tests
echo "Printing differences between the two files: "
diff -s index1s index1_tests
diff -s index2s index2_tests
diff -s index3s index3_tests

echo "Testing error cases: "
echo "Testing invalid number of arguments"
./indexer 1 2 3
echo "Testing invalid directory"
./indexer ../crawler/dummy index4
echo "Testing a directory that is not crawler produced"
./indexer ../crawler index4
