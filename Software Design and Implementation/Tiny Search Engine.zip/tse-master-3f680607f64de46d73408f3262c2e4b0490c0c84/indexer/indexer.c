/*
* indexer.c - implements the indexer for the TSE application
* 
* Reads a crawler-produced directory and creates an index for the crawl
* 
* Arun Anand, August 2017
* Written using class materials provided by Prof. Zhou
* 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <dirent.h>
#include <math.h>
#include <stdbool.h>
#include "hashtable.h"
#include "counters.h"
#include "pagedir.h"
#include "index.h"

/*
* a method that is used by index_delete to delete the individual countersets
* 
* where:
* item is the counterset in question
*/
void counter_deleter(void *item);

/*
* main method for the indexer.
* validates comman-line parameters, calls index_build for each file in the crawler-produced
* directory, and calls index_save to produce the index file
*/
int main (int argc, char *argv[])
{
  if (argc != 3){
    fprintf(stderr, "Invalid number of arguments!\n");
    return 1;
  }

  char *pageDir = malloc(sizeof(char) * (strlen(argv[1])+1));
  if (pageDir == NULL){
    fprintf(stderr, "Error allocating memory!");
    exit(4);
  }
  if (sscanf (argv[1], "%s", pageDir) != 1){ //testing valid pageDir
    fprintf(stderr, "Invalid page directory!\n");
    free(pageDir);
    return 2;
  }
  if (!isCrawlerDirectory(pageDir)){
    fprintf(stderr, "Invalid page directory - not a crawler produced directory!\n");
    free(pageDir);
    return 2;
  }

  char *indexFilename = malloc(sizeof(char) * (strlen(argv[2])+1));

  if (indexFilename == NULL){
    fprintf(stderr, "Error allocating memory!");
    free(pageDir);
    exit(4);
  }
  
  if (sscanf (argv[2], "%s", indexFilename) != 1){ //testing valid indexFilename
    fprintf(stderr, "Invalid index file name!\n");
    free(pageDir);
    free(indexFilename);
    return 3;
  }
  
  index_t *ind = index_new(400); //the index data structure
  if (ind == NULL){
    fprintf(stderr, "Error allocating memory!");
    free(pageDir);
    free(indexFilename);
    exit(4);
  }
  int id = 1;

  //rotates through every crawler produced file and calls index_build
  for (FILE *fp = loadFile(id, pageDir); fp != NULL; ){
  index_build(ind, fp, id);
  FILE *fp_old = fp;
  fclose(fp_old);
  fp = loadFile(++id, pageDir);
  }

  index_save(indexFilename, ind); //saves the index to the index file

  free(pageDir);
  free(indexFilename);
  index_delete(ind, counter_deleter);
}

/*
* a method that is used by index_delete to delete the individual countersets
* 
* where:
* item is the counterset in question
*/
void counter_deleter(void *item)
{
  counters_t *toDelete = (counters_t *) item;
  counters_delete(toDelete);
}
