# CS50 Lab 5
## Arun Hari Anand, CS50 August 2017
## Written using class materials provided by Prof. Zhou

### indexer.c and indextest.c

*indexer* reads a crawler-produced directory and creates an index for the crawl.
It checks ever crawler-produced file it encounters and adds every word in the file (that is longer than 3 letters) to an inverted index data structure.
Once all the files are read and the data structure is fully built, an index file is produced.
This index file contains a line per word encountered, along with a set of document id and word count pairs for ever document where the word is encountered.

*indextest* reads an index file, produced by the indexer, and reads it into an inverted index data structure. It then calls `index_save` in the index module to save the new index strcture into a new index file. 

### User Interface
The *indexer* has only one interface with the user: the command-line. It must always have three arguments. An example run is as follows:
`./indexer pageDir indexFilename`

The *indextest* also run solely from the commandline, and must always have two arguments. An example run is as follows:
`./indextest oldIndexFilename newIndexFilename`

### Inputs and Outputs
The only inputs are the command line parameters. 
The output for indexer is an index file that contains one line for all of the words in the crawled webpages, with a set of [document_id count] pairs for each document that contains the word.
The output for indextest is also a new index file that is formatted like the original index file.

### Functional Decomposition into Modules
We implement the following functions within indexer and the index module:
`index_build` which takes a crawler-produced file and updates the inverted index data structure with all the words in the file.
`index_save` which takes an inverted index data structure and produced an index file as specified above.
`index_load` which takes an index file name and produces a corresponding inverted index data structure.

We also use some helper modules, including *pagedir*, *hashtable*, and *counters*.

### Pseudocode for Logic/Algorithmic Flow
The indexer will run as follows:
1. Execute from command line as shown in the user interface.
2. Parse the command line, validate the parameters and initialize the index module.
3. Loop through the files in the crawler directory provided, and for each file, call *index_build* to update the index structure.
4. Use *index_save* to save the index to the index file under the name provided.
5. Clean up.

Indextest will run as follows:
1. Execute from the commandline
2. Parse the commandline, and validate the number of arguments.
3. Use `index_load` to load the old index file into an inverted index.
4. Pass this index into `index_save` to save it into a new index file.

### Data Flow Through Modules

Indexer:
1. *main* parses the paramters and passes each file in the crawler directory to *index_build*.
2. Once all the files are visited, the index will contain all the words in every file in the directory.
3. The index is then passed to *index_save* to save.

Indextest:
1. main parses the parameters and calls `index_load`
2. `index_load` passes a pointer to the inverted index data structure.
3. This pointer is then passed to the function `index_save`.

### Major Data Structures
*index.c* provides the inverted index data structure, consisting of a hashtable that holds char pointers (the words) as its keys and countersets as its
items.

### Testing Plan
The module *indextest* was written in order to help test the indexer. *Indextest* was written with the help of the `index_load` function from the *index.c*
module. It uses this function to read an index file and parse it into an inverted index data structure. `index_save` is then used to save the index into an index file. 
In order to test the indexer, we will use a set of crawler outputs on a number of different seed URLs at different depths. We will then use a shellscript to attempt to call the indexer on each of these crawls, and test the outputs to see if they match the inputs. We will then use indextest to see whether the new index file exactly matches the old, as a means of testing whether `index_save` works as intended. Then, some error cases will be tested to see whether the indexer handles these cases gracefully.
