/*
 * indextest.c - a program written to test the indexer
 *
 * Reads an index file, puts the index into an index data strcuture, and then transfers the resulting index
 * data structure into a new index file
 *
 * Written using class materials provided by Prof. Zhou
 * Arun Anand, August 2017
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <dirent.h>
#include <math.h>
#include <stdbool.h>
#include "hashtable.h"
#include "counters.h"
#include "pagedir.h"
#include "index.h"


/*
* a method that is used by index_delete to delete the individual countersets
* 
* where:
* item is the counterset in question
*/
void counter_deleter (void *item);
hashtable_t *parseOldIndex(char *oldIndexFilename, hashtable_t index);

/*
* Main method for indextest.c
* Validates its command line parameters, and then calls index_load and index_save
*/
int main (int argc, char *argv[])
{
  if (argc != 3){
    fprintf(stderr, "Invalid number of arguments!\n");
    return 1;
  }

  char *oldIndexFilename = malloc(sizeof(char) * (strlen(argv[1])+1));
  if (oldIndexFilename == NULL){
    fprintf(stderr, "Error allocating memory!");
    exit(4);
  }
  if (sscanf (argv[1], "%s", oldIndexFilename) != 1){ //testing valid dirname
    fprintf(stderr, "Invalid old index filename!\n");
    free(oldIndexFilename);
    return 2;
  }

  char *newIndexFilename = malloc(sizeof(char) * (strlen(argv[2])+1));
  if (newIndexFilename == NULL){
    fprintf(stderr, "Error allocating memory!");
    free(oldIndexFilename);
    exit(4);
  }
  if (sscanf (argv[2], "%s", newIndexFilename) != 1){ //testing valid dirname
    fprintf(stderr, "Invalid index file name!\n");
    free(oldIndexFilename);
    free(newIndexFilename);
    return 3;
  }


  
  index_t *ind = index_load(oldIndexFilename);
  index_save(newIndexFilename, ind);

  free(oldIndexFilename);
  free(newIndexFilename);
  index_delete(ind, counter_deleter);
  return 0;
}

/*
* a method that is used by index_delete to delete the individual countersets
* 
* where:
* item is the counterset in question
*/
void counter_deleter (void *item)
{
  counters_t *ct = (counters_t *) item;
  counters_delete(ct);
}


