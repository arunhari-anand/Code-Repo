# CS50 Lab 5
## Arun Hari Anand, CS50 August 2017

### indexer.c

*indexer* reads a crawler-produced directory and creates an index for the crawl.
It checks ever crawler-produced file it encounters and adds every word in the file (that is longer than 3 letters) to an inverted index data structure.
Once all the files are read and the data structure is fully built, an index file is produced.
This index file contains a line per word encountered, along with a set of document id and word count pairs for ever document where the word is encountered.

*indextest* reads an index file, produced by the indexer, and reads it into an inverted index data structure. It then calls `index_save` in the index module to save the new index strcture into a new index file. 

### DETAILS - INDEXER
Most of the work in indexer is taken care of by an external common module called *index.c*. This module contains the `index_build` and `index_save` functions, which build the inverted index data structure from a crawler file and save this index into an index file respectively. 

Within the indexer, however, there is a loop that uses a function called `loadFile` from a module *pagedir.c* to rotate through each file in the crawler-produced directory and update the inverted index structure. After this loop, we call index_save to save the index to the specified index file.

The function summaries for the index methods and the methods within indexer are provided below.

### FUNCTION SUMMARY - INDEXER

#### `counter_deleter(void *item)`
A method that is used by index_delete to delete the individual countersets 
parameters: *item* is the counterset in question.

#### `main`
Validates command-line arguments, calls index_build for each file in the crawler-produced directory, and calls index_save to produce the index file.

#### `index_build(index_t *ind, FILE *fp, int id)`
This is a function that builds the index data strcuture from a specific file that has been produced by crawler.
parameters:
*ind* is the data structure.
*fp* is the file pointer to the *crawler* file in question.

#### `index_save (char *indexFilename, index_t *ind)`
Saves the index data strcuture to a file with the name indexFilename.
Parameters:
*indexFilename* is the name of the new index file.
*ind* is the data strcuture.

### DETAILS - INDEXTEST
Most of the work in *indextest* is taken care of by the external common module *index.c*. This module contains the `index_load` function, which builds the inverted index data structure from a crawler file. `index_save` is used to save this index into an index file. 

Within indextest, however, there is a main method that validates its parameters (to ensure that the right number of arguments are given - no more validation is performed beyond this) and passes the arguments to `index_load` and `index_save`.

### FUNCTION SUMMARY - INDEXTEST

#### `index_load(char *oldIndexFilename)`
Loads the index from oldIndexfilename into an inverted index data structure and returns a pointer to it.


