# CS50 Lab 5
## Arun Anand, CS50 Summer 2017

### Testing 'indexer'

In order to test *indexer*, the  shellscript *index_test* was written. It
is described below and shows all of the test cases, categorized by the specific
situation being tested.

We first make crawler directories for the indexer to operate on. Three URLS from the wikipedia playground were chosen and these were
crawled at depth 1 in order to produce three separate crawler directories. Then, the bash script calls the indexer on each of these
directories. Each of the three resulting index files were then sorted. Then indextest is called to generate three new index files that 
are generated based on the three indexer-produced index files. These three new file are then sorted, and all three sets of files are
compared to ensure that the formatting of the index files works as intended. As shown in test.out, all three sets of files were shown to be identical.

The three index files are then examined to ensure that the content of the index file are accurate.

We then run valgrind on the indexer and indextest to ensure that there are no memory leaks.

The terminal output is presented in *test.out* and *test.error*. The files were checked to ensure that indexer
works as intended. 

In order to run the test script, simply `./index_test.sh`