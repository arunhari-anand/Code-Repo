/*
 * crawler.c - implements a crawler for the Tiny Search Engine
 *
 * The crawler takes a seed URL and a depth, and crawls through the relevant webpages.
 * It then collects information about these webpages and stores this information in a specified directory
 *
 * Written using class materials provided by Prof. Zhou (such as libcs50.a)
 * Arun Anand, July 2017
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <dirent.h>
#include <math.h>
#include <stdbool.h>
#include "bag.h"
#include "hashtable.h"
#include "webpage.h"

static int id = 0; //a static global variable to keep track of the document ids
static int pos = 0; //keeps track of the position from which urls should be extracted from a webpage
static bool testing = true; //a variable that prints out information useful for testing

/*
* A method that takes as its parameters a bag containing all the webpages to be
* crawled, a hashtable containing all the urls seen thus far, the max depth of
* the crawl and the directory at which the pages must be saved. When it is finished,
* the pageDirectory will be filled with files (each named with a unique doc_id) that
* hold information related to each internal, normalizable url that is explored by
* the crawler. Returns the exit code.
*
* webpages - a bag that stores all the webpages to explore. Should contain a webpage
* that holds the seed url
*
* urls_seen - a hashtable that holds all the urls encountered thus far as its keys.
* Should contain the seed url.
*
* max_depth - the maximum depth of the crawl
*
* dirname - pageDirectory, where the webpages will be stored
*
* Returns exit code for crawler.c. Returns 0 if success, and 5 if any problems are
* encountered
*/
static int crawler (bag_t *webpages, hashtable_t *urls_seen, int max_depth, char *dirname);

/*
* A method that takes a webpage as its parameter and returns a string that holds
* all of the html content of the webpage passed.
*
* page - the webpage in question
*/
static char *pagefetcher (webpage_t *page);

/*
* returns the next url that is embedded within a webpage. It takes as its parameters
* a reference to the webpage and a boolean representing whether this is a new page
* that has just been encountered.
*
* page is the webpage in question
* new_page is a boolean that is true iff there has not been an attempt to extract
* a url from this page previously.
*/
static char *pagescanner (webpage_t *page, bool new_page);

/*
* Saves a file in pageDirectory that holds information about the webpage including
* the url, the depth of the webpage in the crawl, and the html content. The file
* is saved with a unique document id that starts with 1 for the seed url and
* proceeds sequentially henceforth.
*
* content - the html content of the webpage
* page - the webpage in question
* dirname - pageDirectory, where the files need to be stored
*/
static void pagesaver(char *content, webpage_t *page, char *dirname);


/*
* The main method for crawler.c
* receives three command line arguments - namely seed_url, pageDirectory and
* max_Depth. The method validates all parameters, initializes a bag and hashtable
* to be used in the crawl, and passes all of these to the crawler method.
*/
int main (int argc, char *argv[]){
  if (argc != 4){ //testing incorrect number of arguments
    fprintf(stderr, "Incorrect number of arguments!\n");
    return 1;
  }

  char *seed_url = malloc(sizeof(char) * (strlen(argv[1])+1));
  if (seed_url == NULL){
    fprintf(stderr, "Error allocating memory!");
    exit(6);
  }
  if (sscanf (argv[1], "%s", seed_url) != 1){ //testing valid seed url
    fprintf(stderr, "Invalid seed url!\n");
    free(seed_url);
    return 2;
  }

  char *dirname = malloc(sizeof(char) * (strlen(argv[2])+1));
  if (dirname == NULL){
    fprintf(stderr, "Error allocating memory!");
    exit(6);
  }
  if (sscanf (argv[2], "%s", dirname) != 1){ //testing valid dirname
    fprintf(stderr, "Invalid directory name!\n");
    return 3;
  }

  char filename[strlen(dirname)+10];
  strcpy(filename, dirname);
  strcat(filename, "/.crawler" );
  FILE *cr;
  if ((cr = fopen(filename, "w")) == NULL){ //testing that pageDir exists and is writable
    fprintf(stderr, "The directory does not exist or is not writable!\n");
    return 3;
  }
  fclose(cr);


  int max_depth;
  if (sscanf (argv[3], "%d", &max_depth) != 1){ //testing valid max_depth
    fprintf(stderr, "Invalid max depth!\n");
    return 4;
  }

  //initializing modules
  bag_t *webpages = bag_new();
  hashtable_t *urls_seen = hashtable_new(10);
  webpage_t *seed_page = webpage_new(seed_url, 0, NULL);
  if (seed_page == NULL){
    fprintf(stderr, "Invalid seed URL!\n");
    return 2;
  }

  //inserting relevant elements into the modules
  int arb = 1;
  bag_insert(webpages, seed_page);
  hashtable_insert(urls_seen, seed_url, &arb);

  if (testing){
    printf("%s is the seed url\n%s is the dirname\n%d is the maxdepth\n", seed_url, dirname, max_depth);
  }
  int ret = crawler (webpages, urls_seen, max_depth, dirname);

  //cleanup: delete modules and free memory
  hashtable_delete(urls_seen, NULL);
  bag_delete(webpages, webpage_delete);
  free(dirname);
  free(seed_url);
  return ret;
}

/*
* A method that takes as its parameters a bag containing all the webpages to be
* crawled, a hashtable containing all the urls seen thus far, the max depth of
* the crawl and the directory at which the pages must be saved. When it is finished,
* the pageDirectory will be filled with files (each named with a unique doc_id) that
* hold information related to each internal, normalizable url that is explored by
* the crawler. Returns the exit code.
*
* webpages - a bag that stores all the webpages to explore. Should contain a webpage
* that holds the seed url
*
* urls_seen - a hashtable that holds all the urls encountered thus far as its keys.
* Should contain the seed url.
*
* max_depth - the maximum depth of the crawl
*
* dirname - pageDirectory, where the webpages will be stored
*
* Returns exit code for crawler.c. Returns 0 if success, and 5 if any problems are
* encountered
*/
static int crawler (bag_t *webpages, hashtable_t *urls_seen, int max_depth, char *dirname)
{

  int ret = 0; //returns 0 by default

  //continue extracting webpages until the bag is empty
  for (webpage_t *next_page = bag_extract(webpages); next_page != NULL; ){
    if (testing){
      printf("Currently exploring URL: %s\n", webpage_getURL(next_page));
    }

    char *content = pagefetcher(next_page);
    if (content == NULL){
      fprintf(stderr, "Error fetching HTML content!\n");
      ret = 5;
    }
    else{
      pagesaver(content, next_page, dirname);
      int depth = webpage_getDepth(next_page);
      if (depth < max_depth){
        for (char *next_url = pagescanner(next_page, true); next_url != NULL; ){
          if (testing){
            printf("\tFound URL %s\n", next_url);
          }
          if (!NormalizeURL(next_url)){
            fprintf (stderr, "Error normalizing a URL!\n");
            ret = 5;
          }
          else{
            int arb = 1;
            if (IsInternalURL(next_url) && hashtable_insert(urls_seen, next_url, &arb)){
              webpage_t *to_be_added = webpage_new(next_url, depth+1, NULL);
              if (to_be_added != NULL){
                bag_insert(webpages, to_be_added);
              }
              else{
                fprintf(stderr, "Invalid URL found!\n");
                return 5;
              }
            }
          }
          //free the old url and extract the next url embedded in the page
          char *old_url = next_url;
          next_url = pagescanner(next_page, false);
          free(old_url);
        }
      }
    }
    //free the old webpage and extract the next webpage from the bag
    webpage_t *old_page = next_page;
    next_page = bag_extract(webpages);
    webpage_delete(old_page);
  }
  return ret;
}

/*
* A method that takes a webpage as its parameter and returns a string that holds
* all of the html content of the webpage passed.
*
* page - the webpage in question
*/
static char *pagefetcher (webpage_t *page)
{
  if (webpage_fetch(page)){
    return webpage_getHTML(page);
  }
  else{
    return NULL;
  }
}

/*
* returns the next url that is embedded within a webpage. It takes as its parameters
* a reference to the webpage and a boolean representing whether this is a new page
* that has just been encountered.
*
* page is the webpage in question
* new_page is a boolean that is true iff there has not been an attempt to extract
* a url from this page previously.
*/
static char *pagescanner (webpage_t *page, bool new_page)
{
  char *result;
  if (new_page){ //if no url has been extracted from the page yet, reset pos to 0;
    pos = 0;
  }
  if ((pos = webpage_getNextURL(page, pos, &result)) > 0) {
    char *ret = malloc((strlen(result)+1)*sizeof(char));
    if (ret == NULL){
      fprintf(stderr, "Error allocating memory!");
      exit(6);
    }
    strcpy(ret, result);
    free(result);
    return ret;
  }
  return NULL;
}

/*
* Saves a file in pageDirectory that holds information about the webpage including
* the url, the depth of the webpage in the crawl, and the html content. The file
* is saved with a unique document id that starts with 1 for the seed url and
* proceeds sequentially henceforth.
*
* content - the html content of the webpage
* page - the webpage in question
* dirname - pageDirectory, where the files need to be stored
*/
static void pagesaver(char *content, webpage_t *page, char *dirname)
{

  id++;
  //We add three because we have to account for the nullcharacter, the slash and the fact
  //that log10 rounds down.
  int filename_maxlength = strlen(dirname)+log10(id)+3;

  char *filename = malloc(filename_maxlength * sizeof(char));
  char *doc_id= malloc(filename_maxlength * sizeof(char));
  if (filename == NULL || doc_id == NULL){
    fprintf(stderr, "Error allocating memory!");
    exit(6);
  }
  sprintf(doc_id, "%d", id);
  //printf ("%d", id);
  strcpy(filename, dirname);
  strcat(filename, "/");
  strcat(filename, doc_id);
  FILE *fp = fopen(filename, "w");
  fprintf(fp, "%s\n", webpage_getURL(page));
  fprintf(fp, "%d\n", webpage_getDepth(page));
  fprintf(fp, "%s", content);
  fclose(fp);
  free(filename);
  free(doc_id);
}
