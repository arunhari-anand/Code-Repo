#!/bin/bash

echo "Testing invalid uses of crawler"
echo "Testing incorrect number of arguments"
./crawler
echo "Testing invalid URL"
./crawler bad bad 2
echo "Testing invalid directory"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/ bad 2
echo "Testing invalid depth"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/ ./data/ bad

echo "Testing non existent server"
./crawler http://old-www.cs.dart.edu/~cs50/data/tse/letters/ ./data/ 2

echo "Testing a non-internal server"
./crawler http://bwa.dartmouth.edu ./data/ 2

echo "Testing a non-existent page in a valid server"
./crawler http://old-www.cs.dartmouth.edu/~cs50/bad/tse/letters/ ./data/ 2

echo "Testing in a site with cycles"
echo "Max_Depth = 0"
./crawler ./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/ ./data/test1depth2 2 ./data/test1depth0 0

echo "Max_Depth = 1"
./crawler ./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/ ./data/test1depth2 2 ./data/test1depth1 1

echo "Max_Depth = 2"
./crawler ./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/ ./data/test1depth2 2 ./data/test1depth2 2

echo "Max_Depth = 3"
./crawler ./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/ ./data/test1depth2 2 ./data/test1depth3 3

echo "Max_Depth = 4"
./crawler ./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/ ./data/test1depth2 2 ./data/test1depth4 4

echo "Max_Depth = 5"
./crawler ./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/ ./data/test1depth2 2 ./data/test1depth5 5

echo "Testing in the same site starting with a different seed"

echo "Max_Depth = 0"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/B.html ./data/test2depth0 0

echo "Max_Depth = 1"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/B.html ./data/test2depth1 1

echo "Max_Depth = 2"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/B.html ./data/test2depth2 2

echo "Max_Depth = 3"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/B.html ./data/test2depth03 3

echo "Max_Depth = 4"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/B.html ./data/test2depth4 4

echo "Max_Depth = 5"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/B.html ./data/test2depth5 5

echo "Testing on Wikipedia playground at depth = 0"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/wikipedia/ ./data/testwiki0 0

echo "Testing on Wikipedia playground at depth = 1"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/wikipedia/ ./data/testwiki1 1

echo "Testing on Wikipedia playground at depth = 2"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/wikipedia/ ./data/testwiki2 2

echo "Testing on Wikipedia playground from a different seed at depth =2"
./crawler http://old-www.cs.dartmouth.edu/~cs50/data/tse/wikipedia/wiki/Dartmouth_College.html ./data/test2wiki 2
