# CS50 Lab 3
## Arun Anand, CS50 Summer 2017

### Testing 'crawler'

In order to test *crawler*, the  shellscript *testing_crawler.sh* was written. It
is described below and shows all of the test cases, categorized by the specific
situation being tested.

First we test all the error cases. We first attempt to run the program without any
parameters, and then we attempt to run the program with invalid parameters. We then
test a non-internal server, a non-existent server and a non-existent page in a valid
server. We then use the url <http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/>
to test for a seed url that has cycles and repeats the same url multiple times
in the same page. We test this at depths 0, 1, 2, 3, 4, and 5. We then test another page
in the same cycle at depths 0, 1, 2, 3, 4, 5. Then we test the crawler with two seed urls
from the wikipedia playground at depths 0, 1 and 2.

We then run valgrind on the url <http://old-www.cs.dartmouth.edu/~cs50/data/tse/letters/>
to confirm that there are no memory leaks.

Print statements were also inserted in crawler to track the progress of the crawler.
The terminal output is presented in `test.out`. The files were checked to ensure that crawler
works as intended. A sample output from a file in the first wikipedia test run at
depth 2 is also presented in test.out.
