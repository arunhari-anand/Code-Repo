# CS50 Lab 4
## Arun Hari Anand, CS50 Summer 2017

### crawler.c

*crawler* crawls through a set of webpages given a seed URL, a pageDirectory and a maximum depth.
It checks every internal, normalizable url it encounters and explores them if they fall within the
maximum depth.
It saves every webpage it encounters (in pageDirectory) with a unique document id, and
specifies the url, depth of the webpage in the crawl, and the html content of the webpage

### Usage
`./crawler seed_url pageDirectory max_depth`

### Implementation

See [IMPLEMENTATION](Implementation.md)

### EXIT CODES

0 - no errors
1 - invalid number of arguments
2 - invalid *seed_url*
3 - invalid *pageDirectory*
4 - invalid *max_depth*
5 - function `crawler` encountered an error in *webpage.c*
6 - error allocating memory

### Assumptions

Assumptions beyond those that are clear from the spec:

The *pageDirectory* must end with a slash, so as to make sure that `pagesaver` stores
the webpages in the appropriate directory. Additionally, pageDirectory should be empty.

### Compilation

To compile, simply `make clean; make all`

See [TESTING](TESTING.md) for details of testing and an example test run.
