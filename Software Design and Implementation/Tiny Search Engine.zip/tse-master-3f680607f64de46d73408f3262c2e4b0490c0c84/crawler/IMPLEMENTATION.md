# CS50 Lab 4
## Arun Hari Anand, CS50 Summer 2017

### crawler.c

*Crawler* crawls through a set of webpages given a seed URL, a pageDirectory and a maximum depth.
It checks every internal, normalizable url it encounters and explores them if they fall within the
maximum depth.
It saves every webpage it encounters (in pageDirectory) with a unique document id, and
specifies the url, depth of the webpage in the crawl, and the html content of the webpage

#### DETAILS

*crawler* operates by first putting a seed webpage in a bag *webpages* and the seed url
in the hashtable *urls_seen*. Then, for every webpage in the bag pagescanner is
used to get all the embedded urls within the webpage - these are all added to *urls_seen*
and *webpages* if they are internal and normalizable. Then the webpage is saved using pagesaver.



#### FUNCTION SUMMARY

`main`
The main method for crawler.c
receives three command line arguments - namely *seed_url*, *pageDirectory* and
*max_Depth*. The method validates all parameters, initializes a bag and hashtable
to be used in the crawl, and passes all of these to the crawler method.

`crawler`
A method that takes as its parameters a bag containing all the webpages to be
crawled, a hashtable containing all the urls seen thus far, the max depth of
the crawl and the directory at which the pages must be saved. When it is finished,
the pageDirectory will be filled with files (each named with a unique doc_id) that
hold information related to each internal, normalizable url that is explored by
the crawler. Returns the exit code.

parameters:
*webpages* - a bag that stores all the webpages to explore. Should contain a webpage
that holds the seed url
*urls_seen* - a hashtable that holds all the urls encountered thus far as its keys.
Should contain the seed url.
*max_depth* - the maximum depth of the crawl
*dirname* - pageDirectory, where the webpages will be stored
Returns exit code for crawler.c. Returns 0 if success, and 5 if any problems are
encountered

`pagefetcher`
A method that takes a webpage as its parameter and returns a string that holds
all of the html content of the webpage passed.

parameters:
page - the webpage in question

`pagescanner`

Returns the next url that is embedded within a webpage. It takes as its parameters
a reference to the webpage and a boolean representing whether this is a new page
that has just been encountered.

parameters
*page* - the webpage in question
*new_page* - a boolean that is true iff there has not been an attempt to extract
a url from this page previously.

`pagesaver`
Saves a file in pageDirectory that holds information about the webpage including
the url, the depth of the webpage in the crawl, and the html content. The file
is saved with a unique document id that starts with 1 for the seed url and
proceeds sequentially henceforth.

parameters
*content* - the html content of the webpage
*page* - the webpage in question
*dirname* - pageDirectory, where the files need to be stored
