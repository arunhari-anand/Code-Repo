# Tips for the Tiny Search Engine project.

Please follow the [CS50 coding style guidelines](http://www.cs.dartmouth.edu/~cs50/Resources/CodingStyle.html)

Read the [Crawler Requirements Spec](http://www.cs.dartmouth.edu/~cs50/Labs/Lab4/REQUIREMENTS.html).

Read the  [Crawler Design Spec](http://www.cs.dartmouth.edu/~cs50/Labs/Lab4/DESIGN.html).

Read the [Makefile lecture](http://www.cs.dartmouth.edu/~cs50/Lectures/17/makefiles.html).
