/*
 * pagedir.c - A module to manage all of the crawler directory functions related to the TSE
 *
 *
 * Written using class materials provided by Prof. Zhou (such as libcs50.a)
 * Arun Anand, July 2017
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <dirent.h>
#include <math.h>
#include <stdbool.h>
#include "bag.h"
#include "hashtable.h"
#include "webpage.h"
#include "pagedir.h"


static int id = 0; //a static global variable to keep track of the document ids
static int pos = 0; //keeps track of the position from which urls should be extracted from a webpage

/*
* Checks the directory specified as pageDir to see if the file .Crawler is
* present (which would mean that pageDir is a crawler produced directory).
* Returns true iff .crawler is found.
* 
* pageDir - the directory being checked
*/
bool isCrawlerDirectory(char *pageDir);

/*
* takes a document ID and the page directory and returns a file pointer 
* to the file in question. Returns NULL if the file is not found.
*
* where 
* id - the document id
* pageDir - the page directory
*/
FILE *loadFile(int id, char *pageDir);

/*
* A method that takes a webpage as its parameter and returns a string that holds
* all of the html content of the webpage passed.
*
* page - the webpage in question
*/
char *pagefetcher (webpage_t *page);

/*
* returns the next url that is embedded within a webpage. It takes as its parameters
* a reference to the webpage and a boolean representing whether this is a new page
* that has just been encountered.
*
* page is the webpage in question
* new_page is a boolean that is true iff there has not been an attempt to extract
* a url from this page previously.
*/
char *pagescanner (webpage_t *page, bool new_page);

/*
* Saves a file in pageDirectory that holds information about the webpage including
* the url, the depth of the webpage in the crawl, and the html content. The file
* is saved with a unique document id that starts with 1 for the seed url and
* proceeds sequentially henceforth.
*
* content - the html content of the webpage
* page - the webpage in question
* dirname - pageDirectory, where the files need to be stored
*/
void pagesaver(char *content, webpage_t *page, char *dirname);


/*
* A method that takes a webpage as its parameter and returns a string that holds
* all of the html content of the webpage passed.
*
* page - the webpage in question
*/
char *pagefetcher (webpage_t *page)
{
  if (webpage_fetch(page)){
    return webpage_getHTML(page);
  }
  else{
    return NULL;
  }
}

/*
* returns the next url that is embedded within a webpage. It takes as its parameters
* a reference to the webpage and a boolean representing whether this is a new page
* that has just been encountered.
*
* page is the webpage in question
* new_page is a boolean that is true iff there has not been an attempt to extract
* a url from this page previously.
*/
char *pagescanner (webpage_t *page, bool new_page)
{
  char *result;
  if (new_page){ //if no url has been extracted from the page yet, reset pos to 0;
    pos = 0;
  }
  if ((pos = webpage_getNextURL(page, pos, &result)) > 0) {
    char *ret = malloc((strlen(result)+1)*sizeof(char));
    if (ret == NULL){
      fprintf(stderr, "Error allocating memory!");
      exit(6);
    }
    strcpy(ret, result);
    free(result);
    return ret;
  }
  return NULL;
}

/*
* Saves a file in pageDirectory that holds information about the webpage including
* the url, the depth of the webpage in the crawl, and the html content. The file
* is saved with a unique document id that starts with 1 for the seed url and
* proceeds sequentially henceforth.
*
* content - the html content of the webpage
* page - the webpage in question
* dirname - pageDirectory, where the files need to be stored
*/
void pagesaver(char *content, webpage_t *page, char *dirname)
{

  id++;
  //We add three because we have to account for the nullcharacter, the slash and the fact
  //that log10 rounds down.
  int filename_maxlength = strlen(dirname)+log10(id)+3;

  char *filename = malloc(filename_maxlength * sizeof(char));
  char *doc_id= malloc(filename_maxlength * sizeof(char));
  if (filename == NULL || doc_id == NULL){
    fprintf(stderr, "Error allocating memory!");
    exit(6);
  }
  sprintf(doc_id, "%d", id);
  //printf ("%d", id);
  strcpy(filename, dirname);
  strcat(filename, "/");
  strcat(filename, doc_id);
  FILE *fp = fopen(filename, "w");
  fprintf(fp, "%s\n", webpage_getURL(page));
  fprintf(fp, "%d\n", webpage_getDepth(page));
  fprintf(fp, "%s", content);
  fclose(fp);
  free(filename);
  free(doc_id);
}

/*
* Checks the directory specified as pageDir to see if the file .Crawler is
* present (which would mean that pageDir is a crawler produced directory).
* Returns true iff .crawler is found.
* 
* pageDir - the directory being checked
*/
bool isCrawlerDirectory(char *pageDir)
{
  char filename[strlen(pageDir)+10];
  strcpy(filename, pageDir);
  strcat(filename, "/.crawler" );
  FILE *fp = fopen(filename, "r");
  if (fp != NULL){
    fclose(fp);
    return true;
  }
  
  return false;
}

/*
* takes a document ID and the page directory and returns a file pointer 
* to the file in question. Returns NULL if the file is not found.
*
* where 
* id - the document id
* pageDir - the page directory
*/
FILE *loadFile(int id, char *pageDir)
{
  int filename_maxlength = strlen(pageDir)+log10(id)+3;
  char *filename = malloc(filename_maxlength * sizeof(char));
  char *doc_id= malloc(filename_maxlength * sizeof(char));
  sprintf(doc_id, "%d", id);
  strcpy(filename, pageDir);
  strcat(filename, "/");
  strcat(filename, doc_id);
  FILE *fp = fopen(filename, "r");
  free(filename);
  free(doc_id);
  return fp;
}
