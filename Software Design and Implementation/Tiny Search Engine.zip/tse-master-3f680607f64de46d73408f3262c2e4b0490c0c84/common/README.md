# CS50 Tiny Search Engine (TSE) common library

Arun Anand, August 2017.
Compiled using class materials provided by Prof. Xia.

## Usage
To build `common.a`, run `make`. 

To clean up, run `make clean`.

## Overview

 * word - a provided module that is used in order to normalize words for the indexer.
 * index - a module built to support functions related to the indexer, specifically to load, save and build the index.
 * pagedir - a module built to support functions related to the page directory that is built by the crawler.
