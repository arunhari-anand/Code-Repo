/*
* index.h - a header file for the index module
*
*
* incorporates all the logic to load and save index files and build the index
* data structure from a crawler-produced directory
*
* Written using class materials provided by Prof. Zhou
* Arun Anand, August 2017 
*/

#ifndef __INDEX_H
#define __INDEX_H

//global data type
typedef hashtable_t index_t;

//global functions

/*
* Creates a new index data structure - calls hashtable_new
*
* where:
* num_slots is the number of hashing slots in the underlying hashtable
*/
index_t *index_new (int num_slots);

/*
* uses a word (from an indexfile) as a key and attempts to return the associated counterset
*
* returns NULL if error
*
* where:
* ind is the index structure
* word is the key
*/
counters_t *index_find (index_t *ind, char *word);

/*
* attempts to insert a counterset into the index data structure
* returns true if successful and false if not
*
* where:
* ind is the data structure
* word is the key
* and item is the associated counterset
*/
bool index_insert(index_t *ind, const char *word, counters_t *item);

/*
* iterates through the countersets and calls itemfunc on each of them
*
* where:
* ind is the data structure
* arg is the argument to the function itemfunc
* itemfunc is the function to be called on each counter
*/
void index_iterate(index_t *ind, void *arg,
  void (*itemfunc)(void *arg, const char *key, void *item) );

/*
* Deletes the index data structure
* calls hashtable_delete
* 
* where ind is the data structure
* and itemdelete is a function to delete the counterset
*/
void index_delete(index_t *ind, void (*itemdelete)(void *item) );

/*
* This is a function that builds the index data strcuture from a specific file
* that has been produced by crawler
* 
* where:
* ind is the data structure 
* fp is the file pointer to the crawler file in question
*/
void index_build (index_t *ind, FILE *fp, int id);

/*
* saves the index data strcuture to a file with the name indexFilename
* where:
* indexFilename is the name of the new index file
* ind is the data strcuture
*/
void index_save (char *indexFilename, index_t *ind);

/*
* Loads the index from oldFilename into an inverted index data structure
*
* where oldFilename is the file that contains the old index
*/
index_t *index_load(char *oldIndexFilename);

/*
* A helper method that is passed to index_iterate to print the 
* word (that is stored as the key in the underlying hashtable)
* 
* where arg is the file pointer, key is the word, and item is the counterset
*/
void word_print(void *arg, const char *key, void *item);

/*
* A helper method that is passed to counters_iterate to 
* print the doc ids followed by the count of the word in that particular 
* document.
* 
* where arg is the file pointer, key is the doc_id and count is the count
*/
void count_print(void *arg, const int key, int count);
#endif // __INDEX_H
