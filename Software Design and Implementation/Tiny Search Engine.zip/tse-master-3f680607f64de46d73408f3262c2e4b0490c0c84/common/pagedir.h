/*
 * pagedir.h - A header file for the pagedir module
 *
 * Contains all the logic to manage crawler directories
 * Written using class materials provided by Prof. Zhou (such as libcs50.a)
 * Arun Anand, July 2017
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <dirent.h>
#include <math.h>
#include <stdbool.h>
#include "bag.h"
#include "hashtable.h"
#include "webpage.h"


 #ifndef __PAGEDIR_H
 #define __PAGEDIR_H


/*
* A method that takes a webpage as its parameter and returns a string that holds
* all of the html content of the webpage passed.
*
* page - the webpage in question
*/
char *pagefetcher (webpage_t *page);

/*
* returns the next url that is embedded within a webpage. It takes as its parameters
* a reference to the webpage and a boolean representing whether this is a new page
* that has just been encountered.
*
* page is the webpage in question
* new_page is a boolean that is true iff there has not been an attempt to extract
* a url from this page previously.
*/
char *pagescanner (webpage_t *page, bool new_page);

/*
* Saves a file in pageDirectory that holds information about the webpage including
* the url, the depth of the webpage in the crawl, and the html content. The file
* is saved with a unique document id that starts with 1 for the seed url and
* proceeds sequentially henceforth.
*
* content - the html content of the webpage
* page - the webpage in question
* dirname - pageDirectory, where the files need to be stored
*/
void pagesaver(char *content, webpage_t *page, char *dirname);

/*
* Checks the directory specified as pageDir to see if the file .Crawler is
* present (which would mean that pageDir is a crawler produced directory).
* Returns true iff .crawler is found.
* 
* pageDir - the directory being checked
*/
bool isCrawlerDirectory(char *pageDir);

/*
* takes a document ID and the page directory and returns a file pointer 
* to the file in question. Returns NULL if the file is not found.
*
* where 
* id - the document id
* pageDir - the page directory
*/
FILE *loadFile(int id, char *pageDir);

#endif // __PAGEDIR_H
