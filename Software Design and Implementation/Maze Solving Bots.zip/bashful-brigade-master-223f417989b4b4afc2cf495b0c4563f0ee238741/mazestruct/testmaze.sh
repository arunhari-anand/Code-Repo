#!/bin/bash
#
# Series of tests for mazestruct module in Maze Solver
#
# Usage: ./testmaze.sh
#
# Emma Hobday
# CS50 August 2017

echo "TESTING MAZESTRUCT"

./mazestructtest
