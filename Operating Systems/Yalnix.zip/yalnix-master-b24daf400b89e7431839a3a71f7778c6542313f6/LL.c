/*
* LL.c - contains all of the functions necessary to manage the Linked List
* 
* The Memory Men
* Arun Hari Anand, Raunak Bhojwani
*
* October 2017
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Kernel.h"
#include "include/hardware.h"
#include "include/yalnix.h"
#include "PCB.h"
#include "Cvar.h"
#include "LL.h"
#include "LoadProgram.h"
#include "Lock.h"
#include "Memory.h"
#include "Pipe.h"

/*
 *Function to create a linked list, allocates memory for the data structure
 *
 *
 */
LL *LL_new()
{
	LL *new_list = (LL *) malloc(sizeof(LL));
	new_list->head = NULL;
	new_list->tail = NULL;

	return new_list;
}

/* 
 * Function to add to the linked list,
 *
 * LL_add
*/

int LL_add(LL *linked_list, void *item, int id) {

	// fail if the linked_list does not exist
	if(linked_list == NULL) {
		return -1;
	}

	LL_node *new_node = malloc(sizeof(LL_node));
	if (new_node == NULL) {
		return ERROR;
	}

	new_node->info = item;
	new_node->id = id;
	new_node->next = NULL;

	// if the linked list doesn't have head 
	if(linked_list->head == NULL) {
		new_node->prev = NULL;
		linked_list->head = new_node;
		linked_list->tail = new_node;
	}

	// otherwise just add the node in by creating a new LL_node
	else{
		new_node->prev = linked_list->tail;
		linked_list->tail->next = new_node;
		linked_list->tail = new_node;
	}
	// return 0 to indicate success
	return 0;
}

/* 
 * Function to search the linked list for a given node's id
 *
 * LL_search
*/

LL_node *LL_search(LL *linked_list, int id) {
	if (linked_list == NULL) {
		return NULL;
	}

	LL_node *current_node = linked_list->head;

	// loop through all the nodes, checking ids until a match is found
	while(current_node != NULL) {
		if(id == current_node->id){
			return current_node;
		}
		current_node = current_node->next;
	}
	// if no match, return NULL
	return NULL;
}

/* 
 * Function to remove a node, given the node's id, from the linked list returning the removed node
 *
 * LL_search
*/

LL_node *LL_delete(LL *linked_list, int id) {

	if(linked_list == NULL) {
		return NULL;
	}

	// find the node to be deleted
	LL_node *delete_node = LL_search(linked_list, id);
	TracePrintf(2, "delete_node is: %d with id: %d", delete_node, id);
	
	// commence LL operations to delete the node
	if(delete_node != NULL) {
		if(linked_list->head == delete_node && linked_list->tail == delete_node){
			linked_list->head = NULL;
			linked_list->tail = NULL;
		}
		else if(linked_list->head == delete_node) {
			linked_list->head = delete_node->next;
			delete_node->next->prev = delete_node->prev;
		}
		else if(linked_list->tail == delete_node) {
			delete_node->prev->next = NULL;
			linked_list->tail = delete_node->prev;
			delete_node->prev = NULL;
		}
		else{
			delete_node->prev->next = delete_node->next;
			delete_node->next->prev = delete_node->prev;

			delete_node->next = NULL;
			delete_node->prev = NULL;
		}
		return delete_node;
	}
	// return NULL if invalid id
	return NULL;
}

/* 
 * Function to remove the head node, returning it to the caller
 *
 * LL_pop
*/

LL_node *LL_pop(LL *linked_list) {
	if(linked_list == NULL) {
		return NULL;
	}

	LL_node *pop_node = linked_list->head;

	// remove the head node
	if(linked_list->head == pop_node && linked_list->tail == pop_node){
		linked_list->head = NULL;
		linked_list->tail = NULL;
	}
	else {
		linked_list->head = pop_node->next;
		pop_node->next->prev = pop_node->prev;
	}
	
	//return it to caller
	return pop_node;
}

/* 
 * Function that checks if a given linked list is empty
 *
 * LL_empty
*/

bool LL_empty(LL *linked_list) {
	if (linked_list == NULL) {
		return false;
	}
	return (linked_list->head == NULL) && (linked_list->tail == NULL);
}

/* 
 * Function that deletes an entire list, takes as input 
 * the list and a function that will delete according to what the list contains
 *
 * LL_kill
*/

void LL_kill(LL *linked_list, void (*itemdelete)(void *item)) {
	if (linked_list != NULL) {
		LL_node *curr;
		// delete each node in the list and whatever it contains
		for (curr = linked_list->head; curr != NULL;) {
			if (itemdelete != NULL) {
				(*itemdelete)(curr->info);
			}

			LL_node *next = curr->next;
			free(curr);
			curr = next;
		}
		// free all the nodes and the list itself
		free(linked_list);
	}
}
