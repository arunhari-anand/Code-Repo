/*
* Pipe.c - contains all of the functionality required to implement pipes in the operating system
*
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* October 2017
*/
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Kernel.h"
#include "../include/hardware.h"
#include "include/yalnix.h"
#include "PCB.h"
#include "Cvar.h"
#include "LL.h"
#include "LoadProgram.h"
#include "Lock.h"
#include "Memory.h"
#include "Pipe.h"

/* Initialize the pipe by allocating memory, and setting its data structure's 
 * internal variables to the appropriate values
 */
pipe_t *init_pipe() {
	TracePrintf(1, "init_pipe\n");

	pipe_t *new_pipe = malloc(sizeof(pipe_t));

	new_pipe->pipe_id = next_pipe++;

	new_pipe->current_buffer_size = 0;
	new_pipe->buffer_length_remaining = 0;

	new_pipe->waiting_to_read = LL_new();

	return new_pipe;
}

/* Copy into the pipe's buffer the buffer given as a param
 */
int pipe_copy(pipe_t *p, void *buffer, int len)
{	
	TracePrintf(1, "pipe_copy\n");


	// check if here are enough spots between the buffer given and the buffer
	if (len <= ((int) (p->current_buffer_size - p->buffer_length_remaining - (int) p->first_free - (int) p->buf))) {
		// copy it over
		memcpy(p->buf + p->buffer_length_remaining, buffer, len);
		// increment length remaining after copying over
		p->buffer_length_remaining += len;

		return len;
	}
	else {
		return ERROR;
	}

}

/* Write to the buffer given as a param what is stored in the pipe's buffer
 */
int pipe_write(pipe_t *p, void *buffer, int len)
{
	TracePrintf(1, "pipe_write\n");

	// make sure that enough of the buffer is remaining to write
	if (len <= p->buffer_length_remaining) {
		// copy it over
		memcpy(buffer, p->first_free, len);

		// increment the pointer to the first free spot
		p->first_free += len;
		// decrement the buffer length remaining
		p->buffer_length_remaining -= len;
		return len;

	}

	else {
		return ERROR;
	}
}

/* Free the pipe
 */
void kill_pipe(void *p) {
	TracePrintf(1, "kill_pipe\n");
	pipe_t *pipe_delete = (pipe_t *) p;

	// delete the list of waiting to read
	LL_kill(pipe_delete->waiting_to_read, KillPCB);
	// free the pipe
	free(pipe_delete);
}