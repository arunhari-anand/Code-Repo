/*
* fork_test.c - test code for SysFork
*
* Arun Hari Anand, Raunak Bhojwani
* November 2017
*/

int main(int argc, char *argv[]) {
  TracePrintf(1, "Fork File Test\n");
  int pid, rc;
  pid = GetPid();

  TracePrintf(1, "Parent's pid = %d\n", pid);
  rc = Fork();
  if (rc == 0) {
    pid = GetPid();
    while(1) {
      TracePrintf(1, "Child's pid = %d!\n", pid);
      Pause();
    }
  } 
  else {
    while(1) {
      TracePrintf(1, "Parent's pid = %d, Child's pid = %d\n", pid, rc);
      Pause();
    }
  }
  return 0;
}
