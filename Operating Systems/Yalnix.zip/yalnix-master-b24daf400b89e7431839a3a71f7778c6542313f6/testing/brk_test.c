/*
* brk_test.c - test code for SysBrk
*
* Arun Hari Anand, Raunak Bhojwani
* November 2017
*/

int main(int argc, char *argv[]) {
    TracePrintf(1, "Brk Test File\n");
    int i;
    int *int_list;
    int sum;
    while (1) {
        int_list = (int *) malloc(10 * sizeof(int));
        for (i = 1; i <= 10; i++) {
            int_list[i-1] = i;
        }
        for (i = 0; i<10; i++){
            sum += int_list[i];
        }
        TracePrintf(1, "sum of elements 1 through 10 is %d, correct answer is 55", sum);
        free(int_list);
        Pause();
    }
    return 0;
}
