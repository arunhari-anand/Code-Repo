/*
* delay_test.c - test code for SysDelay
*
* Arun Hari Anand, Raunak Bhojwani
* November 2017
*/

int main(int argc, char *argv[]) {
    TracePrintf(1, "Delay Test File\n");
    while (1) {
        TracePrintf(1, "Delay for 5 clock cycles\n");
        Delay(5);
        TracePrintf(1, "Delay done\n");
    }
    return 0;
}
