/*
* getpid_test.c - test code for SysGetPid
*
* Arun Hari Anand, Raunak Bhojwani
* November 2017
*/

int main(int argc, char *argv[]) {
    TracePrintf(1, "GetPid Test File\n");
    int pid;
    while (1) {
	    pid = GetPid();
	    TracePrintf(1, "Pid = %d\n", pid);
	    Pause();
    }
    return 0;
}
