/*
* exit_test.c - test code for SysExit
*
* Arun Hari Anand, Raunak Bhojwani
* November 2017
*/

int main(int argc, char *argv[]) {
  TracePrintf(1, "Exit File Test\n");
  
  int pid, rc, i;
  pid = GetPid();
  TracePrintf(1, "Parent's pid =  %d\n", pid);

  rc = Fork();
  if (rc == 0) {
    pid = GetPid();

    TracePrintf(1, "Child's pid = %d\n", pid);

    for (i = 1; i <= 10; i++) {
      Pause();
    }

    TracePrintf(1, "Bye bye baby, baby bye bye.\n");
    Exit(rc);
  } 
  else {

    TracePrintf(1, "Parent's pid = %d, Child's pid = %d\n", pid, rc);

    TracePrintf(1, "Bye bye parent, parent bye bye\n");
    Exit(rc);
  }
}
