# Yalnix - The Memory Men
# Testing Report

## Report by Arun Anand and Raunak Bhojwani for Professor Sean Smith
## Thursday November 16, 2017

### Testing Files

For the purpose of testing our Yalnix, I wrote the following testing files and they can found in the directory unsurprisingly named "testing". 
* Brk_test.c - Tests the SysBrk system call.
* Delay_test.c - Tests the SysDelay system call.
* Exit_test.c - Tests the SysExit system call.
* Fork_test.c - Tests the SysFork system call.
* Getpid_test.c - Tests the SysGetPid system call.

A report for Professor Sean Smith by The Memory Men
