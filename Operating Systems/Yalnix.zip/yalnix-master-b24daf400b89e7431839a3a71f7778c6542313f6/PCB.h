/*
* PCB.h - contains all of the functions necessary to handle process control blocks.
* Provides a way for PCBs to be looked up through process ids, using a hashtable-like data structure
*
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* October 2017
*/


#ifndef __PCB_H
#define __PCB_H

#include <stdbool.h>
#include "include/hardware.h"
#include "LL.h"


#define KERNEL_STACK_SIZE KERNEL_STACK_MAXSIZE/PAGESIZE
#define name_len 50

// This data structure will keep track of the all of the information in the process control block, including pid, kernel state, user context and process status
typedef struct pcb {

	int pid;
	char process_name[name_len];

	KernelContext kernel_state;
	UserContext user_state;

	struct pte kernel_stack[KERNEL_STACK_SIZE];
	struct pte pt_r1[MAX_PT_LEN];

	struct pcb *parent;
	LL *live_children;
	LL *zombies;

	bool is_waiting;
	int process_status;

	LL *locks_owned;
	LL *pipes;

	unsigned int lowest_stack_address;
	unsigned int break_address;

	int rc;	
	int cvar_waiting;
	int wait_time;

	int read_length;
	char *read_buffer;

	int write_length;
	char *write_buffer;

	bool is_kc_initialized;

} pcb_t;

//Initializes a new pcb_t reference and stores it in the hashtable with key = pid
pcb_t *InitializeNewPCB(int pid);

//Modifies the kernel state of the PCB associated with the process with process id = pid
void UpdatePCB(pcb_t *to_be_updated, pcb_t *model);

void KillPCB(void *pcb);

#endif
