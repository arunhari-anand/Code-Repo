/*
* Memory.c - contains all of the logic necessary to handle page tables and setting the privileged registers relevant
* to memory, such as REGPTBR0.
*
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* October 2017
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Kernel.h"
#include "include/hardware.h"
#include "include/yalnix.h"
#include "PCB.h"
#include "Cvar.h"
#include "LL.h"
#include "LoadProgram.h"
#include "Lock.h"
#include "Memory.h"
#include "Pipe.h"


/* A function to set up the region 0 page table*/
void setup_pt_r0(){
  TracePrintf(1, "setup_pt_r0\n");
  unsigned int n;

  //if the page belongs to the data segment, give read write permissions, or else read exec permission (for code)
  for (n = 0; n<kernel_break; n++){
    pt_r0[n].valid = 1;
    pt_r0[n].pfn = n;

    if (n<kernel_data_base_page){
      pt_r0[n].prot = PROT_READ | PROT_EXEC;
    }
    else{
      pt_r0[n].prot = PROT_READ | PROT_WRITE;
    }
  }
}

/*creates a new pagetable for region 1 for the given process, initialized with no protections or validity and 
pfn = 0*/
void create_pt_r1(pcb_t *p){
  TracePrintf(1, "create_pt_r1\n");
  int n;
  for (n = 0; n<MAX_PT_LEN; n++){
    p->pt_r1[n].valid = 0;
    p->pt_r1[n].prot = 000;
    p->pt_r1[n].pfn = 0;
  }
}

/*sets up the kernel stack for the idle process*/
void setup_idle_kernelstack(pcb_t *p)
{
  TracePrintf(1, "setup_idle_kernelstack\n");
  unsigned int n;
  for (n = 0; n<KERNEL_STACK_MAXSIZE/PAGESIZE; n++){
    //TracePrintf("setting up kernel stack, page = %d", )
    //int pfn = allocate_frame(n+(((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT));
    p->kernel_stack[n].valid = 1;
    p->kernel_stack[n].pfn = n + (((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT);
    p->kernel_stack[n].prot = PROT_READ | PROT_WRITE;
    
  }
}

/*sets up the kernelstack for the process p by allocating physical frames for each PTE and setting up
the appropriate protections*/
void setup_kernelstack(pcb_t *p)
{
  TracePrintf(1, "setup_kernelstack\n");
  unsigned int n;
  for (n = 0; n<KERNEL_STACK_MAXSIZE/PAGESIZE; n++){
    //TracePrintf("setting up kernel stack, page = %d", )
    int pfn = allocate_frame(-1);
    p->kernel_stack[n].valid = 1;
    p->kernel_stack[n].pfn = pfn;
    TracePrintf(1, "pid %d, n = %d, pfn = %d", p->pid, n, pfn);
    p->kernel_stack[n].prot = PROT_READ | PROT_WRITE;
    
  }
}

/*Initializes the init process by creating a new pcb, setting up its region 1 page table, and
then creating the idle process kernel stack*/
void initializeInit(unsigned int pmem_size, UserContext *uctxt, char* cmd_args[])
{
  TracePrintf(1, "initializeInit\n");
  pcb_t *init = InitializeNewPCB(current_pid++);
  //memcpy(init->user_state, uctxt, sizeof(UserContext));
  init->user_state = *uctxt;
  create_pt_r1(init);
  setup_kernelstack(init);
}

/*
* Allocates a free frame for a particular page; returns the pfn.
* if pfn is positive then this function allocates the given frame to the process. Otherwise it allocates the next free frame
*
*/
int allocate_frame(int pfn)
{
  TracePrintf(1, "allocate_frame\n");
  if (LL_empty(free_frames)){
    return ERROR;
  }

  if (pfn < 0){
    LL_node *new_frame = LL_pop(free_frames);
    LL_add(allocated_frames, new_frame, pfn);
    return ((frame_t *) (new_frame->info))->pfn;
  }
  else{
    LL_node *new_frame = LL_delete(free_frames, pfn);
    LL_add(allocated_frames, new_frame, ((frame_t *) (new_frame->info))->pfn);
    return ((frame_t *) (new_frame->info))->pfn;
  }

}

/*
* deallocates a frame that was previously in use
* 
*/
int deallocate_frame(unsigned int pfn){
  TracePrintf(1, "deallocate_frame\n");
  LL_node *fr = LL_delete(allocated_frames, pfn);
  LL_add(free_frames, fr, pfn);
}

/*
* deletes the region 1 page table of a process by deallocating all of the frames associated with it
*
*/
void delete_pt_r1(pcb_t *proc){
  TracePrintf(1, "delete_pt_r1\n");
  int i;
  for (i = 0; i< (VMEM_1_SIZE/PAGESIZE); i++){
    if (proc->pt_r1[i].valid == 1){
      proc->pt_r1[i].valid = 0;
      deallocate_frame(proc->pt_r1[i].pfn);
    }
  }
}

/*
* Sets up the region 1 page table for a process with the appropriate protections from the start page to the page
* (start + pages)
*
*/
int setup_new_pt_r1(pcb_t *proc, unsigned int prot_new, unsigned int pages, unsigned int start){
  TracePrintf(1, "setup_new_pt_r1\n");
  unsigned int page;
  for (page = start; page<start+pages; page++){
    int pfn_new = allocate_frame(-1);
    if (pfn_new == ERROR){
      return ERROR;
    }
    proc->pt_r1[page].pfn = pfn_new;
    proc->pt_r1[page].valid = 1;
    proc->pt_r1[page].prot = prot_new;
  }
}

/*
* modifies the protections for the region 1 page table of the given process from the start page to start + pages
* updates the protection to new_prot
*/
int modify_pt_r1_prot(pcb_t *proc, unsigned int new_prot, unsigned int pages, unsigned int start){
  TracePrintf(1, "modify_pt_r1_prot\n");
  unsigned int page;
  for (page = start; page<start+pages; page++){
    proc->pt_r1[page].prot = new_prot;
  }
}

/*
* flushes the TLB
* if value = 1, then region 1 will be flushed.
* if value = 0, then region 0 will be flushed.
* if value = -1, then the entire TLB will be flushed.
*/
void flush_tlb(int value){

  //the TLB will be flushed; 
  //if value is 0 then region 0 will be flushed, if value is 1 then region 1 will be flushed, and if value is -1 then the whole tlb will be flushed
  if (value == 0){
    TracePrintf(1, "flush_tlb, 0\n");
    WriteRegister(REG_TLB_FLUSH, TLB_FLUSH_0);
  }
  else if (value == 1){
    TracePrintf(1, "flush_tlb, 1\n");
    WriteRegister(REG_TLB_FLUSH, TLB_FLUSH_1);
  }
  else if(value == -1){
    TracePrintf(1, "flush_tlb, -1\n");
    WriteRegister(REG_TLB_FLUSH, TLB_FLUSH_ALL);
  }
}


/*
* clones the address space, including the data that belongs to each PTE entry
*
*/
int clone_address_space(pcb_t *source, pcb_t *dest){
  //clone_kernelstack(source, dest);
  int temp_page = (KERNEL_STACK_BASE >> PAGESHIFT) - 1; //temporary page
  
  //store the previous state of the temp frame
  unsigned int stored_pfn = pt_r0[temp_page].pfn;
  unsigned int stored_valid = pt_r0[temp_page].valid;
  unsigned int stored_protection = pt_r0[temp_page].prot;


  pt_r0[temp_page].valid = 1;
  pt_r0[temp_page].prot = PROT_READ | PROT_WRITE;


  unsigned int dest_addr = temp_page << PAGESHIFT; //adress of the temp page

  //rotate through the kernel stack of the dest process and copy
  int i;
  for (i = 0; i < VMEM_1_SIZE/PAGESIZE; i++) {
    if ( dest->pt_r1[i].valid == 1) {
      unsigned int src_addr = VMEM_1_BASE + (i * PAGESIZE);
      pt_r0[temp_page].pfn = dest->pt_r1[i].pfn;
      WriteRegister(REG_TLB_FLUSH, TLB_FLUSH_0);
      memcpy((void *)dest_addr, (void *) src_addr, PAGESIZE);
    }
  }

  //restore the state of the old process
  pt_r0[temp_page].valid = stored_valid;
  pt_r0[temp_page].pfn = stored_pfn;
  pt_r0[temp_page].prot = stored_protection;
  WriteRegister(REG_TLB_FLUSH, TLB_FLUSH_0);

  return 0;
}

/* 
* grows the heap of a process from the current break to the new break
*
*/
int grow_heap(pcb_t *process, int new_break){
  TracePrintf(1, "grow_heap\n");
  int page;
  for (page = process->break_address; page < new_break; page++){
    int pfn = allocate_frame(-1);
    if (pfn == ERROR){
      return ERROR;
    }
    process->pt_r1[page].valid = 1;
    process->pt_r1[page].prot = PROT_READ | PROT_WRITE;
  }
  return 0;
}


/*
*
* shrinks the heap of the current process from the current break to new_break
*
*/
int shrink_heap(pcb_t *process, int new_break){
  TracePrintf(1, "shrink_heap\n");
  int page;
  for (page = new_break; page < process->break_address; page++){
    deallocate_frame(process->pt_r1[page].pfn);
    process->pt_r1[page].valid = 0;
    process->pt_r1[page].prot = 000;
  }
  return 0;
}


/*
* Deallocates all of the kernel stack frames for a process
*
*/
void free_r0_frames(pcb_t *process){
  TracePrintf(1, "free_r0_frames\n");
  int page;
  for (page = 0; page < KERNEL_STACK_SIZE; page++){
    if(process->kernel_stack[page].valid == 1){
      process->pt_r1[page].valid = 0;
      deallocate_frame(process->kernel_stack[page].pfn);
    }
  }
}

/*
* makes a copy of the kernel stack from source to dest, used during a context switch
*/
int clone_kernelstack(pcb_t *source, pcb_t *dest){
  TracePrintf(1, "clone_kernelstack, source pid = %d, dest pid = %d\n", source->pid, dest->pid);
  TracePrintf(1, "source (idle) = %p, dest (init) = %p\n", source, dest);

  int n;
  TracePrintf(1, "KERNEL_STACK_MAXSIZE = %d, PAGESIZE = %d\n", KERNEL_STACK_MAXSIZE, PAGESIZE);
  for (n = 0; n<(KERNEL_STACK_MAXSIZE/PAGESIZE); n++){
    TracePrintf(1, "In dest, n = %d, pfn[n] = %d\n", n, dest->kernel_stack[n].pfn);
  }

  //set up a temporary frame for copying, and store the old pte
  int temp_page = (KERNEL_STACK_BASE >> PAGESHIFT) - 1;
  unsigned int stored_pfn = pt_r0[temp_page].pfn;
  unsigned int stored_valid = pt_r0[temp_page].valid;
  unsigned int stored_protection = pt_r0[temp_page].prot;

  
  pt_r0[temp_page].valid = 1;
  pt_r0[temp_page].prot = PROT_READ | PROT_WRITE;
  unsigned int dest_addr = temp_page << PAGESHIFT; //base address of the destination page


  pt_r0[temp_page].pfn = allocate_frame(-1);
  int old_pfn = pt_r0[temp_page].pfn;

  //rotate through the kernel stack entries for the destination and copy them over
  int i;
  for (i = 0; i < KERNEL_STACK_MAXSIZE/PAGESIZE; i++) {

    unsigned int src_addr = KERNEL_STACK_BASE + (i * PAGESIZE);

    TracePrintf(1, "kernel_stakc[i].pfn = %d, pt_r0[temp_page].pfn = %d\n", dest->kernel_stack[i].pfn, pt_r0[temp_page].pfn);
    pt_r0[temp_page].pfn = (dest->kernel_stack[i]).pfn;
    WriteRegister(REG_TLB_FLUSH, TLB_FLUSH_0);
    TracePrintf(1, "iter2\n");

    memcpy((void *) dest_addr, (void *) src_addr, PAGESIZE);
    TracePrintf(1, "iter3\n");
  }

  //restore the state of the temp page
  pt_r0[temp_page].pfn = stored_pfn;
  pt_r0[temp_page].valid = stored_valid;
  pt_r0[temp_page].prot = stored_protection;

   WriteRegister(REG_TLB_FLUSH, TLB_FLUSH_0);

  return 0;
}











