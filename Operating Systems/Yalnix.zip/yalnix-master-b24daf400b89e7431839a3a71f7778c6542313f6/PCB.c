#include "PCB.h"

/*
* PCB.c - contains all of the logic and data structures necessary to handle process control blocks.
* Provides a way for PCBs to be looked up through process ids, using a hashtable-like data structure
*
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* October 2017
*/

/* This module uses a hashtable-like data structure to 
 * keep track of the PCBs and their associated process ids.
 * The key for the hashtable will be the process id, and the 
 * values will be the pcb_t references.
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Kernel.h"
#include "include/hardware.h"
#include "PCB.h"
#include "Cvar.h"
#include "LL.h"
#include "LoadProgram.h"
#include "Lock.h"
#include "Memory.h"
#include "Pipe.h"

#define READY 1
#define BLOCKED -1
#define RUNNNING 0

//Initializes a new pcb_t reference and store it in the hashtable with key = pid
pcb_t *InitializeNewPCB(int pid){
	TracePrintf(1, "InitializeNewPCB\n");

	//malloc  new pcb struct
	pcb_t *new = (pcb_t *) malloc(sizeof(pcb_t));

	//assign the process's pid
	new->pid = pid;

	//initialize the linked lists for children and lock ids
	new->live_children = LL_new();
	new->zombies = LL_new();
	new->locks_owned = LL_new();
	new->pipes = LL_new();

	//new->user_state = malloc(sizeof(UserContext));
	//new->kernel_state = malloc(sizeof(KernelContext));

	new->is_kc_initialized = false;

	TracePrintf(1, "\n initialized the new pcb for pid = %d\n", pid);

	return new;
}

// Modifies the kernel state of the PCB associated with the process with process id = pid
void UpdatePCB(pcb_t *to_be_updated, pcb_t *model){
	TracePrintf(1, "UpdatePCB\n");
	memcpy(to_be_updated, model, sizeof(pcb_t));
}

// Function to delete a PCB, this function is passed as a parameter to LL_kill
void KillPCB(void *pcb) {

	TracePrintf(1, "KillPCB\n");
	pcb_t *pcb_delete = (pcb_t *) pcb;

	// kill all the linked lists store in a pcb
	LL_kill(pcb_delete->live_children, KillPCB);
	LL_kill(pcb_delete->zombies, KillPCB);
	LL_kill(pcb_delete->locks_owned, KillLock);
	LL_kill(pcb_delete->pipes, kill_pipe);

	//free(pcb_delete->user_state);
	//free(pcb_delete->kernel_state);

	// free the pcb
	free(pcb_delete);
}
