#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Kernel.h"
#include "include/hardware.h"
#include "include/yalnix.h"
#include "PCB.h"
#include "Cvar.h"
#include "LL.h"
#include "LoadProgram.h"
#include "Lock.h"
#include "Memory.h"
#include "Pipe.h"

/* Internal method to check if the page address provided has 
 * both the validitiy and protection permissions
 */
bool is_valid_page_permission(unsigned int page_address, u_long protections) {
	int validity = current_process->pt_r1[page_address].valid;
	bool is_valid = validity == 1;

	u_long perm = current_process->pt_r1[page_address].prot & protections;
	bool permission_check = perm == 1;

	return is_valid && permission_check;
}

/* Internal method to check if the parameter given by the user 
 * is within the virtual memory limits, and check whether each frame 
 * has the valid page permissions
 */
bool is_valid_address(unsigned int user_param, int bytes, u_long protections) {
	if ((user_param < VMEM_1_BASE) || (user_param >= VMEM_1_LIMIT)) {
		return false;
	}

	int start = ((unsigned int) (user_param - VMEM_1_BASE) >> PAGESHIFT);
	int end = start + (bytes >> PAGESHIFT);

	int i;
	for (i = start; i <= end; i++) {
		if (!is_valid_page_permission(i, protections)) {
			return false;
		}
	}
	return true;
}

/* Internal method to check if the parameter is a valid string, has the right page permissions
 * for each char in the string
 */
bool is_valid_char(char *string) {
	if (((unsigned int) string < VMEM_1_BASE) || ((unsigned int) string >= VMEM_1_LIMIT)) {
		return false;
	}

	int start = ((unsigned int) ((unsigned int) string - VMEM_1_BASE) >> PAGESHIFT);
	if (!is_valid_page_permission(start, PROT_READ)) {
		return false;
	}

	int curr_page;
	string ++;
	while (string != '\0') {
		curr_page = ((unsigned int) ((unsigned int) string - VMEM_1_BASE) >> PAGESHIFT);
		if (!is_valid_page_permission(curr_page, PROT_READ)) {
			return false;
		}
		string ++;
	}
	return true;
}

/*
* Implements the "fork" syscall for the yalnix
*
*/
int SysFork(UserContext *user_state_arg){
	TracePrintf(1, "SysFork\n");

	current_process->user_state = *user_state_arg;

	pcb_t *child = (pcb_t *) InitializeNewPCB(current_pid);

	if (child == NULL) {
		return ERROR;
	}

	current_pid++;

	create_pt_r1(child);
	setup_kernelstack(child);

	child->is_waiting = false;
	child->lowest_stack_address = current_process->lowest_stack_address;
	child->break_address = current_process->break_address;

	clone_address_space(current_process, child); //method that clones the region 1 address space of a process

	LL_add(current_process->live_children, child, child->pid);

	child->parent = current_process;

	int pid = child->pid;

	LL_add(ready, current_process, current_process->pid); // Add child to the ready queue
	switch_process(NEW_PROCESS, child, user_state_arg);

	if (pid == current_process->pid){
		return 0;
	}
	else {
		return pid;
	}

}

/*
* Implements the exec syscall for the yalnix
*
*/
int SysExec(char *filename, char **argvec, UserContext *user_state_arg){
	TracePrintf(1, "SysExec\n");

	if (!is_valid_char(filename)) {
		return ERROR;
	}

	LoadProgram(filename, argvec, current_process); //loads the new program into the address space
	*user_state_arg = current_process->user_state;
	return 0;

}

/*
* Implements the exit syscall for the yalnix
*
*/
int SysExit(int status, UserContext *user_state_arg){
	TracePrintf(1, "SysExit\n");
	while(!LL_empty(current_process->live_children)){
		pcb_t *p = (pcb_t *) ((LL_pop(current_process->live_children))->info);
		p->parent = NULL;
	}
	current_process->rc = status;
	free_r0_frames(current_process);
	delete_pt_r1(current_process);

	//if the process has a parent, then update its pcb. If it is waiting then allow it to proceed.
	if (current_process->parent != NULL){
		LL_delete(current_process->parent->live_children, current_process->pid);
		LL_add(current_process->parent->zombies, current_process, current_process->pid);
		if (current_process->parent->is_waiting) {
            current_process->parent->is_waiting = false;
            LL_add(ready, current_process->parent, current_process->parent->pid);
        }
	}
	switch_process(NEXT_PROCESS, NULL, user_state_arg);
	return 0;
}

/*
* Implements the wait syscall for the yalnix
*
*
*/
int SysWait(int *status_ptr, UserContext *user_state_arg){
	TracePrintf(1, "SysWait\n");

	if (!is_valid_address((unsigned int) status_ptr, sizeof(int), PROT_WRITE)) {
		return ERROR;
	}

	if (LL_empty(current_process->live_children)){
		return ERROR;
	}

	//returns the exit status of any dead child
	current_process->is_waiting = true;
	switch_process(NEXT_PROCESS, NULL, user_state_arg);
	pcb_t *dead_child = (pcb_t *) (LL_pop(current_process->zombies))->info;
	*status_ptr = dead_child->rc;
	return 0;
}

/* Syscall to get the process id of the current process
 */
int SysGetPid(void){
	TracePrintf(1, "SysGetPid\n");
	return current_process->pid;
}

/* This syscall is passed a new break address, which it uses to then determine whether to grow or shrink the heap
* The heap is then grown or shrunk (assigning appropriate protections using the functions in Memory.c)
 */
int SysBrk(void *address){
	TracePrintf(1, "SysBrk\n");
	int vmem_first_page = ((unsigned int) VMEM_1_BASE) >> PAGESHIFT;
	unsigned int new_break = (((unsigned int) (address-1)) >> PAGESHIFT) - vmem_first_page + 1;
	if (new_break > current_process->break_address){
		grow_heap(current_process, new_break); //Memory.c
	}
	else if (new_break > current_process->break_address){
		shrink_heap(current_process, new_break); //Memory.c
	}
	current_process->break_address = new_break;
	return 0;
}

/*
* This function blocks execution of the process until the given number of clock ticks expires.
* This function coordinates with trap_clock in order to provide this functionality
*
*/
int SysDelay(int clock_ticks, UserContext *user_state_arg){
	TracePrintf(1, "SysDelay\n");
	current_process->wait_time = clock_ticks;
	LL_add(clock_blocked, current_process, current_process->pid);
	switch_process(NEXT_PROCESS, NULL, user_state_arg);
	return 0;
}

/*
* This syscall copies the contents of the given buffer into the read buffer of the given process.
* It then returns the number of characters copied into this buffer
*
*/
int SysTtyRead(int tty_id, void *buf, int len, UserContext *user_state_arg){
	TracePrintf(1, "SysTtyRead\n");

	if (!is_valid_address((unsigned int) buf, len, PROT_WRITE)) {
		return ERROR;
	}

	termstate_t *state = tty_array[tty_id];
	char *line_buf = (char *) (LL_pop(state->lines)->info);
	if (line_buf != NULL){
		memcpy(buf, line_buf, len);

		if (get_true_len(line_buf) > len){
			int charsleft = get_true_len(line_buf) - len;
			char remainder[charsleft];
			memcpy(remainder, line_buf, charsleft);
			line_buf = remainder;
			LL_add(state->lines, line_buf, charsleft);
			return len;
		}

		else{
			return get_true_len(line_buf);
		}
	}
	LL_add(state->w_read, current_process, current_process->pid);
	current_process->read_length = len;
	current_process->read_buffer = malloc(len * sizeof(char));
	switch_process(NEXT_PROCESS, NULL, user_state_arg);
	memcpy(buf, current_process->read_buffer, current_process->read_length);
	return current_process->read_length;
}

/*
* This syscall copies the contents of the write buffer of the given process into the buffer provided.
* It then uses TtyTransmit to transmit this into the tty. It returns the number of characters transmitted, or error.
*/
int SysTtyWrite(int tty_id, void *buf, int len, UserContext *user_state_arg){
	TracePrintf(1, "SysTtyWrite\n");

	if (!is_valid_address((unsigned int) buf, len, PROT_READ)) {
		return ERROR;
	}

	termstate_t *state = tty_array[tty_id];
	current_process->write_length= len;
	current_process->write_buffer = malloc(len * sizeof(char));
	memcpy(current_process->write_buffer, buf, len);
	switch_process(NEXT_PROCESS, NULL, user_state_arg);
	TtyTransmit(tty_id, current_process->write_buffer, TERMINAL_MAX_LINE);
	return len;
}


/*
* Gets the true length of the provided string by counting all characters until the null character.
*/
int get_true_len(char *str){
	TracePrintf(1, "get_true_len\n");
	int len = 0;
	int i = 0;
	char a = str[0];
	while (a != 0){
		len++;
		i++;
		a = str[i];
	}
}

/* Create a new lock; save its identifier at *lock idp.
 * In case of any error, the value ERROR is returned.
 */
int SysLockInit(int *lock_idp){
	TracePrintf(1, "SysLockInit\n");

	if (!is_valid_address((unsigned int) lock_idp, sizeof(int), PROT_WRITE)) {
		return ERROR;
	}


	// initialize a new lock using method from lock.c
	lock_t *new_lock = InitializeNewLock(next_lock);
	next_lock++;

	// return ERROR if lock not properly initialized
	if (!new_lock) {
		return ERROR;
	}

	// add this new lock to list of locks and store its id
	LL_add(locks, new_lock, new_lock->lock_id);
	lock_idp = (int *) new_lock->lock_id;

	return 0;
}

/* Acquire the lock identified by lock id.
 * In case of any error, the value ERROR is returned.
 */
int SysAcquire(int lock_id, UserContext *user_state_arg){
	TracePrintf(1, "SysAcquire\n");
	lock_t *acquired_lock = (lock_t *) LL_search(locks, lock_id);

	if (!acquired_lock) {
		return ERROR;
	}

	if (!acquired_lock->is_locked) {
		acquired_lock->is_locked = true;
		acquired_lock->pid = current_process->pid;

		LL_add(current_process->locks_owned, (void *) acquired_lock, acquired_lock->lock_id);

		return 0;
	}

	if (acquired_lock->is_locked && (acquired_lock->pid == current_process->pid)) {
		return 0;
	}

	LL_add(acquired_lock->waiting_processes, (void *) current_process, current_process->pid);
	switch_process(NEW_PROCESS, NULL, user_state_arg);

	return 0;
}

/* Release the lock identified by lock id.
 * The caller must currently hold this lock. In case of
 * any error, the value ERROR is returned.
 */
int SysRelease(int lock_id) {
	TracePrintf(1, "SysRelease\n");
	lock_t *released_lock = (lock_t *) LL_search(locks, lock_id);

	if (!released_lock) {
		return ERROR;
	}

	else if (released_lock->pid != current_process->pid || !released_lock->is_locked) {
		return ERROR;
	}

	LL_node *deleted_lock = LL_delete(current_process->locks_owned, released_lock->lock_id);
	if (deleted_lock == NULL) {
		return ERROR;
	}

	if (LL_empty(released_lock->waiting_processes)) {
		released_lock->is_locked = false;
		return 0;
	}

	LL_node *next_proc_node = LL_pop(released_lock->waiting_processes);
	pcb_t *next_proc_acquire = (pcb_t *) next_proc_node->info;

	released_lock->pid = next_proc_acquire->pid;
	LL_add(next_proc_acquire->locks_owned, (void *) released_lock, released_lock->lock_id);

	LL_add(ready, next_proc_acquire, next_proc_acquire->pid);

	return 0;
}

/*
* Initializes a pipe, used for interprocess communication.
*
*/
int SysPipeInit(int *pipe_idp) {
	TracePrintf(1, "SysPipeInit\n");

	if (!is_valid_address((unsigned int) pipe_idp, sizeof(int), PROT_WRITE)) {
		return ERROR;
	}

    pipe_t *p = (pipe_t *)init_pipe();
    if (p == NULL) {
        return ERROR;
    }
    LL_add(pipes, p, p->pipe_id);
    *pipe_idp = p->pipe_id;
    return 0;
}

/*
* Read from the given buffer and copies the contents into the pipe's read buffer
*/
int SysPipeRead(int pipe_id, void *buf, int len, UserContext *user_state) {
	TracePrintf(1, "SysPipeRead\n");

	if (!is_valid_address((unsigned int) buf, len, PROT_WRITE)) {
		return ERROR;
	}

    if (len < 0) {
        return ERROR;
    }
    if (len == 0) {
        return 0;
    }


    pipe_t *p = (pipe_t *) LL_search(pipes, pipe_id);
    if (p == NULL) {
        return ERROR;
    }

    while (p->current_buffer_size < len) {
        LL_add(p->waiting_to_read, current_process, len);
        switch_process(NEXT_PROCESS, user_state);
    }
    
    return pipe_write(p, buf, len);
}

/*
* Read from the pipe buffer and copies the contents into the given buffer
*/
int SysPipeWrite(int pipe_id, void *buf, int len, UserContext *user_state) {
	TracePrintf(1, "SysPipeWrite\n");
    if (len < 0) {
        return ERROR;
    }
    if (len == 0) {
        return SUCCESS;
    }

    if (!is_valid_address((unsigned int) buf, sizeof(char) * len, PROT_READ)) {
    	return ERROR;
    }

    pipe_t *p = (pipe_t *) LL_search(pipes, pipe_id);
    if (p == NULL) {
        return ERROR;
    }

    if (p->buffer_length_remaining < len) {
        int new_size = p->current_buffer_size + len;
        void *expanded_buf = malloc(sizeof(char) * new_size);
        memcpy(expanded_buf, p->buf, p->current_buffer_size);
        p->buf = expanded_buf;
        p->current_buffer_size = new_size;
    }

    pipe_copy(p, buf, len);
    switch_process(NEXT_PROCESS, user_state);
    return len;
}


/* Create a new condition variable; save its identifier at *cvar idp.
 * In case of any error, the value ERROR is returned.
 */
int SysCvarInit(int *cvar_idp){
	TracePrintf(1, "SysCvarInit\n");

	if (!is_valid_address((unsigned int) cvar_idp, sizeof(int), PROT_WRITE | PROT_READ)) {
		return ERROR;
	}

	int new_lock = next_lock++;
	cvar_t *new_cvar = InitializeNewCvar(new_lock);
	new_lock++;
	if (!new_cvar) {
		return ERROR;
	}

	LL_add(cvars, new_cvar, new_cvar->cvar_id);

	*cvar_idp = new_cvar->cvar_id;

	return 0;
}

/* Signal the condition variable identified by cvar id.
 * (Use Mesa-style semantics.) In case of any error, the
 * value ERROR is returned.
 */
int SysCvarSignal(int cvar_id) {
	TracePrintf(1, "SysCvarSignal\n");
	cvar_t *current_cvar = (cvar_t *) LL_search(cvars, cvar_id);
	if (!current_cvar) {
		return ERROR;
	}

	if (LL_empty(current_cvar->waiting_processes)) {
		return 0;
	}

	pcb_t *next_proc = (pcb_t *) (LL_pop(current_cvar->waiting_processes)->info);
	LL_add(ready, next_proc, next_proc->pid);

	return 0;
}

/* Broadcast the condition variable identified by cvar id.
 * (Use Mesa-style semantics.) In case of any error, the value
 * ERROR is returned.
 */
int SysCvarBroadcast(int cvar_id){
	TracePrintf(1, "SysCvarBroadcast\n");
	cvar_t *current_cvar = (cvar_t *) LL_search(cvars, cvar_id);

	if (!current_cvar) {
		return ERROR;
	}

	while (!LL_empty(current_cvar->waiting_processes)) {
		pcb_t *next_proc = (pcb_t *) (LL_pop(current_cvar->waiting_processes)->info);
		LL_add(ready, next_proc, next_proc->pid);
	}

	return 0;
}

/* Atomically release the lock identified by lock id and wait
 * on the condition variable indentified by cvar id. Upon waking
 * up, re-acquire the lock. (Use Mesa-style semantics.) In case of
 * any error, the value ERROR is returned.
 */
int SysCvarWait(int cvar_id, int lock_id, UserContext *user_state_arg){
	TracePrintf(1, "SysCvarWait\n");
	cvar_t *current_cvar = (cvar_t *) LL_search(cvars, cvar_id);
	if (!current_cvar) {
		return ERROR;
	}

	if (SysRelease(lock_id) == ERROR) {
		return ERROR;
	}

	LL_add(current_cvar->waiting_processes, current_process, current_process->pid);
	switch_process(NEXT_PROCESS, NULL, user_state_arg);

	if (SysAcquire(lock_id, user_state_arg) == ERROR) {
		return ERROR;
	}

	return 0;
}

/* Destroy the lock, condition variable, or pipe indentified by id,
 * and release any associated resources. In case of any error, the
 * value ERROR is returned.
 */

int SysReclaim(int id){
	TracePrintf(1, "SysReclaim\n");
	lock_t *current_lock = (lock_t *) LL_delete(locks, id);
	if (current_lock) {
		if (current_lock->is_locked || !LL_empty(current_lock->waiting_processes)) {
			return ERROR;
		}
		// TODO: free the lock and waiting processes list?
		return 0;
	}

	cvar_t *current_cvar = (cvar_t *) LL_delete(cvars, id);
	if (current_cvar) {
		if (!LL_empty(current_cvar->waiting_processes)) {
			return ERROR;
		}
		// TODO: free the cvar and waiting processes list?
		return 0;
	}

	// TODO: Pipe reclaiming...

	return ERROR;
}
