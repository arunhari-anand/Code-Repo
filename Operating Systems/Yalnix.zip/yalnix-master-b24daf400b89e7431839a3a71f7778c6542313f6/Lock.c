/*
* Lock.c - contains all of the logic necessary to manage locks in the Yalnix kernel
*
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* November 2017
*/
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "../include/hardware.h"
#include "Kernel.h"
#include "Lock.h"
#include "PCB.h"
#include "Cvar.h"
#include "LL.h"
#include "LoadProgram.h"
#include "Memory.h"
#include "Pipe.h"

// Initializes the lock, stores its id and instatiates a new 
// linked list as the list of processes waiting for this lock
lock_t *InitializeNewLock(int lock_id) {
	TracePrintf(1, "InitializeNewLock\n");
	lock_t *lock = malloc(sizeof(lock_t));

	lock->lock_id = lock_id;
	lock->is_locked = false;

	lock->waiting_processes = LL_new();

	return lock;
}

// This function deleted the lock by deleting the linked list 
// holding its waiting processes and frees the lock itself
void KillLock(void *lock) {
	TracePrintf(1, "KillLock\n");
	lock_t *lock_delete = (lock_t *) lock;
	LL_kill(lock_delete->waiting_processes, KillPCB);
	free(lock_delete);
}