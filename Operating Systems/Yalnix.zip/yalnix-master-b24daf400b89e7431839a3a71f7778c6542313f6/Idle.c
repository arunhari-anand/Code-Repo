/*
* Idle.c; the idle process
*/

#include <hardware.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
     while (true) {
        TracePrintf(2, "Pause loop in idle()!\n");
        Pause();
    }
}

