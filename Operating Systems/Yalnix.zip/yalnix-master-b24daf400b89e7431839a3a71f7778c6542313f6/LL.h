/*
* LL.h - contains all of the functions necessary to manage the Linked List
* 
* The Memory Men
* Arun Hari Anand, Raunak Bhojwani
*
* October 2017
*/


#ifndef __LL_H
#define __LL_H

typedef struct LL_node {
	int id;
	void *info;

	struct LL_node *next;
	struct LL_node *prev;
} LL_node;

typedef struct LL_ {
	LL_node *head;
	LL_node *tail;
} LL;

LL *LL_new();

int LL_add(LL *linked_list, void *item, int key);

LL_node *LL_search(LL *linked_list, int id);

LL_node *LL_delete(LL *linked_list, int id);

LL_node *LL_pop(LL *linked_list);

bool LL_empty(LL *linked_list);

void LL_kill(LL *linked_list, void (*itemdelete)(void *item));

// bool LL_equals(LL_node *node_1, LL_node *node_2);

#endif