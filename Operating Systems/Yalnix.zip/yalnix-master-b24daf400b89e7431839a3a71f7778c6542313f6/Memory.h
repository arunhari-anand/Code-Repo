/*
* Memory.h - contains all of the functions necessary to handle page tables and setting the privileged registers relevant
* to memory, such as REGPTBR0.
*
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* October 2017
*/


#ifndef __MEMORY_H
#define __MEMORY_H

void setup_pt_r0();
void create_pt_r1(pcb_t *p);
void setup_kernelstack(pcb_t *p);
void initializeInit(unsigned int pmem_size, UserContext *uctxt, char* cmd_args[]);
int allocate_frame(int pfn);
int deallocate_frame(unsigned int pfn);
void delete_pt_r1(pcb_t *proc);
int setup_new_pt_r1(pcb_t *proc, unsigned int prot_new, unsigned int pages, unsigned int start);
int modify_pt_r1_prot(pcb_t *proc, unsigned int new_prot, unsigned int pages, unsigned int start);
int clone_address_space(pcb_t *source, pcb_t *dest);
int grow_heap(pcb_t *process, int new_break);
int shrink_heap(pcb_t *process, int new_break);
void free_r0_frames(pcb_t *process);
void free_r1_frames(pcb_t *process);
void setup_idle_kernelstack(pcb_t *p);
int clone_kernelstack(pcb_t *source, pcb_t *dest);

//the TLB will be flushed; if value is 0 then region 0 will be flushed, if value is 1 then region 1 will be flushed, and if value is -1 then the whole tlb will be flushed
void flush_tlb(int value);

#endif