/*
* Kernel.c - contains all of the functions necessary to manage the kernel and start it up, 
* including KernelStart(), SetKernelData(), etc.
*
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
* November 2017
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Kernel.h"
#include "include/hardware.h"
#include "include/yalnix.h"
#include "PCB.h"
#include "Cvar.h"
#include "Syscalls.h"
#include "LL.h"
#include "LoadProgram.h"
#include "Lock.h"
#include "Memory.h"
#include "Pipe.h"

// declare the context_switch_helper method that is passed into KernelContextSwitch
KernelContext *context_switch_helper(KernelContext * kernel_state_arg, void *old_pcb_arg, void *new_pcb_arg);

/* SetKernelData initializes the global variables KernelDataStart and KernelDataEnd
 * And finds the starting page and the break page for the Kernel
 */
void SetKernelData(void * KernelDataStart_arg, void * KernelDataEnd_arg){
  TracePrintf(1, "SetKernelData\n");
  KernelDataStart = (unsigned int) KernelDataStart_arg;
  KernelDataEnd = (unsigned int) KernelDataEnd_arg;
  kernel_break = ((((unsigned int) KernelDataEnd) - 1) >> PAGESHIFT) + 1;
  kernel_data_base_page = ((unsigned int) KernelDataStart) >> PAGESHIFT;
}

/* This procedure will use several helper methods, one for each of the 
 * major processes that need to be conducted while the Kernel starts.
 */
void KernelStart(char *cmd_args[], unsigned int pmem_size, UserContext *uctxt){
  TracePrintf(1, "KernelStart\n");
  unsigned int addr = 0x00028000;
  TracePrintf(1, "%d\n", addr >> PAGESHIFT);
  int i;

  // set up the interrupt vector
  for(i = 0; i<TRAP_VECTOR_SIZE; i++){
    interrupt_vector[i] = &undefined_trap;
  }

  // initialize the various handlers in the interrupt vector
  interrupt_vector[TRAP_KERNEL] = (void *) &kernel_handler;
  interrupt_vector[TRAP_CLOCK] = (void *) &clock_handler;
  interrupt_vector[TRAP_ILLEGAL] = (void *) &illegal_handler;
  interrupt_vector[TRAP_MEMORY] = (void *) &memory_handler;
  interrupt_vector[TRAP_MATH] = (void *) &math_handler;
  interrupt_vector[TRAP_TTY_RECEIVE] = (void *) &tty_transmit_handler;
  interrupt_vector[TRAP_TTY_TRANSMIT] = (void *) &tty_receive_handler;

  // write the base adress of the interrupt vector to REG_VECTOR_BASE register
  WriteRegister(REG_VECTOR_BASE, (unsigned int) interrupt_vector);

  // set up the linked list that keeps a track of all free frames in physical memory
  // also initialize linked lists to store locks, semaphores, cvars and pipes
  initialize_kernel_bookkeeping(cmd_args, pmem_size, uctxt);

  TracePrintf(2, "About to initialize idle process\n");

  // initialize the idle process using a helper method; this will also set up the 
  // region 0 pagetable as well as the region 1 pagetable and kernel stack for the process
  idle_process = initialize_idle_process(cmd_args, uctxt);


  // load the idle process' kernel stack into the region 0 page table
  unsigned int n;
  for (n = 0; n<KERNEL_STACK_MAXSIZE/PAGESIZE; n++){
    TracePrintf(2, "PT_R0: address %d\n", (((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT)+n);
    pt_r0[(((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT)+n] = idle_process->kernel_stack[n];
  }

  // write the TLB for the region 0 page table
  WriteRegister(REG_PTBR0, (unsigned int) pt_r0);
  //WriteRegister(REG_PTBR1, (unsigned int) pagetable_region1);
  WriteRegister(REG_PTLR0, (VMEM_0_SIZE/PAGESIZE));
  //WriteRegister(REG_PTLR1, (unsigned int) pagetable_region1->limit);

  // write the TLB for the region 1 page table
  WriteRegister(REG_PTBR1, (unsigned int) idle_process->pt_r1);
  WriteRegister(REG_PTLR1, (VMEM_1_SIZE/PAGESIZE));

  // enable virtual memory and write to the REG_VM_ENABLED register
  TracePrintf(2, "About to enable vm\n");
  WriteRegister(REG_VM_ENABLE, 1);
  TracePrintf(2, "Enabled vm\n");
  is_vmem_enabled = true;

  // make the idle_process the current process
  current_process = idle_process;

  // load the idle process
  char *args[2];
  args[0] = NULL;
  LoadProgram("Idle", args, idle_process);

  // set the name of the init process, name it "init" if NULL
  char *init_name = "init";
  if (cmd_args[0] != NULL){
   init_name = cmd_args[0];
 }

 TracePrintf(1, "About to initialize init pcb");

 // initialize a new PCB for the init process
 pcb_t *init_process = InitializeNewPCB(current_pid);
 current_pid++;

 // create the region 1 page table for the init process and set up its kernel stack
 create_pt_r1(init_process);
 setup_kernelstack(init_process);


 TracePrintf(1, "initialized init pcb");
 TracePrintf(1, "idle process = %p, init process = %p\n", idle_process, init_process);

 //unsigned int n; TAKE A LOOK AT THIS
 // load the idle process' kernel stack into the region 0 page table
  for (n = 0; n<KERNEL_STACK_MAXSIZE/PAGESIZE; n++){
    TracePrintf(2, "PT_R0: address %d\n", (((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT)+n);
    pt_r0[(((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT)+n] = idle_process->kernel_stack[n];
  }

  TracePrintf(1, "About to LOAD init program");

  // write the init process' page table to the register
  WriteRegister(REG_PTBR1, (unsigned int) init_process->pt_r1);
  // flush the TLB
  WriteRegister(REG_TLB_FLUSH, TLB_FLUSH_1);
  // load the init process
  LoadProgram(init_name, cmd_args, init_process);


  for (n = 0; n<KERNEL_STACK_MAXSIZE/PAGESIZE; n++){
    TracePrintf(2, "PT_R0: address %d\n", (((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT)+n);
    pt_r0[(((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT)+n] = idle_process->kernel_stack[n];
  }

  // set the current process as the isle process, and write to the registr before flushing TLB
  current_process = idle_process;
  WriteRegister(REG_PTBR1, (unsigned int) idle_process->pt_r1);
  WriteRegister(REG_TLB_FLUSH, TLB_FLUSH_1);

  // add the init process to the ready queue
  LL_add(ready, init_process, init_process->pid);

  // make use of the idle process' user context
  *uctxt = idle_process->user_state;
  idle_process->is_kc_initialized = true;

  TracePrintf(2, "done with ks!");
}

/* This method ensures that all pages from VMEM_BASE to addr are valid
 */
int SetKernelBrk(void * addr){
  TracePrintf(1, "SetKernelBrk\n");
  int rc = 0;
  // Ensure that we are within the bounds of the kernel stack
  if (((unsigned int) addr >> PAGESHIFT) >= (DOWN_TO_PAGE(KERNEL_STACK_BASE) >> PAGESHIFT)){
    TracePrintf(1, "Error setting kernel break - illegal address");
    return ERROR;
  }

  unsigned int new_kernel_break = (((unsigned int) addr-1) >> PAGESHIFT)+1;

  // if virtual memory is enabled
  if (is_vmem_enabled){
    // if the new break is after the kernel break, grow the kernel heap
    if (new_kernel_break > kernel_break){
      int page;
      for (page = kernel_break; page<new_kernel_break && page<(((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT); page++){
        if (page >= (VMEM_0_LIMIT/PAGESIZE) || pt_r0[page].valid == 1){
          return ERROR;
        }
        else{
          pt_r0[page].pfn = allocate_frame(-1);
          pt_r0[page].valid = 1;
          pt_r0[page].prot = PROT_READ | PROT_WRITE;
        }
      }
    }
    // else, shrink the kernel heap
    else if (new_kernel_break<kernel_break){
      int page;
      for (page = kernel_break-1; page>= new_kernel_break; page--){
        if (page<(((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT)){
          deallocate_frame(pt_r0[page].pfn);
          pt_r0[page].valid = 0;
        }
      }
    }

  }
  
  kernel_break = new_kernel_break;
  return 0;

  
}

/* This method sets up a linked list of all the free frames in physical
 *  memory, and also creates linked lists for the ready queue, and all the relevant lists required
 */
void initialize_kernel_bookkeeping(char *cmd_args[], unsigned int pmem_size, UserContext *uctx){
  
  //create structure to keep track of frames in physical memory  
  TracePrintf(1, "initialize_kernel_bookkeeping\n");
  int num_physical_frames = pmem_size/PAGESIZE;
  free_frames = LL_new();


  int frame_limit = ((pmem_size + PMEM_BASE) >> PAGESHIFT) - 1;


  //create frame_t's for all of the free frames that have yet to be allocated.

  int i;
  for (i = kernel_break + 1; i < (((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT); i++) {
    frame_t *fr = (frame_t *) (malloc(sizeof(frame_t)));
    fr->pfn = i;
    LL_add(free_frames, fr, i);
  }

 
  for (i = (((unsigned int) KERNEL_STACK_LIMIT) >> PAGESHIFT) + 1; i <= frame_limit; i++) {
    frame_t *fr = (frame_t *) (malloc(sizeof(frame_t)));
    fr->pfn = i;
    LL_add(free_frames, fr, i);
  }

  // int n;
  // for (n =0; n<=num_physical_frames; n++){

  //   frame_t *fr = (frame_t *) (malloc(sizeof(frame_t)));
  //   fr->pfn = n;
    

  //   LL_add(free_frames, fr, n);
  // }

  // create linked lists for ready queue, waiting processes and terminated processes
  ready = LL_new();
  waiting = LL_new();
  terminated = LL_new();

  // create linked lists for blocked processes due to cvars, locks, clocks
  cvar_blocked = LL_new();
  lock_blocked = LL_new();
  clock_blocked = LL_new();
  waiting_on_children = LL_new();

  // create an LL for locks, sems, cvars and pipes
  pcbs = LL_new();
  locks = LL_new();
  cvars = LL_new();
  pipes = LL_new();
  semophores = LL_new();


  //setup_pagetable_region0();

  //initializeInit(pmem_size, uctxt, cmd_args[]);


}


/* This method initilizes a new process (PCB) for idle, and assigns
 * it the user context. It proceeds by setting up the region 1 and 
 * region 0 page-tables and also the kernel stack for the idle process.
 */
pcb_t *initialize_idle_process(char *cmd_args[], UserContext *uctxt){
  TracePrintf(1, "initialize_idle_process\n");
  pcb_t *idle = InitializeNewPCB(current_pid);
  current_pid++;
  //memcpy(&idle->user_state, &uctxt, sizeof(UserContext));
  idle->user_state = *uctxt;
  TracePrintf(2, "About to create the region 1 page table\n");
  create_pt_r1(idle);
  TracePrintf(2, "About to create the kernel stack\n");
  setup_pt_r0();
  setup_idle_kernelstack(idle);
  return idle;  
  
}

// method to get the current process
pcb_t *get_current_process(){
  TracePrintf(1, "get_current_process\n");
  return current_process;
}

// method to switch processes at regular time intervals
int switch_process(int switch_proc, pcb_t *next_process, UserContext *user_state_arg){
  if (switch_proc == NEXT_PROCESS){
    TracePrintf(1, "switch_process - next process\n");
  }
  else{
    TracePrintf(1, "switch process - new process\n");
  }
  
  // if switching to next process on the ready queue, pop from the queue
  if (switch_proc == NEXT_PROCESS){
    next_process = (pcb_t *) (LL_pop(ready))->info;
    if (next_process == NULL){
      // if nothing in the ready queue, divert to the idle process
      next_process = idle_process;
      TracePrintf(1, "Switching into idle");
    }
  }

  // update the user context of the current process
  current_process->user_state = *user_state_arg;
  //*user_state_arg = *next_process->user_state;

  // write to the register the region 1 page table of the next process and then flush the TLB
  WriteRegister(REG_PTBR1, (unsigned int) next_process->pt_r1);
  flush_tlb(1);

  // update the current process and switch contexts from previous to next, 
  // with the global current process update appropriately
  pcb_t *prev_process = current_process;
  current_process = next_process;
  KernelContextSwitch(&context_switch_helper, prev_process, next_process);
  *user_state_arg = current_process->user_state;

}

/*This is a helper method that is passed to KernelContextSwitch
 */
KernelContext *context_switch_helper(KernelContext *kernel_state_arg, void *old_pcb_arg, void *new_pcb_arg){
  TracePrintf(1, "context_switch_helper\n");

  // Extract both the old and new PCBs
  pcb_t *old_pcb = (pcb_t *) old_pcb_arg;
  pcb_t *new_pcb = (pcb_t *) new_pcb_arg;

  // initialize the kernel stack of the new process and clone 
  // the kernel stack of the old process into the kernel stack of 
  // the new process
  old_pcb->kernel_state = *kernel_state_arg;
  if (!new_pcb->is_kc_initialized) {
        TracePrintf(1, "Initializing the Kernel Context for a process\n");
        //new_pcb->kernel_state = malloc(sizeof(KernelContext));
        //memcpy(new_pcb->kernel_state, old_pcb->kernel_state, sizeof(KernelContext));
        new_pcb->kernel_state = old_pcb->kernel_state;
        clone_kernelstack(old_pcb, new_pcb);
        new_pcb->is_kc_initialized = true;
        int k;
        for (k = 0; k<2; k++){
          TracePrintf(1, "%d\n", new_pcb->kernel_stack[k].pfn);
        }
    }

  // load the new process' kernel stack into the region 0 page table
  unsigned int n;
  for (n = 0; n<KERNEL_STACK_MAXSIZE/PAGESIZE; n++){
    //TracePrintf(2, "PT_R0: address %d\n", (((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT)+n);
    pt_r0[(((unsigned int) KERNEL_STACK_BASE) >> PAGESHIFT)+n] = new_pcb->kernel_stack[n];
  }

  //flush_tlb(-1);
  TracePrintf(1, "%s\n", "Returning the new PCB's kernel state");
  return &new_pcb->kernel_state;
}

/* This is the handler method for TRAP_MEMORY
 */
void memory_handler(UserContext *uctxt){
  TracePrintf(1, "memory_handler\n");
  // check if the address of the user context has strayed off bounds, exit if it has
  unsigned int address = (unsigned int) uctxt->addr;
  if (address>VMEM_1_LIMIT || address<VMEM_1_BASE){
    SysExit(ERROR, uctxt);
  }
  // if not, find the lowest page of the current process and allocate frames
  else{
    pcb_t *current_process = get_current_process();
    unsigned int page = (((unsigned int)current_process->lowest_stack_address) >> PAGESHIFT) - 1;
    while (page >= (((unsigned int) uctxt->addr - VMEM_1_BASE) >> PAGESHIFT)){
      int pfn = allocate_frame(-1);
      if (pfn != ERROR){
        // set the validity of the page
        current_process->pt_r1[current_process->lowest_stack_address-1].valid = 1;
        page--;
      }
    }
    current_process->lowest_stack_address = (((unsigned int) uctxt->addr - VMEM_1_BASE) >> PAGESHIFT);
  }
}

/* This is the handler method for undefined trap handlers
 */
void undefined_trap(UserContext *uctxt){
  TracePrintf(1, "undefined trap!\n");
  SysExit(ERROR, uctxt);
}

/* This is the handler method for TRAP_KERNEL
 * Take an appropriate action for each of the user context codes
 */
void kernel_handler(UserContext *uctxt){
  TracePrintf(1, "kernel_handler\n");
  int rc;
  switch(uctxt->code) {
    case YALNIX_FORK:
    rc = SysFork(uctxt);
    break;
    case YALNIX_EXEC:
    rc = SysExec((char *) uctxt->regs[0], (char **) uctxt->regs[1], uctxt);
    break;
    case YALNIX_EXIT:
    rc = SysExit(uctxt->regs[0], uctxt);
    break;
    case YALNIX_WAIT:
    rc = SysWait((int *) uctxt->regs[0], uctxt);
    break;
    case YALNIX_GETPID:
    rc = SysGetPid();
    break;
    case YALNIX_BRK:
    rc = SysBrk((void *) uctxt->regs[0]);
    break;
    case YALNIX_DELAY:
    rc = SysDelay(uctxt->regs[0], uctxt);
    break;
    case YALNIX_TTY_READ:
    rc = SysTtyRead(uctxt->regs[0], (void *) uctxt->regs[1], uctxt->regs[2], uctxt);
    break;
    case YALNIX_TTY_WRITE:
    rc = SysTtyWrite(uctxt->regs[0], (void *) uctxt->regs[1], uctxt->regs[2], uctxt);
    break;
    default:
    rc = ERROR;
    SysExit(ERROR, uctxt);
    break;
  }

  uctxt->regs[0] = rc;

}

/* This is the handler method for TRAP_CLOCK, activated at regular time intervals
 */
void clock_handler(UserContext *uctxt){
  TracePrintf(1, "clock_handler\n");
  LL_node *proc;
  // for each process blocked by the clock, decrement its wait time, and if the wait 
  // time is 0, delete it from clock_blocked and add it to the ready queue
  for(proc = clock_blocked->head; proc != NULL; proc = proc->next) {
    pcb_t *process = (pcb_t *) proc->info;
    --process->wait_time;
    if(process->wait_time <= 0) {
      LL_delete(clock_blocked, process->pid);
      LL_add(ready, process, process->pid);
    }
  }

  if(current_process->pid != idle_process->pid) {
    LL_add(ready, current_process, current_process->pid);
  }

  //switch process to the next process on the ready queue
  switch_process(NEXT_PROCESS, NULL, uctxt);

}

/* This is the handler method for TRAP_ILLEGAL, simply exits
 */
void illegal_handler(UserContext *uctxt){
  TracePrintf(1, "illegal_handler\n");
  SysExit(ERROR, uctxt);
}

/* This is the handler method for TRAP_MATH, simply exits
 */
void math_handler(UserContext *uctxt){
  TracePrintf(1, "math_handler\n");
  SysExit(ERROR, uctxt);
}

/* This is the handler method for TRAP_TTY_TRANSMIT
 */
void tty_transmit_handler(UserContext *uctxt){
  TracePrintf(1, "tty_transmit_handler\n");
  int tty_code = uctxt->code;

  //retrieve the termstate
  termstate_t *termstate = tty_array[tty_code];
  pcb_t *waiting_process;


  if (!LL_empty(termstate->w_transmit)) {
    //retrieve the waiting process from the termstate transmit list, it will be the head node
    waiting_process = (pcb_t *) termstate->w_transmit->head->info;
    if (waiting_process->write_length > TERMINAL_MAX_LINE) {

      waiting_process->write_buffer += TERMINAL_MAX_LINE;
      waiting_process->write_length -= TERMINAL_MAX_LINE;

      // Transmit whatever is smaller, write_length or the TERMINAL_MAX_LINE
      if (TERMINAL_MAX_LINE > waiting_process->write_length) {
        TtyTransmit(tty_code, waiting_process->write_buffer, waiting_process->write_length);
      }
      else {
        TtyTransmit(tty_code, waiting_process->write_buffer, TERMINAL_MAX_LINE);
      }
      return;
    }
  }

  // Once it has transmitted, the process can be removed from the w_transmit list
  // and added to the ready queue
  LL_delete(termstate->w_transmit, waiting_process->pid);
  LL_add(ready, waiting_process, waiting_process->pid);

  if (LL_empty(termstate->w_transmit)) {
    return;
  }

  // if there are more processes that need to transmit, do the next one
  pcb_t *next_tramission = (pcb_t *) termstate->w_transmit->head->info;
  if (TERMINAL_MAX_LINE > next_tramission->write_length) {
    TtyTransmit(tty_code, next_tramission->write_buffer, next_tramission->write_length);
  }
  else{
    TtyTransmit(tty_code, next_tramission->write_buffer, TERMINAL_MAX_LINE);
  }
}

/* This is the handler method for TRAP_TTY_RECEIVE
 */
void tty_receive_handler(UserContext *uctxt){
  TracePrintf(1, "tty_receive_handler\n");
  // extract the user context code and get the appropriate termstate
  int tty_code = uctxt->code;
  termstate_t *termstate = tty_array[tty_code];

  // if there are no processes waiting
  if (LL_empty(termstate->w_read)) {
    // create the buffer to receive into and add that into the list of lines
    char *buffer = (char *) (LL_pop(termstate->lines)->info);
    buffer = malloc(sizeof(char) * TERMINAL_MAX_LINE);
    TtyReceive(tty_code, buffer, TERMINAL_MAX_LINE);
    LL_add(termstate->lines, buffer, tty_code);
  }
  else {
    // allocate memory to receive
    char *to_read = malloc(sizeof(char) * TERMINAL_MAX_LINE);
    char *mid = to_read;
    int read_len = TtyReceive(tty_code, to_read, TERMINAL_MAX_LINE);
    int remaining = read_len;

    // loop until there are either no more processes waiting or no more input to be received
    while (!LL_empty(termstate->w_read) && read_len > 0) {
      // reenter the process waiting into the ready queue
      pcb_t *waiting_process = (pcb_t *) (LL_pop(termstate->w_read))->info;
      LL_add(ready, waiting_process, waiting_process->pid);

      if (read_len <= waiting_process->read_length) {
        // read all of the input at once
        memcpy(waiting_process->read_buffer, mid, remaining);
        waiting_process->read_length = remaining;
        remaining = 0;
      }

      else {
        // read some of the input now, and continue iterating
        memcpy(waiting_process->read_buffer, mid, waiting_process->read_length);
        remaining -= waiting_process->read_length;
        mid += waiting_process->read_length;
      }
    }

    if (remaining > 0) {
      // if there is input after all the processes have received then tore this input and 
      // add it to the list of lines in the termstate
      char *rem_buffer = malloc(remaining * sizeof(char));
      memcpy(rem_buffer, mid, remaining);

      LL_add(termstate->lines, rem_buffer, tty_code);
    }
  }
}