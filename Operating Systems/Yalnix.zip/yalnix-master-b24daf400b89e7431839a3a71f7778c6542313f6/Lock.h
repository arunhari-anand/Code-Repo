/*
* Lock.h - contains all of the functions necessary to manage locks in the Yalnix kernel
*
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* November 2017
*/

#include "LL.h"

// Lock data structure stores its id, the pid of the process 
// that holds it, a boolean indicating whether it is locked, 
// and a linked list of all the processes waiting for the lock 
typedef struct Lock {
	int lock_id;
	int pid;

	bool is_locked;

	LL *waiting_processes;
} lock_t;


// Initializes the lock 
lock_t *InitializeNewLock(int lock_id);

// Deletes the lock
void KillLock(void *lock);