/*
* Cvar.c - contains all of the logic necessary to implement condition variables
* Uses a linked list data structure to implement mesa-style locks
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* November 2017
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Kernel.h"
#include "../include/hardware.h"
#include "PCB.h"
#include "Cvar.h"
#include "LL.h"
#include "LoadProgram.h"
#include "Lock.h"
#include "Memory.h"
#include "Pipe.h"

/* This method initializes a new condition variable, 
 * allocating it some memory, giving it its requisite id, 
 * and then setting up a new linked list for the processes 
 * waiting on this cvar.
 */
cvar_t *InitializeNewCvar(int cvar_id){
	TracePrintf(1, "InitializeNewCvar\n");
	cvar_t *new_cvar = malloc(sizeof(cvar_t));

	new_cvar->cvar_id = cvar_id;
	new_cvar->waiting_processes = LL_new();

	return new_cvar;
}

/* This method deletes the cvar passed to it by killing
 * the linked list of its stored waiting processes and 
 * then freeing the cvar itself.
 */
void KillCvar(void *cvar) {
	TracePrintf(1, "KillCvar\n");
	cvar_t *cvar_delete = (cvar_t *) cvar;
	LL_kill(cvar_delete->waiting_processes, KillPCB);
	free(cvar_delete);
}
