/*
* Init.c; the initial process
*/

#include <hardware.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
     while (true) {
        TracePrintf(2, "Pause loop in init()!\n");
        Pause();
    }
}

