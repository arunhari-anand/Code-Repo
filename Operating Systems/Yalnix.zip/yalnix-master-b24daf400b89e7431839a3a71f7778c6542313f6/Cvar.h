/*
* Cvar.h - contains all of the function headers necessary for condition variables
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* November 2017
*/

#include "LL.h"

/*
 * This struct defines a condition variable, and it comprises
 * of an int that stores the id of the cvar, and a linked list
 * that holds all the processes waiting on the condition variable
 */

typedef struct CVar {
	int cvar_id;
	LL *waiting_processes;
} cvar_t;

//This method initializes a new condition variable
cvar_t *InitializeNewCvar(int cvar_id);

//This method frees a cvar and its components
void KillCvar(void *cvar);