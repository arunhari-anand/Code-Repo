/*
* LoadProgram.h - contains all of the functions to load a program into the hardware 
*
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* October 2017
*/


#ifndef __LOADPROGRAM_H
#define __LOADPROGRAM_H

#include "PCB.h"

int LoadProgram(char *name, char *args[], pcb_t *proc);

#endif