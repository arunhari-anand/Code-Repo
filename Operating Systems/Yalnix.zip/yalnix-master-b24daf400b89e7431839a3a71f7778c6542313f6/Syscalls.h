


#ifndef __SYSCALLS_H
#define __SYSCALLS_H

#include "include/hardware.h"

int SysFork(UserContext *user_state_arg);

int SysExec(char *filename, char **argvec, UserContext *user_state_arg);

int SysExit(int status, UserContext *user_state_arg);

int SysWait(int *status_ptr, UserContext *user_state_arg);

int SysGetPid(void);

int SysBrk(void *address);

int SysDelay(int clock_ticks, UserContext *user_state_arg);

int SysTtyRead(int tty_id, void *buf, int len, UserContext *user_state_arg);

int SysTtyWrite(int tty_id, void *buf, int len, UserContext *user_state_arg);

int get_true_len(char *str);

int SysLockInit(int *lock_idp);

int SysAcquire(int lock_id, UserContext *user_state_arg);

int SysRelease(int lock_id);

int SysCvarInit(int *cvar_idp);

int SysCvarSignal(int cvar_id);

int SysCvarBroadcast(int cvar_id);

int SysCvarWait(int cvar_id, int lock_id, UserContext *user_state_arg);

int SysReclaim(int id);

int SysPipeWrite(int pipe_id, void *buf, int len, UserContext *user_state);

int SysPipeRead(int pipe_id, void *buf, int len, UserContext *user_state);

int SysPipeInit(int *pipe_idp);

#endif
