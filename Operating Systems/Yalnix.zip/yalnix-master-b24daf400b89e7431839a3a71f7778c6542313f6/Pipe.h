/*
* Pipe.h - contains all of the data structures and functions required to implement pipes in the operating system
*
* The Memory Men
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* November 2017
*/

#ifndef __PIPE_H
#define __PIPE_H

typedef struct pipe {
	int pipe_id;

	int current_buffer_size;
	int buffer_length_remaining;

	void *buf;
	void *first_free;

	LL *waiting_to_read;

} pipe_t;


pipe_t *new_pipe();

int pipe_copy(pipe_t *p, void *buf, int len);

int pipe_write(pipe_t *p, void *buf, int len);

void kill_pipe(void *p);

#endif
