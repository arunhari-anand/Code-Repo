/*
* Kernel.h - contains all of the functions necessary to manage the kernel and start it up, 
* including KernelStart(), SetKernelData(), etc.
* 
* The Memory Men
* Arun Hari Anand, Raunak Bhojwani
*
* Written using class materials provided by Prof. Smith
*
* October 2017
*/

#ifndef __KERNEL_H
#define __KERNEL_H

#include "include/hardware.h"
#include "Syscalls.h"
#include "PCB.h"

#define KILL -9999
#define SUCCESS 15
#define MAX_PROC_NAME_LEN 100
#define NEW_PROCESS 101
#define NEXT_PROCESS 102

typedef struct termstate{
	LL *lines;
	LL *w_read;
	LL *w_transmit;
} termstate_t;

pcb_t *idle_process; //holds a reference to the pcb for an idle process
pcb_t *current_process;
pcb_t *init_process;
unsigned int KernelDataStart;
unsigned int KernelDataEnd;
unsigned int kernel_break;
unsigned int kernel_data_base_page;
LL *free_frames;
LL *allocated_frames;
int current_pid;
LL *pcbs;
LL *locks;
LL *cvars;
LL *pipes;
LL *semophores;
//void *top_of_kernel_heap;
struct pte pt_r0[MAX_PT_LEN];
LL *ready;
LL *waiting;
LL *terminated;
LL *cvar_blocked;
LL *lock_blocked;
LL *clock_blocked;
LL *waiting_on_children;
termstate_t *tty_array[NUM_TERMINALS];

void (*interrupt_vector[TRAP_VECTOR_SIZE])(UserContext *); 
bool is_vmem_enabled;
unsigned int next_lock;
unsigned int next_pipe;


typedef struct frame {
  int pfn;
  //int in_use;
  //int pid;
} frame_t;

void SetKernelData(void * KernelDataStart, void * KernelDataEnd);
void KernelStart(char *cmd_args[], unsigned int pmem_size, UserContext *uctxt);
int SetKernelBrk(void * addr);
void initialize_kernel_bookkeeping(char *cmd_args[], unsigned int pmem_size, UserContext *uctx);
pcb_t *initialize_idle_process(char *cmd_args[], UserContext *uctxt);
pcb_t *get_current_process();

KernelContext *context_switch_helper(KernelContext * kernel_state_arg, void *old_pcb_arg, void *new_pcb_arg);

void memory_handler(UserContext *uctxt);
void undefined_trap(UserContext *uctxt);
void kernel_handler(UserContext *uctxt);
void clock_handler(UserContext *uctxt);
void illegal_handler(UserContext *uctxt);
void math_handler(UserContext *uctxt);
void tty_transmit_handler(UserContext *uctxt);
void tty_receive_handler(UserContext *uctxt);

// void setup_pagetable_region0(pcb_t *p);
// void create_pt_r1(pcb_t *p);
// void setup_kernelstack(pcb_t *p);
// void initializeInit(unsigned int pmem_size, UserContext *uctxt, char* cmd_args[]);
// int allocate_frame(unsigned int pfn);
// int deallocate_frame(unsigned int pfn);
// void delete_pt_r1(pcb_t *proc);
// int setup_new_pt_r1(pcb_t *proc, unsigned int prot, unsigned int pages; unsigned int start);
// int modify_pt_r1_prot(pcb_t *proc, unsigned int new_prot, unsigned int pages, unsigned int start);

#endif
