import java.util.*;
import java.io.*;
import javax.swing.*;

public class HW8{
	public static void main(String[] args) {
		int associativity;
		int split;
		Scanner user_input = new Scanner(System.in);
		System.out.println("What is the associativity of the cache?");
		associativity = user_input.nextInt();
		System.out.println("Enter 0 for a unified cache and 1 for a split cache");
		split = user_input.nextInt();
		
		//Change the length of these arrays according to the number of entries on the textfile
		String [] identifiers = new String [6346078]; //array for storing the identifiers at the beginning of each line in the textfile
		Long [] access_addresses = new Long [6346078];//array for storing all the access requests
		read(identifiers, access_addresses);//puts all the identifiers and addresses into the respective arrays
		if (associativity==1 && split == 0)
			System.out.println("tagmask = 0xfffffc00\nsetmask = 0x000003f0\n64 blocks, 16 bytes in block; 64 sets, 1 line per set");
		else if (associativity==2 && split == 0)
			System.out.println("tagmask = 0xfffffe00\nsetmask = 0x000001f0\n64 blocks, 16 bytes in block; 32 sets, 2 lines per set");
		else if (associativity==4 && split == 0)
			System.out.println("tagmask = 0xffffff00\nsetmask = 0x000000f0\n64 blocks, 16 bytes in block; 16 sets, 4 lines per set");
		else if (associativity==64 && split == 0)
			System.out.println("tagmask = 0xfffffff0\nsetmask = 0x00000000\n64 blocks, 16 bytes in block; 1 sets, 64 lines per set");
		else if (associativity==1 && split == 1)
			System.out.println("tagmask = 0xfffffe00\nsetmask = 0x000001f0\n32 blocks, 16 bytes in block; 32 sets, 1 lines per set");
		if (split == 0)
			access_unified_cache(associativity, split, access_addresses);//subroutine that handles unified caching
		else if (split == 1)
			access_split_cache(associativity, split, access_addresses, identifiers);//subroutine that handles the split caches
	}

	private static void read(String [] identifiers, Long[] access_addresses){
		int n = 0; // count of items read into array
		Scanner input = null;

		// Put up a file chooser window to select a file to read.
		JFileChooser chooser = new JFileChooser();
		int status = chooser.showOpenDialog(null);

		boolean fileOpened = true;    // OK unless proven otherwise

		do {
			// Get a file from the file chooser.  If the user hits the Cancel button,
			// end the program.
			while (status != JFileChooser.APPROVE_OPTION) {
				if (status == JFileChooser.CANCEL_OPTION)
					System.exit(0);
				else {
					System.out.println("No file chosen.  Try again.");
					status = chooser.showOpenDialog(null);
				}
			}
			// We have a file from the file chooser.  We should be able to create a
			// Scanner to read the file.
			File inputFile = chooser.getSelectedFile();
			try {
				input = new Scanner(inputFile);
			} catch (FileNotFoundException e) {
				fileOpened = false;
				System.out.println("Could not open file.  Try again.");
			}
		}
		while (!fileOpened);

		// Now the file has been opened.  Read it until we read the last address or
		// we've filled the array a.
		while (input.hasNext() && n < access_addresses.length && n< identifiers.length) {
			identifiers[n] = input.next();
			access_addresses[n] = input.nextLong(16);
			n++;
		}
		return;
	}


	/*Subroutine that extracts the tag alone from the address. 
	 * Uses a tagmask that depends on each separate caching scheme
	 */
	private static Long extract_tag(Long input, int associativity, int split){
		long tagmask = 0x0;
		int shifter = 9;
		if (split == 0){
			if (associativity == 1){
				tagmask = 0xfffffc00;
				shifter =10;
			}
			else if (associativity == 2){
				tagmask = 0xfffffe00;
				shifter = 9;
			}
			else if (associativity == 4){
				tagmask = 0xffffff00;
				shifter = 8;
			}
			else{
				tagmask = 0xfffffff0;
				shifter = 4;
			}	
		}
		else
			tagmask = 0xfffffe00;


		Long ret = (tagmask & input);
		ret = ret>>shifter;
//		System.out.format("%x", ret);
//		System.out.println("-ret");
//		System.out.println("Shifter = " + shifter);
//		System.out.format("%x", input);
//		System.out.println("-input");
		return ret;
	}


	/*Subroutine that extracts the tag alone from the address. 
	 * Uses a setmask that depends on each separate caching scheme
	 */
	private static Long extract_set(Long input, int associativity, int split){
		long setmask = 0x000003f0;
		int shifter = 4;
		if (split == 0){
			if (associativity == 1){
				setmask = 0x000003f0;
				shifter = 4;
			}
			else if (associativity == 2){
				setmask = 0x000001f0;
				shifter = 4;
			}
			else if (associativity == 4){
				setmask = 0x000000f0;
				shifter = 4;
			}
			else{
				setmask = 0x00000000;
				shifter = 0;
			}
		}
		else
			setmask = 0x000001f0;

		Long ret = (setmask & input);
		ret = ret>>shifter;	
//		System.out.format("%x", setmask);
//		System.out.println("-setmask");
		return ret;
	}

	/*
	 * subroutine that handles the unified cache
	 * 
	 */
	private static void access_unified_cache(int associativity, int split, Long [] access_addresses){
		int no_set =0;
		int misses = 0;//keeps track of the number of misses
		int hits = 0; //keeps track of the number of hits
		HashMap<Long, ArrayList<Line>> cache = new HashMap<Long, ArrayList<Line>>(); //this essentially represents the cache
		//The key is a set number and the value is an array list of "line" objects
		//Each Line object has a tag and a time of last access
		for (int i =0; i<access_addresses.length; i++){//access_addresses.length
			Boolean carryOn = true;//boolean value that is set to false if there is a hit and true if miss
			long tagbits = extract_tag(access_addresses[i], associativity, split);//extracts the tag alone from the address
			long set = extract_set(access_addresses[i], associativity, split); //extracts the set number alone from the address
			if (cache.containsKey(set)){ //we know that the set has valid lines in the cache
				ArrayList<Line> a = cache.get(set); //gets the list of lines associated with the set			
				int line_found = 0; //variable that keeps track of the line in which a specific tag value was found within the set
				for (Line x : a){//rotates through the lines in the set
					if (x.tag.equals(tagbits)){//if the line has the given tag then it is a hit
						hits++;
						carryOn=false;//indicating we have a hit and don't need to carry on with this this address any further
						x.time = i;//updates time
//						System.out.print(""+ (i+1) + ". Addr: ");
//						System.out.format("%x", access_addresses[i]);
//						System.out.print("; tag: ");
//						System.out.format("%x", tagbits);
//						System.out.print(", looking in set: ");
//						System.out.format("%d", set);
//						System.out.println("; Hit! Found it in line "+ line_found);	
						line_found++; //increments line by 1
					}
				}

				if (carryOn){//we didnt find the tag in the set, so it is a miss
					misses++;
					Line l1 = new Line();
					l1.tag = tagbits;
					l1.time = i; //we have made a new Line with the tagbits we want and have updated the time
					if (a.size() < associativity){//we have empty lines in the set
						a.add(l1);//add the missed line to the next empty line in the cache
//						System.out.print(""+ (i+1) + ". Addr: ");
//						System.out.format("%x", access_addresses[i]);
//						System.out.print("; tag: ");
//						System.out.format("%x", tagbits);
//						System.out.print(", looking in set: ");
//						System.out.format("%d", set);
//						System.out.println("; Miss! Added it to line "+ (a.size()-1));	
					}
					else {//we do not have empty lines in the set! we need to evict the lRU line
//						System.out.print(""+ (i+1) + ". Addr: ");
//						System.out.format("%x", access_addresses[i]);
//						System.out.print("; tag: ");
//						System.out.format("%x", tagbits);
//						System.out.print(", looking in set: ");
//						System.out.format("%d", set);
						no_set++;
						evict_LRU(a, l1);//subroutine that evicts the LRU line and adds l1 in its place
					}



				}
			}
			else {//the cache has no lines in the given set!
				misses++;
				ArrayList<Line> new_set = new ArrayList<Line>();//The new set to be added to the cache
				Line l1 = new Line();
				l1.tag = tagbits;
				l1.time = i; //make a new Line with the required tagbits and update the time
				new_set.add(l1);//add the the line to the set
				cache.put(set, new_set);//add the set to the cache
//				System.out.print(""+ (i+1) + ". Addr: ");
//				System.out.format("%x", access_addresses[i]);
//				System.out.print("; tag: ");
//				System.out.format("%x", tagbits);
//				System.out.print(", looking in set: ");
//				System.out.format("%d", set);
//				System.out.println("; Miss! Added it to line 0");	
			}
		}
		System.out.println("Hits = "+hits+ " and misses = " +misses);
	}
	/*
	 * Subroutine that evicts the LRU line and adds line to the set in its place
	 */
	private static void evict_LRU (ArrayList<Line> a, Line l1){
		int min_time = Integer.MAX_VALUE;
		for (Line x : a){
			if (x.time < min_time)
				min_time = x.time;
		}//determines the "time" value of the LRU line in the set
		int index=0;//"index" of the LRU line
		for (Line x : a){
			if (x.time == min_time){
				break;
			}
			index++;
		}
		a.remove(index);
		a.add(index, l1);
		//System.out.println(" Miss! Evicted line "+index+" and added there.");
	}
/*
 * Subroutine that handles the split cache
 * Does it very similar to the unified cache method, except it keeps
 * track of two caches, an i-cache and a d-cache
 */
	private static void access_split_cache(int associativity, int split, Long[] access_addresses, String[] identifiers) {
		int d_hits =0;
		int d_misses=0;
		int i_hits =0;
		int i_misses =0;
		int num_d=0;
		int num_i=0;
		HashMap<Long, ArrayList<Line>> icache = new HashMap<Long, ArrayList<Line>>();
		HashMap<Long, ArrayList<Line>> dcache = new HashMap<Long, ArrayList<Line>>();
		for (int i =0; i<access_addresses.length; i++){
			if (identifiers[i].equals("I"))
				num_i++;
			else
				num_d++;
			Boolean carryOn = true;
			Long tagbits = extract_tag(access_addresses[i], associativity, split);
			Long set = extract_set(access_addresses[i], associativity, split);

			if (icache.containsKey(set) && identifiers[i].equals("I")){

				ArrayList<Line> a = icache.get(set);
				int line_found = 0;
				for (Line x : a){
					if (x.tag.equals(tagbits)){
						i_hits++;
//						System.out.print("I"+ num_i+ ". Addr: ");
//						System.out.format("%x",access_addresses[i]);
//						System.out.print("; tag: ");
//						System.out.format("%x", tagbits);
//						System.out.print(", looking in set: ");
//						System.out.format("%d", set);
//						System.out.println("; Hit! Found it in line "+ line_found);	
						carryOn=false;
						x.time = i;
					}
					line_found++;
				}

				if (carryOn){
					i_misses++;
					Line l1 = new Line();
					l1.tag = tagbits;
					l1.time = i;
					if (a.size() < associativity){
						a.add(l1);
//						System.out.print("I"+ num_i+ ". Addr: ");
//						System.out.format("%x",access_addresses[i]);
//						System.out.print("; tag: ");
//						System.out.format("%x", tagbits);
//						System.out.print(", looking in set: ");
//						System.out.format("%d", set);
//						System.out.println("; Miss! Added it to line "+ (a.size()-1));	
					}
					else {
//						System.out.print("I"+ num_i+ ". Addr: ");
//						System.out.format("%x",access_addresses[i]);
//						System.out.print("; tag: ");
//						System.out.format("%x", tagbits);
//						System.out.print(", looking in set: ");
//						System.out.format("%d", set);
						evict_LRU(a, l1);
					}
				}
			}

			else if (dcache.containsKey(set) && identifiers[i].equals("D")){

				ArrayList<Line> a = dcache.get(set);
				int line_found =0;
				for (Line x : a){
					//System.out.println(x.tag + "  " + tagbits);
					if (x.tag.equals(tagbits)){
						d_hits++;
//						System.out.print("D"+ num_d+ ". Addr: ");
//						System.out.format("%x", access_addresses[i]);
//						System.out.print("; tag: ");
//						System.out.format("%x", tagbits);
//						System.out.print(", looking in set: ");
//						System.out.format("%d", set);
//						System.out.println("; Hit! Found it in line "+ line_found);	
						carryOn=false;
						x.time =i;
					}
					line_found++;
				}

				if (carryOn){
					d_misses++;
					Line l1 = new Line();
					l1.tag = tagbits;
					l1.time = i;
					if (a.size() < associativity){
						a.add(l1);
//						System.out.print("D"+ num_d+ ". Addr: ");
//						System.out.format("%x", access_addresses[i]);
//						System.out.print("; tag: ");
//						System.out.format("%x", tagbits);
//						System.out.print(", looking in set: ");
//						System.out.format("%d", set);
//						System.out.println("; Miss! Added it to line "+ (a.size()-1));	
					}
					else {
//						System.out.print("D"+ num_d+ ". Addr: ");
//						System.out.format("%x", access_addresses[i]);
//						System.out.print("; tag: ");
//						System.out.format("%x", tagbits);
//						System.out.print(", looking in set: ");
//						System.out.format("%d", set);
						evict_LRU(a, l1);
					}
				}
			}

			else {
				if (identifiers[i].equals("I"))
					i_misses++;
				else
					d_misses++;
				ArrayList<Line> new_set = new ArrayList<Line>();
				Line l1 = new Line();
				l1.tag = tagbits;
				l1.time = i;
				new_set.add(l1);
				if (identifiers[i].equals("D")){
					dcache.put(set, new_set);
//					System.out.print("D"+ (num_d) + ". Addr: ");
//					System.out.format("%x", access_addresses[i]);
//					System.out.print("; tag: ");
//					System.out.format("%x", tagbits);
//					System.out.print(", looking in set: ");
//					System.out.format("%d", set);
//					System.out.println("; Miss! Added it to line 0");	
				}
				else{
					icache.put(set, new_set);
//					System.out.print("I"+ (num_i) + ". Addr: ");
//					System.out.format("%x", access_addresses[i]);
//					System.out.print("; tag: ");
//					System.out.format("%x", tagbits);
//				  System.out.print(", looking in set: ");
//					System.out.format("%d", set);
//					System.out.println("; Miss! Added it to line 0");	
				}
			}
		}
		System.out.println("IHits = " + i_hits+ " and Imisses= "+ i_misses);
		System.out.println("DHits = " + d_hits+ " and Dmisses = "+ d_misses);
		System.out.println("Total hits = " + (i_hits+d_hits)+", and total misses = "+(i_misses+d_misses));
	}



	public static void printOutHashMap(HashMap<Long, ArrayList<Line>> cache){
		Set<Long> keys = cache.keySet();
		for (Long set:keys){
			for (Line l1: cache.get(set)){
				System.out.print ("Set "+set+", tag ");
				System.out.format("%x", l1.tag);
				System.out.println();
			}
		}
	}
}

















