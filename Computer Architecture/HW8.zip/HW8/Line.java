public class Line{
	public Line (){}
	public Long tag;
	public int time;
}