load wine.mat
X = [Xtrain; Xtest];
mu = mean(X,1); sigma = std(X,[],1);
Xtrain = (Xtrain - repmat(mu,size(Xtrain,1),1)) ./ repmat(sigma, size(Xtrain,1),1); 
Xtest = (Xtest - repmat(mu,size(Xtest,1),1)) ./ repmat(sigma, size(Xtest,1),1);

alphas = [0.1, 0.5, 1, 5];

hatYtest = randi(10,size(Xtest,1),1); % predicting by random guess test
error = cal_err_Ytest_wine(hatYtest); % evaluate the testing error


logprob_values = zeros(1, length(alphas));
Nfold = 2;
for n = 1:length(alphas)
    s = size(Xtrain, 1);
    errors = zeros(Nfold,1);
    indices=1:s;
    logprob_Vec = zeros(Nfold,1);
    training_set_x = Xtrain;
    training_set_y = Ytrain;
    for i=0:(Nfold-1)
        testing_interval = floor((s / Nfold * i) + 1) : floor((s / Nfold) * (i + 1));
        training_interval  = setdiff(indices,testing_interval);
        testing_set_x =  Xtrain(testing_interval, :);
        testing_set_y =  Ytrain(testing_interval);  
        training_set_x = Xtrain(training_interval, :);
        training_set_y = Ytrain(training_interval);  
        alpha = alphas(n);
        theta0 = zeros(3, size(Xtrain, 2));
        maxIter = 50
        theta = LogisticReg_LBFGS(training_set_x, training_set_y, alpha, theta0, maxIter);
    end
    theta = LogisticReg_LBFGS(testing_set_x, testing_set_y, alpha, theta0, maxIter);
    [neglogp, negDlogp] = LogisticReg_negloglikelihood(testing_set_x, testing_set_y, theta, alpha)
    logprob_values(1, n) = neglogp; 
end
[max_logprob, index] = max(logprob_values);
alpha = alphas(1, index)
theta = LogisticReg_LBFGS(Xtrain, Ytrain, alpha, theta0, maxIter);
[hatYtest, Pyx] = LogisticReg_predict(Xtest, theta);
cal_err_Ytest_wine(hatYtest)