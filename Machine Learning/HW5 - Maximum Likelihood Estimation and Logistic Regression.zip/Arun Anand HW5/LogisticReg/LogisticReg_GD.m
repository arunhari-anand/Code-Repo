function theta = LogisticReg_GD(X, Y,  alpha, theta0, stepsize, maxIter)
% Gradient descent for logistic regression
% Inputs: 
%   -- Xtrain (n X d): features
%   -- Ytrain (n X 1): labels, have to take values in {1,...,K}
%   -- alpha  (1 X 1): regularization coefficient
%   -- theta0 (K X d): initialization of the parameter (default = 0)
%   -- stepsize(1 X 1): the step size of the gradient update
%   -- maxIter(1 X 1): maximum number of gradient updates
% 
% Outputs: 
%   -- theta (K X d): the optimization result;
% 


% Please complete the code
theta = theta0;
mse_vec = zeros(maxIter, 1);
for i = 1:maxIter
    [neglogp, negDlogp] = LogisticReg_negloglikelihood(X, Y, theta, alpha);
    theta = theta - stepsize * negDlogp;
    mse_vec(i, 1) = neglogp;
    %... gradient update
end

%plot(1:maxIter, mse_vec);

