function [hatYtest, Pyx] = LogisticReg_predict(Xtest, theta)
% Making prediction in multi-class logistic regression 
% Inputs (n = #_of_data_points, d = #_of_features, K = #_of_classes): 
%    -- Xtest (n X d) features
%    -- theta  (K X d) parameters
%
% Outputs: 
%    -- hatYtest: (n X 1) the predicted labels (in the range of {1,...,K})
%    -- PyX: (n X K) the prediction probability p(y | x); Pyx(i,j) should
%    equal p(y_i = j | x_i). 



f = Xtest*theta';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Please complete the code here
n = size(Xtest,1);
K = size(theta,1);
prbs = zeros(n, K);
phi = logsumexp((theta*Xtest')');
hatYtest = zeros(n,1);
for i=1:n
    for k=1:K
        prbs(i,k) = exp(theta(k,:) * Xtest(i,:)' - phi(i,:));
    end
   [max_prob, index] = max(prbs(i,:));
   hatYtest(i) = index;
end

Pyx = prbs;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%