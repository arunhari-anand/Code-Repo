function[res] =  problem2()
x = [-5:0.025:5];
der = (((exp(x) + 1) .* exp(x))-(exp(x) .* exp(x)))./((exp(x)+1)).^2;

h = 10^-6;
fxh = exp(x+h)./(exp(x+h) + 1);
fxminus_h = exp(x-h)./(exp(x-h) + 1);
fx = exp(x)./(exp(x) + 1);
approx1 = (fxh-fxminus_h)/(2*h);
approx2 = (fxh-fx)/h;
hold on; plot(x, der), plot(x, approx1), plot(x, approx2)
