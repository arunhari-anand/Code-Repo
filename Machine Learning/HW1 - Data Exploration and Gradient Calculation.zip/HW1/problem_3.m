function[res] =  problem3()
clear all;
close all;
load('data/sales_example.mat')
a1 = sum(log(advertising_expense)-sales)/-50
a2 = sum(advertising_expense - exp(sales))/-50

range = linspace(0,100);
f1 = log(range)+a1;
f2 = log(range + repmat(a2, 1, 100));
hold on; scatter(advertising_expense, sales), plot(range, f1), plot(range, f2)

mse1 =0;
mse2=0;
for k=1:50
mse1 = mse1 + (sales(k) - ( log(advertising_expense(k)) + a1)).^2;
mse2 = mse2 + (sales(k) - ( log(advertising_expense(k) + a2))).^2;
end
mse1
mse2


mse_list1 = [];
mse_list2 = [];

for i=1:100

train = randperm(50, 40)
a1 =0;
a2 =0;
for n=1:40
a1 = a1 + (log(advertising_expense(train(n)))-sales(train(n)))
a2 = a2 + (advertising_expense(train(n))-exp(sales(train(n))))
end
a1 = a1/(-40)
a2 = a2/(-40)


mse1 = 0
mse2 = 0
full_range = [1:50]
test = setdiff(full_range, train)

for n=1:10
mse1 = mse1 + ((sales(test(n)) - (log(advertising_expense(test(n))) + a1)).^2)
mse2 = mse2 + ((sales(test(n))- (log(advertising_expense(test(n)) + a2))).^2)
end

mse_list1(end+1) = mse1
mse_list2(end+1) = mse2

end

m1 = mean(mse_list1)
m2 = mean(mse_list2)
