function[res] =  problem1()
clear all;
close all;
iris=load('data/iris.txt'); %loadthetextfile
y=iris(:,end); %target value is last column
X=iris(:,1:end-1); %features are other columns
whos %show current variables in memory and sizes
size(X,2),size(X,1) %get the number of features, and the number of datapoints

clear mean;
clear std;
clear var;
hist(X(:,1))
hist(X(:,2))
hist(X(:,3))
hist(X(:,4))
m = mean(X)
v = var(X)
s = std(X)

norm = (X - repmat(m, 148, 1))./(repmat(s, 148, 1))

x1 = X(:,1);
x2 = X(:,2);
x3 = X(:,3);
x4 = X(:,4);

s = linspace(1, 10, length(X));
hold off;
subplot(2,2,1)
scatter(x1, x2, [], s);
title('Relation between x1 and x2')
hold on
subplot(2, 2, 2)
scatter(x1, x3, [], s);
title('Relation between x1 and x3')
subplot(2, 2, 3)
scatter(x1, x4, [], s);
title('Relation between x1 and x4')
hold off
