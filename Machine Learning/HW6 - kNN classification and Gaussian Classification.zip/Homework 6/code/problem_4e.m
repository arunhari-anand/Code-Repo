
% Construct a grid of features
%[Xgrid1,Xgrid2] = meshgrid(linspace(2,8, 200), linspace(2,8,200));
[Xgrid1,Xgrid2] = meshgrid(linspace(-30,40, 200), linspace(-12,18,200));
Ygrid_hat = GaussianBayesPredict([Xgrid1(:), Xgrid2(:)], Xtrain(:,1:2), Ytrain);
% Plot the decision boundary.
figure; hold on;
% Plot the decision region for label y = 1
dx_0 =find(Ygrid_hat==0);
dx_1 =find(Ygrid_hat==1);
dx_2 =find(Ygrid_hat==2);

plot(Xgrid1(dx_0), Xgrid2(dx_0), '.r');
plot(Xgrid1(dx_1), Xgrid2(dx_1), '.b');
plot(Xgrid1(dx_2), Xgrid2(dx_2), '.g');

% Plot the decision region for label y = 1 and 2;
% using some different color (please finish .....)
%plot(....);
% Plot the original training data; labels visualized using different marker shapes
plot(Xtrain(Ytrain==1,1), Xtrain(Ytrain==1,2), 'kd','markersize',10); 
plot(Xtrain(Ytrain==2,1), Xtrain(Ytrain==2,2), 'k*','markersize',10); 
plot(Xtrain(Ytrain==0,1), Xtrain(Ytrain==0,2), 'ko','markersize',10);
axis tight;