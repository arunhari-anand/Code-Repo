iris=load('iris.txt'); y=iris(:,end); X=iris(:,1:end-1);
% Note: indexing with ":" indicates all values (in this case, all rows);
% indexing with a value ("1", "end", etc.) extracts only that one value (here, column % indexing rows/columns with a range ("1:end-1") extracts any row/column in that rang
n = size(X,1); d = size(X,2); % n: # of instances; d: # of features
dxtrain = 1:round(0.75*n); dxtest = setdiff(1:n, dxtrain); Xtrain = X(dxtrain, :); Ytrain = y(dxtrain,:);
Xtest = X(dxtest, :); Ytest = y(dxtest,:);
% Split data into 75/25 train/test


Ytest_hat = GaussianBayesPredict(Xtest(:,1:2), Xtrain(:,1:2), Ytrain);
Error_test = mean(Ytest_hat ~= Ytest)
% Calculate testing error;

Ytrain_hat = GaussianBayesPredict(Xtrain(:,1:2), Xtrain(:,1:2), Ytrain);
Error_train = mean(Ytrain_hat ~= Ytrain)
% Calculate training error