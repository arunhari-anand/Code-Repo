function px = pdfGaussian(X, mu, Sigma)
% Calculate the likelihood for a multivariate Gaussian distribution

t2 = exp((-1/2) * (X - mu)' * inv(Sigma) * (X - mu));
px = (1/(2 * pi * sqrt(det(Sigma)))) * t2;

