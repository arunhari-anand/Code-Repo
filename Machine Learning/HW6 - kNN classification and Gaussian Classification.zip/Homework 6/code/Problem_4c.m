close all
iris=load('iris.txt'); y=iris(:,end); X=iris(:,1:end-1);

% Note: indexing with ":" indicates all values (in this case, all rows);
% indexing with a value ("1", "end", etc.) extracts only that one value (here, columns);
% indexing rows/columns with a range ("1:end-1") extracts any row/column in that range.
n = size(X,1); 
d = size(X,2); % n: # of instances; d: # of features
dxtrain = 1:round(0.75*n); 
dxtest = setdiff(1:n, dxtrain);

Xtrain = X(dxtrain, :); 
Ytrain = y(dxtrain,:);
Xtest = X(dxtest, :); 
Ytest = y(dxtest,:);
% Split data into 75/25 train/test

Xtest = Xtest(:,1:2);
Xtrain = Xtrain(:,1:2);

mu_0 = mean(Xtrain(1:49,:));
mu_1 = mean(Xtrain(50:99,:));
mu_2 = mean(Xtrain(100:111,:));

sigma_0 = cov(Xtrain(1:49,:));
sigma_1 = cov(Xtrain(50:99,:));
sigma_2 = cov(Xtrain(100:111,:));

scatter(Xtrain(1:49,1),Xtrain(1:49,2), 'r');
hold on;
scatter(Xtrain(50:99,1),Xtrain(50:99,2), 'g');
scatter(Xtrain(100:111,1),Xtrain(100:111,2), 'b');
title('Feature 1 vs Feature 2');
legend('Y=0', 'Y=1', 'Y=2');

[X1,X2] = meshgrid([4:.1:9], [0:.1:8]);

p0 = zeros(size(X1));
for i = 1:size(X1,1)
    for j = 1:size(X2, 2)
        p0(i,j)=pdfGaussian([X1(i,j), X2(i,j)]', mu_0', sigma_0);
    end
end
contour(X1,X2,p0, 'color', 'red');

p1 = zeros(size(X1));
for i = 1:size(X1,1)
    for j = 1:size(X2, 2)
        p1(i,j)=pdfGaussian([X1(i,j), X2(i,j)]', mu_1', sigma_1);
    end
end
contour(X1,X2,p1, 'color', 'green');

p2 = zeros(size(X1));
for i = 1:size(X1,1)
    for j = 1:size(X2, 2)
        p2(i,j)=pdfGaussian([X1(i,j), X2(i,j)]', mu_2', sigma_2);
    end
end
contour(X1,X2,p2, 'color', 'blue');

axis([4,9,1,5]);
