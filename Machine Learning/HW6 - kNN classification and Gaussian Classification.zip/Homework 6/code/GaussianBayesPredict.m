function Ytest_hat = GaussianBayesPredict(Xtest, Xtrain, Ytrain)
% Implement Gaussian Bayesian classifer.
%
% Input:  
%    -- Xtest: feature of test data (a n X d matrix; each row is an instance, each column is a feature)
%    -- Xtrain: feature of training data (a n X d matrix)
%    -- Ytrain: true target value of training data (a n X 1 vector)
%
% Output: 
%    -- Ytest_hat: predicted target value on the test data 
%
% 



count_0 = 0;
count_1 = 0;
count_2 = 0;

for i = 1:size(Ytrain, 1)
    if (Ytrain(i, 1) == 0)
        count_0 = count_0 + 1;
    elseif (Ytrain(i, 1) == 1)
         count_1 = count_1 + 1;
    else  
       count_2 = count_2 + 1;
    end
end

p0 = count_0 / (count_0+count_1+count_2)
p1 = count_1 / (count_0+count_1+count_2)
p2 = count_2 / (count_0+count_1+count_2)

[y_sort, y_sort_index] = sort(Ytrain);
Xtrain_sort = [Xtrain(y_sort_index, 1), Xtrain(y_sort_index, 2)];
Xtrain_0 = [Xtrain_sort(1:count_0, 1), Xtrain_sort(1:count_0, 2)];
Xtrain_1 = [Xtrain_sort(count_0+1:count_0+count_1, 1), Xtrain_sort(count_0+1:count_0+count_1, 2)];
Xtrain_2 = [Xtrain_sort(count_0+count_1+1:size(Ytrain, 1), 1), Xtrain_sort(count_0+count_1+1:size(Ytrain, 1), 2)];

mu_0 = [mean(Xtrain_0(:, 1)); mean(Xtrain_0(:, 2))];
mu_1 = [mean(Xtrain_1(:, 1)); mean(Xtrain_1(:, 2))];
mu_2 = [mean(Xtrain_2(:, 1)); mean(Xtrain_2(:, 2))];

sigma_0 = cov(Xtrain_0(:, 1), Xtrain_0(:, 2))
sigma_1 = cov(Xtrain_1(:, 1), Xtrain_1(:, 2))
sigma_2 = cov(Xtrain_2(:, 1), Xtrain_2(:, 2))

Ytest_hat = zeros(size(Xtest, 1), 1);

for i = 1 :size(Xtest, 1)
    prob_classify = zeros(3, 1);
    prob_classify(1, 1) = p0 * pdfGaussian(Xtest(i, :)', mu_0, sigma_0);
    prob_classify(2, 1) = p1 * pdfGaussian(Xtest(i, :)', mu_1, sigma_1);
    prob_classify(3, 1) = p2 * pdfGaussian(Xtest(i, :)', mu_2, sigma_2);
    
    [max_prox, Ytest_hat(i, 1)] = max(prob_classify);
end

Ytest_hat = Ytest_hat -1;
    
    


        
