clear all;
close all;

iris=load('iris.txt'); y=iris(:,end); X=iris(:,1:end-1);
% Note: indexing with ":" indicates all values (in this case, all rows);
% indexing with a value ("1", "end", etc.) extracts only that one value (here, column % indexing rows/columns with a range ("1:end-1") extracts any row/column in that rang
n = size(X,1); d = size(X,2); % n: # of instances; d: # of features
dxtrain = 1:round(0.75*n); dxtest = setdiff(1:n, dxtrain); Xtrain = X(dxtrain, :); Ytrain = y(dxtrain,:);
Xtest = X(dxtest, :); Ytest = y(dxtest,:);
% Split data into 75/25 train/test

k = [1, 3, 5, 7, 9];

training_errors = zeros(1, 5);
testing_errors = zeros(1, 5);



for i = 1:5
    K = k(1, i);
    
    Ytest_hat = KNN(Xtest, K, Xtrain, Ytrain);
    % KNN prediction with K=1;
    
    testing_errors(1, i) = mean(Ytest_hat ~= Ytest);
    % Calculate testing error;
    
    Ytrain_hat = KNN(Xtrain, K, Xtrain, Ytrain);
    training_errors(1, i) = mean(Ytrain_hat ~= Ytrain);
    % Calculate training error (which is zero in this case (since K = 1));
end

scatter(k, testing_errors, 'b');
hold on;
scatter(k, training_errors, 'r');
title('K versus error for training (in red) and testing(in blue)');

[val, ind] = min(training_errors(1, :)');
k_best = k(1, ind)

%%%Weighted KNN%%%

training_errors = zeros(1, 5);
testing_errors = zeros(1, 5);
k = 2;
w = [2,1];
w(2) = 1;
w_vals = [0.01, 0.1, 1, 10, 100];




for i = 1:5
    
    w(1) = w_vals(i);
    Ytest_hat = WeightedKNN(Xtest, K, w, Xtrain, Ytrain);
    % KNN prediction with K=1;
    
    testing_errors(1, i) = mean(Ytest_hat ~= Ytest);
    % Calculate testing error;
    
    Ytrain_hat = WeightedKNN(Xtrain, K, w, Xtrain, Ytrain);
    training_errors(1, i) = mean(Ytrain_hat ~= Ytrain);
    % Calculate training error (which is zero in this case (since K = 1));
end

close all;
scatter(log(w_vals), testing_errors, 'b');
hold on;
scatter(log(w_vals), training_errors, 'r');
title('log w versus error for training (in red) and testing(in blue)');

[val, ind] = min(training_errors(1, :)');
w_best = w_vals(1, ind)

