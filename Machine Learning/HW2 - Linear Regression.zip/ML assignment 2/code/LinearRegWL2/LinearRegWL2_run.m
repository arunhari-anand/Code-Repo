%%% Load and plot data %%%% 
clear all; 
rng('default'); rng(1);
load curveData
figure; hold on;
plot(Xtrain, Ytrain, 'o');

%% Run polynomial Regression 

poly_order = 10; % order of the polynomial feature
alpha = 1;       % regularization parameter
w = [0, ones(1,poly_order)]; % weights in L2 norm; we set w(1)=0 so that we do not regularize on the constant term. 

% Apply linear regression on the polynomial feature to the data with a
% polynomial curve
theta = LinearRegWL2_train(poly_feature(Xtrain, poly_order),  Ytrain, alpha, w); % training 
hatYtest = LinearRegWL2_predict(poly_feature(Xtest,poly_order), theta); % testing
err_test = calculate_mse_Ytest_curveData(hatYtest); % calculate mse = mean((Ytest-hatYtest).^2);
fprintf('Testing Error is %d\n', err_test);

% plot the curve 
Xgrid = linspace(0,10,100)';
hatYgrid = LinearRegWL2_predict(poly_feature(Xgrid,poly_order), theta); % testing

figure; hold on;
plot(Xtrain, Ytrain, 'o');
plot(Xgrid, hatYgrid, '-');
legend('Training', 'Testing');


%% cross validation (Simple example):

% create a function handle that takes x and y as inputs and
% output the estimated parameter, the other parameters (poly_order, alpha, w) are
% are fixed and defined outside of the function handle. For example, you can run train_func(Xtrain, Ytrain),
% and get the same theta you had before. 
% For more info about matlab function handle, see 
% http://www.mathworks.com/help/matlab/matlab_prog/creating-a-function-handle.html
% 
Nfold = 2; % the code only works when Nfold=2 currently, please make work for general Nfold

train_func = @(x,y)LinearRegWL2_train(poly_feature(x, poly_order),  y, alpha, w);  
% create a function handle for calculaing the MSE on xtest with linear regression parameter th: 
evaluate_func = @(x, y, th)(mean((LinearRegWL2_predict(poly_feature(x, poly_order), th) - y).^2)); 
% cross validation: taking the data and train_func, predict_func as inputs and output the cross validation error 
err_xVar = cross_validation(Xtrain, Ytrain, Nfold, train_func, evaluate_func)

%% Use cross validation to select the best alpha:
Nfold = 5;
poly_order = 10; % order of the polynomial feature
w = [0, ones(1,poly_order)]; % weights in L2 norm; we set w(1)=0 so that we do not regularize on the constant term. 
alphaVec = [0,0.1,1,10,100];
errors = zeros(5);
for i = 1:length(alphaVec)
    alpha  = alphaVec(i);
    training_function = @(x,y)LinearRegWL2_train(poly_feature(x, poly_order),  y, alpha, w);  
    errors(i) = cross_validation(Xtrain, Ytrain, Nfold, training_function, evaluate_func);
    
    fprintf('alpha = %f error = %f\n', alpha,errors(i));
    %... please complete the code
    %err_xVar_Vec(i) = ... please complate the code
end
[min_err, index] = min(errors);
alphabest = alphaVec(index(1));

% Rerun your model with the best alpha and evaluate your performance 
hatYtest = LinearRegWL2_predict(poly_feature(Xtest, poly_order),LinearRegWL2_train(poly_feature(Xtrain, poly_order), Ytrain, alphabest,w)); 
err_test = calculate_mse_Ytest_curveData(hatYtest); % calculate mse = mean((Ytest-hatYtest).^2);
fprintf('alpha = %d, MSE = %d\n', alphabest, err_test);

 
%% Use cross validation to select the best polynomial order:
Nfold = 5;
%alpha = .1;
poly_order_Vec = [1,2,3,4,5,10,20];
errors = zeros(7);
for i = 1:7
    order  = poly_order_Vec(i);
    fprintf('order = %d\n', order);
    w = [0, ones(1,order)]; % weights in L2 norm; we set w(1)=0 so that we do not regularize on the constant term. 
    %... please complete the code
    %err_xVar_Vec(i) = ... % please complete the code
    
    training_func = @(x,y)LinearRegWL2_train(poly_feature(x, order),  y, alpha, w);  
    evaluate_func = @(x, y, th)(mean((LinearRegWL2_predict(poly_feature(x, order), th) - y).^2)); 
    errors(i) = cross_validation(Xtrain, Ytrain, Nfold, training_func, evaluate_func);
    fprintf('order: %d MSE: %f\n', order,errors(i));
end

[min_err, index] = min(errors);
poly_order_best = poly_order_Vec(index(1));
fprintf("Best poly order = %d\n", poly_order_best);
% Rerun your model with the best poly_order
% hatYtest = ....  please complate the code 

w = [0, ones(1,poly_order_best)];
theta_star =  LinearRegWL2_train(poly_feature(Xtrain, poly_order_best), Ytrain, alpha,w);
hatYtest = LinearRegWL2_predict(poly_feature(Xtest, poly_order_best),theta_star);


err_test = calculate_mse_Ytest_curveData(hatYtest); % calculate mse = mean((Ytest-hatYtest).^2);
fprintf('Testing Error is %d\n', err_test);




Nfold = 5;



alphaVec = 3:15;     
poly_order_Vec = 1:5;  
errors = zeros(length(alphaVec),length(poly_order_Vec));

min_error = 10000;
alphabest = 1000;
poly_order_best = 1000;

for i = 1:length(alphaVec)
    for j = 1:length(poly_order_Vec)
        alpha       = alphaVec(i);

        order  = poly_order_Vec(j);
        w = [0, ones(1,order)]; % weights in L2 norm; we set w(1)=0 so that we do not regularize on the constant term.
        
        training_func = @(x,y)LinearRegWL2_train(poly_feature(x, order),  y, alpha, w);
        evaluate_func = @(x, y, th)(mean((LinearRegWL2_predict(poly_feature(x, order), th) - y).^2));
        errors(i,j) = cross_validation(Xtrain, Ytrain, Nfold, training_func, evaluate_func);
        
        errors(i,j)
        if errors(i,j) < min_error
            min_error = errors(i,j);
            alphabest = alpha;
            poly_order_best = order;
        end
        
        fprintf('alpha = %d, order = %d error = %f\n', alpha, order,errors(i,j));     
    end
end


%alphabest = alphaVec(index_min_alpha);
%poly_order_best =  poly_order_Vec(index_min_order);
w = [0, ones(1,poly_order_best)];
% Rerun your model with the best poly_order

theta_star =  LinearRegWL2_train(poly_feature(Xtrain, poly_order_best), Ytrain, alphabest,w);
hatYtest = LinearRegWL2_predict(poly_feature(Xtest, poly_order_best),theta_star);
err_test = calculate_mse_Ytest_curveData(hatYtest); % calculate mse = mean((Ytest-hatYtest).^2);
fprintf('best alpha = %d, best order: %d, testing error is %f\n', alphabest, poly_order_best,min_err);

