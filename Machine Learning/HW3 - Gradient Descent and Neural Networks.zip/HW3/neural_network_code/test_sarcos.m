%% load the training and testing dataset
clear all;
load sarcos;
rng(1);
Xtrain = sarcos_training(:,1:21); Ytrain  = sarcos_training(:, 22); 
Xtest = sarcos_testing(:, 1:21); Ytest = sarcos_testing(:, 22);

% Feel free to tune these hyperparameters
% number of hidden units
params.hidden_units = 200;
% SGD, batch size
params.batch_size = 10;
% SGD, step size
params.step_size = 1e-4;
% epoches
params.max_epoches = 30;

% Try nn with 10 hidden units. 
params.hidden_units = 10; 
[net, mse] = nn_train( [ones(size(Xtrain,1),1),Xtrain], Ytrain, params);
figure;
plot(1:length(mse), mse, '-ro', 'LineWidth', 4, 'MarkerSize', 8);
xlabel('Epoch', 'FontSize', 20); ylabel('MSE', 'FontSize', 20);

% calculate the MSE on both the training and testing datasets.
mse_test = nn_MSE([ones(size(Xtest,1),1), Xtest], Ytest, net)
mse_train =  nn_MSE([ones(size(Xtrain,1),1), Xtrain], Ytrain, net)

%% use cross validation to select the best number of hidden units
hidden_units = [10 50 100 200];


mse_values = zeros(1, length(hidden_units));
Nfold = 2;
for n = 1:length(hidden_units)
    s = size(Xtrain, 1);
    errors = zeros(Nfold,1);
    indices=1:s;
    MSE_Vec = zeros(Nfold,1);
    training_set_x = Xtrain;
    training_set_y = Ytrain;
    for i=0:(Nfold-1)
        testing_interval = floor((s / Nfold * i) + 1) : floor((s / Nfold) * (i + 1));
        training_interval  = setdiff(indices,testing_interval);
        testing_set_x =  Xtrain(testing_interval, :);
        testing_set_y =  Ytrain(testing_interval);  
        training_set_x = Xtrain(training_interval, :);
        training_set_y = Ytrain(training_interval);  
        params.hidden_units = hidden_units(n);
        [net, mse] = nn_train( [ones(size(training_set_x,1),1),training_set_x], training_set_y, params);
        MSE_Vec(i+1) = nn_MSE([ones(size(testing_set_x,1),1), testing_set_x], testing_set_y, net);
       %theta_star = train_func(Xtrain_new, Ytrain_new); 
       %errors(i+1) = evaluate_func(Xtest, Ytest, theta_star);
    end
    mse_values(1, n) = mean(MSE_Vec); 
end
[min_mse, index] = min(mse_values);
num_hidden_units = hidden_units(1, index);
params.hidden_units = num_hidden_units;
[net, mse] = nn_train( [ones(size(Xtrain,1),1),Xtrain], Ytrain, params);
mse_test = nn_MSE([ones(size(Xtest,1),1), Xtest], Ytest, net);
fprintf("The optimal number of hidden units is %d and the testing MSE is %d\n", num_hidden_units, mse_test);
fprintf("The training mse is %d\n", mse(size(mse,1)));
%hu_best  = ...

