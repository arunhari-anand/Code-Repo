%Homework 3, question 1a
%Arun Hari Anand
%October 9, 2017

load '../sales_example';

iterations = 5000;
step_size = 0.003;
a=-5;

n = length(sales);

loss_values = zeros(1, iterations);


for i = 1:iterations
    loss = 0;
    gradient_so_far = 0;
    
    for j = 1:n
        gradient_so_far = gradient_so_far + ((2/n) * (sales(j) - log(advertising_expense(j) + a)) * ((-1)/(advertising_expense(j) + a)));
        
        loss = loss + (1/n) * (sales(j) - log(advertising_expense(j) + a))^2;
    end
    
    loss_values(1,i) = loss;
    a = a - (step_size * gradient_so_far);
end


loss_gd = loss;
a_gd = a;

hold off;

x = 1:iterations;
plot(x, loss_values);

title('Loss plot');
xlabel('Number of Iterations');
ylabel('Value of the loss function');

a = -10:0.1:10
loss_function = zeros(1,length(a));

for i = 1:length(a)
    loss = 0;
    for j = 1:n
    loss = loss + (1/n) * (sales(j) - log(advertising_expense(j) + a(i)))^2;
    end
    loss_function(1,i) = loss;
end


%uncomment these lines to plot the loss function
plot(a, loss_function);
title('Loss function');
xlabel('Value of a');
ylabel('Value of the loss function');

    


fprintf("optimal a = %d, loss = %d", a_gd, loss_gd);


