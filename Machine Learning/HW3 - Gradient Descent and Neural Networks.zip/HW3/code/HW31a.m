%Homework 3, question 1a
%Arun Hari Anand
%October 9, 2017

load '../sales_example';

iterations = 5000;
step_size = 0.3;
a=1;

n = length(sales);

loss_values = zeros(1, iterations);


for i = 1:iterations
    loss = 0;
    gradient_so_far = 0;
    
    for j = 1:n
        gradient_so_far = gradient_so_far + ((2/n) * (sales(j) - log(advertising_expense(j) + a)) * ((-1)/(advertising_expense(j) + a)));
        
        loss = loss + (1/n) * (sales(j) - log(advertising_expense(j) + a))^2;
    end
    
    loss_values(1,i) = loss;
    a = a - (step_size * gradient_so_far);
end


loss_gd = loss;
a_gd = a;

hold on;

x = 1:iterations;
plot(x, loss_values);

title('Loss plot');
xlabel('Number of Iterations');
ylabel('Value of the loss function');

fprintf("optimal a = %d, loss = %d", a_gd, loss_gd);


