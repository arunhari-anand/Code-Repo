%Homework 3, question 1b
%Arun Hari Anand
%October 9, 2017

close all;

load '../sales_example';

a2 = 6.4866;
astar = 1.2279;

hold on;
scatter(advertising_expense, sales);
x = linspace(0,100);

plot(x, log(x + a2), 'r');
plot(x, log(x + astar), 'b');

ylabel('Sales');
xlabel('Advertising Expense');
title('Comparison of optimal a derived from exponentiation versus gradient descent' );
legend('sales data', 'a2 based regression', 'a* based regression');