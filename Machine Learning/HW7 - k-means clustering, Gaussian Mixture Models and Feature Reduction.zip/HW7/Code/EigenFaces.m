clear all;
close all;
X = load('../data/faces.txt'); % load face dataset
%img = reshape(X(i, :),[24 24]); % convert vectorized datum to 24x24 image patch 
%imagesc(img); axis square; colormap gray;

height = size(X,1);
width = size(X, 2);
mu = 0;
for row = 1:height
    for col = 1:width
        mu = mu + X(row, col);
    end
end
mu = mu/(height*width);

X0 = zeros(height, width);
for row = 1:height
    for col = 1:width
        X0(row, col) = X(row, col) - mu;
    end
end


[U,S,V] = svds(X0, width);

k = [1:10];
MSEvec = zeros(1, 10);

for K =1:10
    W = U * S;
    X_hat = W(:,1:K)*V(:,1:K)';
    mse_hat = mean((X0-X_hat).^2);
    MSEvec(1,K) = mean(mse_hat);
end


scatter(k, MSEvec);
title('k vs MSE');
xlabel('K');
ylabel('MSE');

for i = 1:3
    alpha = 2*median(abs(W(:,i)));
    face1 = mu + (alpha * V (:, i)');
    face2 = mu - (alpha * V (:, i)');
    img1 = reshape(face1,[24 24]); % convert vectorized datum to 24x24 image patch 
    img2 = reshape(face2,[24 24]);
    figure;
    imagesc(img1); axis square; colormap gray;
    
 
    figure;
    imagesc(img2); axis square; colormap gray;
end



idx =  randi(576, 1, 20);
figure; hold on; axis ij; colormap(gray);
range = max(W(idx,1:2)) - min(W(idx,1:2)); % find range of coordinates to be plot 
scale = [200 200]./range; % want 24x24 to be visible but not lar 
for i=idx, imagesc(W(i,1)*scale(1),W(i,2)*scale(2), reshape(X(i,:),24,24)); end;


k = [5, 10, 50];
faces = [55, 71];
W = U * S;
    
for j = 1:3
    
    X_hat = W(:,1:k(1,j))*V(:,1:k(1,j))';
    
    figure;
    img1 = reshape(X_hat(55, :),[24 24]);
    imagesc(img1); axis square; colormap gray;
    
    
    figure;
    img2 = reshape(X_hat(71, :),[24 24]);
    imagesc(img2); axis square; colormap gray;
end
    

    
    





    
    






    
