clear all;
close all;
load('../data/iris.txt');
X = iris(:, 1:2);
x1 = X(:, 1);
x2 = X(:, 2);

options = statset('Display','final');

figure;
plot(x1, x2,'k*','MarkerSize',5);
gm = fitgmdist(X,2,'Options',options);
gmPDF = @(X,Y)pdf(gm,[X Y]);
hold on;
p = ezcontour(gmPDF,[1 10],[1 5]);
title('Contour, K=2')
xlabel 'x1';
ylabel 'x2';
hold off


figure;
plot(x1,x2,'k*','MarkerSize',5);
gm = fitgmdist(X,5,'Options',options);
gmPDF = @(X,Y)pdf(gm,[X Y]);
hold on
p = ezcontour(gmPDF,[3 10],[1 5]);
title('Contour, K=5')
xlabel 'x1';
ylabel 'x2';
hold off






figure;
plot(x1,x2,'k*','MarkerSize',5);
hold on;


ll_star = 10e9;
gm_star = -1;
for i = 1:10
    gm = fitgmdist(X,5,'Options',options);
    if  ll_star > gm.NegativeLogLikelihood
        ll_star = gm.NegativeLogLikelihood;
        gm_star = gm;
    end
end


gmPDF = @(X,Y)pdf(gm_star,[X Y]);
p = ezcontour(gmPDF,[4 8],[2 5]);
title('Best Contour, k=5')
xlabel('x1');
ylabel('x2');
hold off

ll_star

