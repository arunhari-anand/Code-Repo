clear all;
close all;
load('../data/iris.txt');
X = iris(:, 1:2);
x1 = X(:, 1);
x2 = X(:, 2);

scatter(x1, x2);
title('x1 vs x2');
xlabel('x1');
ylabel('x2');

[idx, C] = kmeans(X, 2);

figure;
plot(X(idx==1,1),X(idx==1,2),'r.','MarkerSize',12)
hold on
plot(X(idx==2,1),X(idx==2,2),'b.','MarkerSize',12)
plot(C(:,1),C(:,2),'kx',...
     'MarkerSize',15,'LineWidth',3)
legend('Cluster 1','Cluster 2','Centroids',...
       'Location','NW')
title 'Cluster Assignments and Centroids; k=2'
hold off


[idx, C] = kmeans(X, 5);
figure;
plot(X(idx==1,1),X(idx==1,2),'r.','MarkerSize',12)
hold on
plot(X(idx==2,1),X(idx==2,2),'b.','MarkerSize',12)
plot(X(idx==3,1),X(idx==3,2),'g.','MarkerSize',12)
plot(X(idx==4,1),X(idx==4,2),'m.','MarkerSize',12)
plot(X(idx==5,1),X(idx==5,2),'c.','MarkerSize',12)
plot(C(:,1),C(:,2),'kx',...
     'MarkerSize',15,'LineWidth',3)
legend('Cluster 1','Cluster 2','Cluster 3','Cluster 4','Cluster 5','Centroids',...
       'Location','NW')
title 'Cluster Assignments and Centroids; k=5'
hold off

idx = zeros(size(X, 1), 2);
c = zeros(50, 2);
sumd = zeros(10, 1);

for i = 1:10
    [idx_iter,c_iter, sumd_iter] = kmeans(X,5);
    sumd(i,1) = sum(sumd_iter);
    idx(:,i) = idx_iter;
    row_start = (5*(i-1)) +1;
    row_end = row_start + 4;
    c(row_start:row_end,:) = c_iter;
end

[min_sum, min_index] = min(sumd);
idx = idx(:, min_index);
row_start = (5*(min_index-1)) +1;
row_end = row_start+4;
C = c(row_start: row_end, :);


figure;
plot(X(idx==1,1),X(idx==1,2),'r.','MarkerSize',12)
hold on
plot(X(idx==2,1),X(idx==2,2),'b.','MarkerSize',12)
plot(X(idx==3,1),X(idx==3,2),'g.','MarkerSize',12)
plot(X(idx==4,1),X(idx==4,2),'m.','MarkerSize',12)
plot(X(idx==5,1),X(idx==5,2),'c.','MarkerSize',12)
plot(C(:,1),C(:,2),'kx',...
     'MarkerSize',15,'LineWidth',3)
legend('Cluster 1','Cluster 2','Cluster 3','Cluster 4','Cluster 5','Centroids',...
       'Location','NW')
title 'Best Cluster Assignments and Centroids; k=5'
hold off



