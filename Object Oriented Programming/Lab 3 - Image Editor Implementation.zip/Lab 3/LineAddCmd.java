/**
 * LineAddCmd.java
 * Implements the set of commands for the "Line" button.
 * Communicates with the Drawing object to create and add Segment objects to the canvas
 * Extends the command class
 * 
 * @author Arun Hari Anand on February 1, 2016
 * @author Nitasha Kochar on February 1, 2016
 */
import java.awt.Point;

public class LineAddCmd extends Command{
	private Shape s;// the line object 
	
	/**
	 * Method to execute a mouse press on the canvas - creates a new Segment object with the initial point
	 * final point being the point that was pressed and passes it to the Drawing
	 * The initial color of the segment is accessed from the getDefaultColor() method in the Drawing class
	 * @param p the point where the press occurred
	 * @param dwg the drawing object that contains the shapes stored on the canvas.
	 * 
	 */
	public void executePress(Point p, Drawing dwg) {
		s= new Segment (((int) p.getX()), ( (int) p.getY()),((int) p.getX()), 
				( (int) p.getY()), dwg.getDefaultColor());
	  dwg.addNewShape(s);
	}
	
	/**
	 * Method to execute a mouse drag on the canvas - calls the setFinalPoint(Point p) method in the
	 * Segment class to the point where the drag occurred
	 * @param p the point where the drag occurred
	 * @param dwg the drawing object that contains the shapes stored on the canvas.
	 * 
	 */
	public void executeDrag(Point p, Drawing dwg) {
		((Segment) s).setFinalPoint(p);
	}
}

