/**
 * BackCmd.java
 * Implements the set of commands for the "Back" button.
 * Commmunicates with the Drawing object to relay information about what changes need to be made
 * to the canvas.
 * Extends the command class
 * 
 * @author Arun Hari Anand on February 1, 2016
 * @author Nitasha Kochar on February 1, 2016
 */
import java.awt.*;



public class BackCmd extends Command{
	
/**
 * Method to execute a click on the canvas - Gets the frontmost shape and 
 * tells the drawing object to move it to the background.
 * @param p the point where the click occurred
 * @param dwg the drawing object that contains the shapes stored on the canvas.
 * 
 */
	public void executeClick(Point p, Drawing dwg) {
		Shape s = dwg.getFrontmostContainer(p);
		if (s != null)
		dwg.move_to_back(s);
	}	
}


