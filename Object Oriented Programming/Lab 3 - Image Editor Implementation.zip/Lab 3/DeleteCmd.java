/**
 * DeleteCmd.java
 * Implements the set of commands for the "Delete" button.
 * Commmunicates with the Drawing object to relay information about what changes need to be made
 * to the canvas.
 * Extends the command class
 * 
 * @author Arun Hari Anand on February 1, 2016
 * @author Nitasha Kochar on February 1, 2016
 */
import java.awt.Point;

public class DeleteCmd extends Command {

/**
 * Method to execute a click on the canvas
 * Deletes the shape that was clicked on from the shapes ArrayList
 * in the Drawing object with a call to the "deleteShape()" method
 * @param p the point where the click occurred on the canvas
 * @param dwg the drawing object that stores the Shape objects on the canvas
 */
	public void executeClick(Point p, Drawing dwg) {
		Shape s = dwg.getFrontmostContainer(p);
		if (s!=null)
		dwg.deleteShape(s);
	}
	
}
