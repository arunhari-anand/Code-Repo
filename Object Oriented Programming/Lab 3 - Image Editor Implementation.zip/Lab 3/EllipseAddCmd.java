/**
 * EllipseAddCmd.java
 * Implements the set of commands for the "Ellipse" button.
 * Communicates with the Drawing object to add ellipses to the canvas
 * 
 * @author Arun Hari Anand on February 1, 2016
 * @author Nitasha Kochar on February 1, 2016
 */
import java.awt.Point;

public class EllipseAddCmd extends Command {
	private Shape s; // holds the ellipse object
	private Point pt;// the point that was initially pressed
	
	 /**
   *Method to add an ellipse to the canvas when it is pressed  
   * Creates a new ellipse object with the left corner being the 
   * point that was pressed and width and height being zero (with the color being the 
   * default color selected by the user (accessed from the Drawing class) and passes it to the Drawing
   * 
   * @param p the point where the press occurred on the canvas
   * @param dwg the drawing object that stores the Shape objects on the canvas
   */
	public void executePress(Point p, Drawing dwg) {
		s= new Ellipse (((int) p.getX()), ((int) p.getY()),0,0, dwg.getDefaultColor());
		pt = p;
	  dwg.addNewShape(s);
	}
	
	 /**
   * Method to execute a drag on the canvas
   * Changes the height and width of the existing ellipse according to 
   * the new mouse position
   * @param p the point where the mouse drag occurred on the canvas
   * @param dwg the drawing object that stores the Shape objects on the canvas
   */
	public void executeDrag(Point p, Drawing dwg) {
		int x = Math.min(p.x, pt.x);
		int y = Math.min(p.y, pt.y);
		int width = Math.abs(p.x - pt.x);
		int height = Math.abs(p.y - pt.y);
		((Ellipse) s).setX(x);
		((Ellipse) s).setY(y);
		((Ellipse) s).setWidth(width);
		((Ellipse) s).setHeight(height);
	}
}

