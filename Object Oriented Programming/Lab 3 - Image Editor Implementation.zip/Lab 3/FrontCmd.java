/**
 * FrontCmd.java
 * Method to execute the command associated with the "Front" button
 * Extends the command class
 * 
 * @author Arun Hari Anand on February 1, 2016
 * @author Nitasha Kochar on February 1, 2016
 */
import java.awt.Point;

public class FrontCmd extends Command{

/**
 * Method to execute a click on the canvas when the front button has been pressed
 * calls the "moveToFront()" method in the Drawing class to send the shape that has
 * been clicked on to the front	
 */
	public void executeClick(Point p, Drawing dwg) {
		Shape s = dwg.getFrontmostContainer(p);
		if (s!=null)
		dwg.moveToFront(s);
	}	
}
