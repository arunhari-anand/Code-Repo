/**
 * ColorCmd.java
 * Implements the set of commands for the color buttons.
 * Commmunicates with the Drawing object to relay information about what changes need to be made
 * to the canvas.
 * Extends the command class
 * 
 * @author Arun Hari Anand on February 1, 2016
 * @author Nitasha Kochar on February 1, 2016
 */
import java.awt.Color;
import java.awt.Point;


public class ColorCmd extends Command{
   private Color newDefaultColor;// the color of the particular color button that was clicked 
	/**
	 * Constructor for the ColorCmd class
	 * @param col initial value for the col instance variable
	 * @param dwg the Drawing object thta contains the shapes on the canvas
	 */
   public ColorCmd(Color col, Drawing dwg){
		dwg.setDefaultColor(col);
		this.newDefaultColor = col;
	}
	
   /**
    * Method to execute a click on the canvas
    * Sets the color of the shape that was clicked on to the 
    * color stored in the variable "col"
    * @param p the point where the click occurred on the canvas
    * @param dwg the drawing object that stores the Shape objects on the canvas
    */
	public void executeClick(Point p, Drawing dwg){
		Shape s = dwg.getFrontmostContainer(p);
		s.setColor(newDefaultColor);
	}
}


