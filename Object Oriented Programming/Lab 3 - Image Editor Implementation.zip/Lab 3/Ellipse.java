
import java.awt.*;

/**
 * Ellipse.java
 * Class for an ellipse.
 * Extends Shape.java
 * 
 * Written by THC for CS 5 Lab Assignment 3.
 *
 * @author Nitasha Kochar on Feb 1, 2016
 * @author Arun Hari Anand on Feb 1, 2016
 * @author Thomas H. Cormen
 * @see Shape
 */
public class Ellipse extends Shape {
  private int myX, myY;
  private int myWidth, myHeight;
 

  /**
   * Constructor for Ellipse. 
   * @param x the x coordinate of the upper left corner
   * @param y the y coordinate of the upper left corner
   * @param width the width of the surrounding rectangle
   * @param height the height of the surrounding rectangle
   */
  public Ellipse(int x, int y, int width, int height, Color color){
  	super(color);
  	myX = x;
  	myY = y;
  	myWidth = width;
  	myHeight = height;
  	
  	
  }
  
  /**
   * Method to change the x coordinate of the upper left corner
   * @param x the new x coordinate
   */
  public void setX(int x){
  	myX =x;
  }
  
  /**
   * Method to change the y coordinate of the upper left corner
   * @param y the new y coordinate
   */
  public void setY(int y){
  	myY =y;
  }
  
  /**
   * Method to change the width
   * @param width the new width
   */
  public void setWidth(int width){
  	myWidth = width;
  }
  
  /**
   * Method to change the height
   * @param width the new height
   */
  public void setHeight(int height){
  	myHeight =height;
  }
  
  /**
   * Method to draw an ellipse using the fillOval method of the Graphics class
   * @param page the Graphics object that represents the canvas
   */
  public void drawShape(Graphics page){ // draw the Shape
  	page.fillOval(myX,myY, myWidth, myHeight);
  }
  
  /**
   * Method to return true if the given point is inside the ellipse
   * @param p the given point
   * @return true if the point is inside the ellipse, false if not
   */
  public boolean containsPoint(Point p){ // does the Shape contain Point p?
  	return pointInEllipse(p, myX, myY, myWidth, myHeight);
  }
  
  /**
   * Method to move the ellipse by deltaX and deltaY
   * @param deltaX the amount by which the ellipse should be moved horizontally
   * @param deltaY the amount by which the ellipse should be moved vertically
   */
  public void move(int deltaX, int deltaY){ // move the Shape
    myX += deltaX;
    myY += deltaY;

  }
  
  /**
   * Method thats returns the center of the ellipse
   * @return the center of the ellipse
   */
  public Point getCenter(){ // return the Shape's center
  	double centerX = (myX + (myWidth/2));
  	double centerY = (myY + (myHeight/2));
  	Point p = new Point (((int) centerX), ((int) centerY));
  	return p;
  }

  // Helper method that returns whether Point p is in an Ellipse with the given
  // top left corner and size.
  private static boolean pointInEllipse(Point p, int left, int top, int width,
      int height) {
    double a = width / 2.0; // half of the width
    double b = height / 2.0; // half of the height
    double centerx = left + a; // x-coord of the center
    double centery = top + b; // y-coord of the center
    double x = p.x - centerx; // horizontal distance between p and center
    double y = p.y - centery; // vertical distance between p and center

    // Now we just apply the standard geometry formula.
    // (See CRC, 29th edition, p. 178.)
    return Math.pow(x / a, 2) + Math.pow(y / b, 2) <= 1;
  }
}
