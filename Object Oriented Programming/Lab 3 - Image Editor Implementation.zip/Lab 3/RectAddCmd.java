/**
 * RectAddCmd.java
 * Implements the set of commands for the "Rectangle" button.
 * Communicates with the Drawing object to add rects to the canvas
 * 
 * @author Arun Hari Anand on February 1, 2016
 * @author Nitasha Kochar on February 1, 2016
 */
import java.awt.Point;

public class RectAddCmd extends Command{
	private Shape s; //the rect object being added
	private Point pt; // the upper left point of the rect
	
	/**
   *Method to add an rect to the canvas when it is pressed  
   * Creates a new rect object with the left corner being the 
   * point that was pressed and width and height being zero (with the color being the 
   * default color selected by the user (accessed from the Drawing class) and passes it to the Drawing
   * 
   * @param p the point where the press occurred on the canvas
   * @param dwg the drawing object that stores the Shape objects on the canvas
   */
	public void executePress(Point p, Drawing dwg) {
		s= new Rect (((int) p.getX()), ((int) p.getY()),0,0, dwg.getDefaultColor());
		pt = p;
	  dwg.addNewShape(s);
	}
	
	/**
   * Method to execute a drag on the canvas
   * Changes the height and width of the existing rect according to 
   * the new mouse position
   * @param p the point where the mouse drag occurred on the canvas
   * @param dwg the drawing object that stores the Shape objects on the canvas
   */
	public void executeDrag(Point p, Drawing dwg) {
		int x = Math.min(p.x, pt.x);
		int y = Math.min(p.y, pt.y);
		int width = Math.abs(p.x - pt.x);
		int height = Math.abs(p.y - pt.y);
		((Rect) s).setX(x);
		((Rect) s).setY(y);
		((Rect) s).setWidth(width);
		((Rect) s).setHeight(height);
	}
}

