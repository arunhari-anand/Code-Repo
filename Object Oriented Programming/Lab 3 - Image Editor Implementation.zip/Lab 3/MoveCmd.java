/**
 * MoveCmd.java
 * Implements the set of commands for the "Move" button.
 * Commmunicates with the Drawing object to relay information about what changes need to be made
 * to the canvas when the shape is moved.
 * Extends the command class
 * 
 * @author Arun Hari Anand on February 1, 2016
 * @author Nitasha Kochar on February 1, 2016
 */
import java.awt.Point;

public class MoveCmd extends Command {
	private Shape movedShape; //this is the variable that stores the shape being moved
	private Point intialPt; //The point where the shape is currently at
	
	/**
	 * Method to execute a press on the canvas - Gets the frontmost shape and 
	 * initializes the initial point to the point where the ellipse was pressed.
	 * @param p the point where the click occurred
	 * @param dwg the drawing object that contains the shapes stored on the canvas.
	 * 
	 */
	public void executePress(Point p, Drawing dwg) {
		movedShape = dwg.getFrontmostContainer(p);
		intialPt = p;
	}
	
	/**
	 * Method to execute a drag on the canvas - calls the shape's move method and
	 * resets the initial point to the current location
	 * @param p the point where the click occurred
	 * @param dwg the drawing object that contains the shapes stored on the canvas.
	 * 
	 */
	public void executeDrag(Point p, Drawing dwg) {
		if (movedShape!=null){
		movedShape.move(p.x-intialPt.x, p.y-intialPt.y);
		intialPt = p;
		}
	}
}
