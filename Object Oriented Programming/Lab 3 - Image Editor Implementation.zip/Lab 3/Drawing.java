/**
 * Drawing.java
 * Keeps track of the shapes that are currently on the canvas
 * and provides information such as the frontmost container at a given point
 * 
 * 
 * 
 * @author Arun Hari Anand on February 1, 2016
 * @author Nitasha Kochar on February 1, 2016
 */
import java.awt.Graphics;
import java.util.ArrayList;
import java.awt.*;

public class Drawing {
 private Color default_color; //the default color selected by the user
 private ArrayList<Shape> shapes; // the ArrayList that stores all the shapes
 
 /**
  * Constructor for the Drawing class
  * initializes the instance variables
  * @param default_color the initial default color for the canvas
  */
 public Drawing (Color default_color){
	 this.default_color = default_color;
	 shapes = new ArrayList<Shape>();
	 
 }
 
 /**
  * Method to draw all the shapes in the shapes ArrayList
  * calls the individual drawShape() methods for each shape
  * @param page a reference to the graphics page where the shapes are to be drawn
  */
 public void draw (Graphics page){
	 for (int i =0; i<shapes.size(); i++){
		 shapes.get(i).draw(page);
	 }
	 
 }
 
 /**
  * Method to return the frontmost shape that contains a given point
  * since shapes stores the frontmost containers at the last indices, the method rotates through
  * from last to first, returning the first instance of a shape that contains a given point
  * @param p the point where the click was made on the canvas
  * @return the frontmost shape that contains the point p, null if there is no shape at that point
  */
 public Shape getFrontmostContainer(Point p){
	 for (int i =shapes.size()-1;i>=0; i--){
		if (shapes.get(i).containsPoint(p))
			return shapes.get(i);
	 }
	 return null;
	 }
 
 
 /**
  * method to change the default color of the shapes being drawn
  * @param col the new default color
  */
 public void setDefaultColor(Color col){
	 default_color = col;
 }
 /**
  * returns the value of the default_color variable, which is the current default color of
  * the shapes being drawn on the canvas
  * @return the default color
  */
 public Color getDefaultColor(){
	 return default_color;
 }
 
 /**
  * deletes the reference of the given shape from the shapes arrayList
  * @param s a reference to the shape that must be deleted from the canvas
  */
 public void deleteShape(Shape s){
	 shapes.remove(s);
	 //System.out.println((shapes.remove(s)).toString());
 }
 
 /**
  * method to add a given shape to the canvas, adds it to the end because
  * the frontmost containers go last
  * @param s the shape to be added to the shapes ArrayList
  */
 public void addNewShape(Shape s){
	 shapes.add(s);
 }
 
/**
 * method to move a shape to the front of the canvas
 * since the shapes are stored back to front, the method moves the shape to the
 * end of the list
 * @param s the shape that must be moved to front
 */
public void moveToFront(Shape s){
 shapes.remove(s);
 shapes.add(s);
  }

/**
 * method to move a shape to the background of the canvas
 * moves the given shape to the front of the list
 * @param s the shape that must be moved to the back
 */
public void move_to_back(Shape s){
	shapes.remove(s);
	shapes.add(0,s);
}
}
