/**
 * Ellipse.java
 * Class for an ellipse.
 * Extends Shape.java
 * 
 * Written by THC for CS 5 Lab Assignment 3.
 *
 * @author Nitasha Kochar on Feb 1, 2016
 * @author Arun Hari Anand on Feb 1, 2016 
 * @author Thomas H. Cormen
 * @author Scot Drysdale
 * @see Shape
 */

import java.awt.*;

public class Rect extends Shape {
  private int myWidth, myHeight; // Rectangle's width and height
  private int myX, myY; //x and y values for rectangle
  

  /**
   *  Constructor for Rectangle. 
   * @param x the x coordinate of the upper left corner
   * @param y the y coordinate of the upper left corner
   * @param width the width of the rectangle
   * @param height the height of the rectangle
   * @param rectColor the color of the rectangle
   */
  public Rect(int x, int y, int width, int height, Color rectColor) {
    super(rectColor);
    myX = x;
    myY = y;
    myWidth = width;
    myHeight = height;
   
  }
  
  /**
   * Method to change the x coordinate of the upper left corner
   * @param x the new x coordinate
   */
  public void setX(int x){
  	myX =x;
  }
  
  /**
   * Method to change the y coordinate of the upper left corner
   * @param y the new y coordinate
   */
  public void setY(int y){
  	myY =y;
  }
  
  /**
   * Method to change the width
   * @param width the new width
   */
  public void setWidth(int width){
  	myWidth = width;
  }
  
  /**
   * Method to change the height
   * @param width the new height
   */
  public void setHeight(int height){
  	myHeight =height;
  }

  /**
   * Have the Rectangle object draw itself on the page passed as a parameter.
   * @param page the graphics object to draw on
   */
  // Assumes that the Graphics object's color has already been set.
  public void drawShape(Graphics page) {
    page.fillRect(myX, myY, myWidth, myHeight);
  }
 
  /**
   * Method to return true if the given point is inside the rect
   * @param p the given point
   * @return true if the point is inside the rect, false if not
   */
  public boolean containsPoint(Point p){ // does the Shape contain Point p?
  	return (myX <= p.x && p.x <= (myX + myWidth) && myY <= p.y && p.y <= myY + myHeight);
  }
  
  /**
   * Method to move the rect by deltaX and deltaY
   * @param deltaX the amount by which the rect should be moved horizontally
   * @param deltaY the amount by which the rect should be moved vertically
   */
  public void move(int deltaX, int deltaY){ // move the Shape
  	myX += deltaX;
  	myY += deltaY;
  }
  
  /**
   * Method thats returns the center of the ellipse
   * @return the center of the ellipse
   */
  public Point getCenter(){ // return the Shape's center
  	double centerX = (myX + (myWidth/2));
  	double centerY = (myY + (myHeight/2));
  	Point p = new Point (((int) centerX), ((int) centerY));
  	return p;
  }
  	
  }
