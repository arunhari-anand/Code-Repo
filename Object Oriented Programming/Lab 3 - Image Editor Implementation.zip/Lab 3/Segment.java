/* Author: Nitasha Kochar
 */

import java.awt.*;


/**
 * Segment.java
 * Class for a line segment.
 * 
 * Written by THC for CS 5 Lab Assignment 3.
 *
 * @author Thomas H. Cormen
 * @author Nitasha Kochar on Feb 1, 2016
 * @author Arun Hari Anand on Feb 1, 2016
 * @see Shape
 */
public class Segment extends Shape {
  private int myX1, myY1, myX2, myY2; // Segment endpoints
  private int myLeft, myRight, myTop, myBottom; 
  private final double MY_TOLERANCE = 3;
  
  /**
   * Constructor for Segment. Called to create a segment object with endpoints
   * (x1, y1) and (x2, y2), with color segmentColor.
   * 
   * @param x1 x coordinate of point 1
   * @param y1 y coordinate of point 1
   * @param x2 x coordinate of point 2
   * @param y2 y coordinate of point 2
   * @param segmentColor the color of the segment
   */
  public Segment(int x1, int y1, int x2, int y2, Color segmentColor) {
    super(segmentColor);
    myX1 = x1;
    myX2 = x2;
    myY1 = y1;
    myY2 = y2;
  }
  /**
   * Draws the segment using the drawLine method of the Graphics class
   */
  public void drawShape(Graphics page) {
    page.drawLine(myX1, myY1, myX2, myY2);
  }
  
  /**
   * method to change the second endpoint of the segment
   * @param p_final the new second endpoint
   */
  public void setFinalPoint(Point p_final){
  	myX2 = (int) p_final.getX();
  	myY2 = (int) p_final.getY();
  }

  /**
   * Move the Segment by deltaX in x and deltaY in y.
   * @param deltaX the change in the x values
   * @param deltaY the change in the y values
   */
  public void move(int deltaX, int deltaY) {
    myX1 += deltaX;
    myX2 += deltaX;
    myY1 += deltaY;
    myY2 += deltaY;
  }
  
  /**
   * Method to check if a given point is almost on the line
   * @param p the given point
   * @return true if the point p lies on the line or almost on it, false if not
   */
  public boolean containsPoint(Point p){ // does the Shape contain Point p?
  	if (myX2 < myX1) {
  		myLeft = myX2;
  		myRight = myX1;
  	}
  	else {
  		myLeft = myX1;
  		myRight = myX2;
  	}
  	if(myY1 < myY2) {
  		myTop = myY1;
  		myBottom = myY2;
  	}
  	else{
  			myTop = myY2;
  			myBottom = myY1;
  	}
  		return almostContainsPoint(p, myLeft, myTop, myRight, myBottom, MY_TOLERANCE) && MY_TOLERANCE >= distanceToPoint(p, myX1, myY1, myX2, myY2);
  }
  /**
   * Method to return the center of the line
   * @return the Point that represents the center of the line
   */
  public Point getCenter(){ // return the Shape's center
    	double centerX = (myX1 + myX2)/2;
    	double centerY = (myY1 + myY2)/2;
    	Point p = new Point (((int) centerX), ((int) centerY));
    	return p;
  }
	
	
	
  // Helper method that returns true if Point p is within a tolerance of a
  // given bounding box. Here, the bounding box is given by the coordinates of
  // its left, top, right, and bottom.
  private static boolean almostContainsPoint(Point p, int left, int top,
      int right, int bottom, double tolerance) {
    return p.x >= left - tolerance && p.y >= top - tolerance
        && p.x <= right + tolerance && p.y <= bottom + tolerance;
  }

  // Helper method that returns the distance from Point p to the line
  // containing a line segment whose endpoints are given.
  private static double distanceToPoint(Point p, int x1, int y1, int x2,
      int y2) {
    if (x1 == x2) // vertical segment?
      return (double) (Math.abs(p.x - x1)); // yes, use horizontal distance
    else if (y1 == y2) // horizontal segment?
      return (double) (Math.abs(p.y - y1)); // yes, use vertical distance
    else {
      // Here, we know that the segment is neither vertical nor
      // horizontal.
      // Compute m, the slope of the line containing the segment.
      double m = ((double) (y1 - y2)) / ((double) (x1 - x2));

      // Compute mperp, the slope of the line perpendicular to the
      // segment.
      double mperp = -1.0 / m;

      // Compute the (x, y) intersection of the line containing the
      // segment and the line that is perpendicular to the segment and that
      // contains Point p.
      double x = (((double) y1) - ((double) p.y) - (m * x1) + (mperp * p.x))
          / (mperp - m);
      double y = m * (x - x1) + y1;

      // Return the distance between Point p and (x, y).
      return Math.sqrt(Math.pow(p.x - x, 2) + Math.pow(p.y - y, 2));
    }
  }
}
