

import java.util.*;
import java.io.*;
import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import java.util.concurrent.atomic.AtomicReference;
import java.lang.reflect.InvocationTargetException;

/**
*Compressor.java
*A class that compresses a textfile using the huffman algorithm and makes a new file that contains the huffman code in bits
*@author Arun Hari Anand, February 16, 2016
*@author Nitasha Kochar, February 16, 2016
*/
public class Compressor {
	
	/**
	 *A method that compresses the target file into a file that contains the bit encoding based on the huffman
	 *algorithm.
	 *@param inputPathName the path name for the target file
	 *@param compressedPathName the path name for the compressed file
	 *@param codeList the HashMap that contains the encoding for each character in the textfile based on the 
	 *huffman algorithm
	 */
	public static void compress (String inputPathName, String compressedPathName, HashMap <Character, String> codeList) throws IOException{
		BufferedReader inputFile =  new BufferedReader(new FileReader(inputPathName));
		BufferedBitWriter bitOutputFile = new BufferedBitWriter(compressedPathName);
		try{
			int a = inputFile.read();
			if (a==-1){
				return;
			}
			while (a != -1){
				String code = codeList.get((char) a);
				for (int i = 0; i<code.length(); i++){
					bitOutputFile.writeBit(code.substring(i, i+1).equals("0")?0:1);
				}
				a = inputFile.read();

			}
		}	
		finally{
			inputFile.close();
			bitOutputFile.close();
		}
	}


	
	/**
   * Puts up a fileChooser and gets the path name for the file to be opened.
   * Returns an empty string if the user clicks "cancel".
   * @return path name of the file chosen 
   */

public static String getFilePath() {
	final AtomicReference<String> result = new AtomicReference<>();
	try {
		SwingUtilities.invokeAndWait(new Runnable() {
			public void run() {

				JFileChooser fc = new JFileChooser();
				int returnVal = fc.showOpenDialog(null);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();
					String pathName = file.getAbsolutePath();
					result.set(pathName);
				}
				else
					result.set("");
			}
		});
	} catch (InvocationTargetException | InterruptedException e) {
		e.printStackTrace();
	}
	return result.get();
}

/**
 *Main method for the compressor class. 
 *Opens two filechooser windows, the first one prompting for the file to be decompressed and the second prompting for the file  *that is to hold the original uncompressed text.
 * It then reconstructs the original file
 */
public static void main(String[] args) {
	try{
		String inputFile = getFilePath();
		String compressedFile = getFilePath();
		HashMap<Character, Integer> frq = HuffmanEncoder.frequencyTableGenerator(inputFile);
		System.out.println(frq.toString());
		BinaryTree<Character> codes = HuffmanEncoder.huffmanAlgorithm(frq);
		System.out.println(codes.toString());
		HashMap<Character, String> codeList = HuffmanEncoder.retrieveCodes(codes);
		System.out.println(codeList.toString());
		compress(inputFile, compressedFile, codeList);
	}
	catch (IOException ex){
		System.out.println("caught ioe\n" + ex.toString());
	}
}

}


