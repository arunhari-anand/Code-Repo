import java.util.*;
/**
*TreeComparator.java
 *Implements the Comparator interface
 *Used to compare two BinaryTree<Character> objects based on the frequency of the characters in them.
 *@author Arun Hari Anand, February 16, 2016
 *@author Nitasha Kochar, February 16, 2016
 */
public class TreeComparator<E> implements Comparator<E>{
	
 private HashMap<Character, Integer> frequencyTable;

/**
 *Constructor for the TreeComprator class
 *Initializes the frequencyTable instance variable
 *@param frequencyTable the frequencyTable that is used to compare two BinaryTree<Character> objects
 */
 public TreeComparator (HashMap<Character, Integer> frequencyTable){
	 this.frequencyTable = frequencyTable;
 }
	/**
	 *A method that implements the compare method in the Comparator interface.
	 *@param t1, t2 the two trees to be compared
	 *@return -1 if t1<t2, 0 if t1=t2 and 1 if t1>t2
	 */
	public int compare (E t1, E t2){
		if (t1 instanceof BinaryTree<?> && t2 instanceof BinaryTree<?>){
		@SuppressWarnings("unchecked")
		int frqT1 = computeTotalFrequency((BinaryTree<Character>) t1, 0);
		@SuppressWarnings("unchecked")
		int frqT2 = computeTotalFrequency((BinaryTree<Character>) t2, 0);
		if (frqT1 - frqT2 < 0)
			return -1;
		if (frqT1 - frqT2 > 0)
			return 1;
		else
			return 0;
		}
		else return -2;
	}
	
	/**
	 *Method to recursively traverse the tree, adding up the individual frequencies of the characters
	 *@param t the BinaryTree whose character frequencies are to be added
	 *@param initialFrequency a method that keeps track of the “initial frequency” so far, repeatedly gets added to
	 *@return the sum of the character frequencies of all the characters in the tree
	 */
	public int computeTotalFrequency (BinaryTree<Character> t, int initialFrequency){
		if (t.isLeaf()){
			return initialFrequency + frequencyTable.get(((BinaryTree<?>) t).getValue());
		}
		else {
			return (t.hasLeft() ? computeTotalFrequency(t.getLeft(), initialFrequency) : 0)
					+ (t.hasRight() ? computeTotalFrequency(t.getRight(), initialFrequency) : 0)
					+ initialFrequency;
		}
	}
	
	
	
	
	}
	


