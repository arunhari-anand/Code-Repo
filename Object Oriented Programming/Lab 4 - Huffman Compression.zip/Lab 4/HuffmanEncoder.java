import java.io.*;
import java.util.*;

/**
 *HuffmanEncoder.java
 *@author Arun Hari Anand, February 16, 2016
 *@author Nitasha Kochar, February 16, 2016
 *A class that implements the huffman coding algorithm to generate the coding list for a text file
 */
public class HuffmanEncoder{
	
	/**
	 *A method to generate a hashmap that represents the frequency table for each character in a textfile
	 *@param pathname the pathname for the textfile to be compressed
	 *@return a hashmap that maps each character in the textfile to its frequency
	 */
	public static HashMap<Character, Integer> frequencyTableGenerator(String pathName) throws IOException{
		BufferedReader inputFile =  new BufferedReader(new FileReader(pathName));

		try{
			HashMap <Character, Integer> frequencyTable = new HashMap<Character, Integer>();
			int a = inputFile.read();
			if (a==-1){
				return null;
			}
			while (a != -1){
				Character nextChar = (char) a;
				if (frequencyTable.containsKey(nextChar)){
					int frq = frequencyTable.get(nextChar) + 1;
					frequencyTable.remove(nextChar);
					frequencyTable.put(nextChar, frq);
				}
				else
					frequencyTable.put(nextChar, 1);
				a = inputFile.read();
			}
			return frequencyTable;
		}

		finally{
			inputFile.close();
		}
	}
	
	/**
	 *A method to generate a binary tree that holds character values as dictated by the Huffman algorithm
	 *@param frq the frequency table for the textfile
	 *@return a Binary Tree of characters where each character’s position is dictated by the Huffman Algorithm
	 */
public static BinaryTree<Character> huffmanAlgorithm(HashMap<Character, Integer> frq){
	  if (frq==null){
	  	return null;
	  }
		TreeComparator<BinaryTree<Character>> trc = new TreeComparator<BinaryTree<Character>>(frq);
		PriorityQueue<BinaryTree<Character>> singleTreeHelper = makeSingletonTrees(frq, trc);
		return makeSingleTree(singleTreeHelper);
	}
	
	/**
	 *A method to make a priority queue filled with singleton trees where each tree holds a single character from the
*textfile
*@param frq the frequency table for the characters in the textfile
*@param trc an instance of a TreeComparator object
*@return A priority queue of singleton trees which compares trees based on the TreeComparator class
*/
	private static PriorityQueue<BinaryTree<Character>> makeSingletonTrees(HashMap<Character, Integer> frq, TreeComparator<BinaryTree<Character>> trc){
		@SuppressWarnings("unchecked")
		PriorityQueue<BinaryTree<Character>> ret = new PriorityQueue<BinaryTree<Character>>(1, (Comparator<BinaryTree<Character>>) trc);
		for (char c : frq.keySet()){
			BinaryTree<Character> newTree = new BinaryTree<Character>(c);
			ret.add(newTree);
		}
		return ret;
	}
	
	/**
	 *A method that takes a priority queue of singleton trees and makes a single tree by taking out two trees
	 *at a time from the priority queue and making a single tree out of them, until the size of the queue is 0
	 *@param q the PriorityQueue of singleton trees
	 *@return a BinaryTree constructed as per the Huffman Algorithm
	 */
	private static BinaryTree<Character> makeSingleTree (PriorityQueue<BinaryTree<Character>> q){
		if (q.size()==1){
			BinaryTree<Character> ret = new BinaryTree<Character>(null);
			ret.setLeft(new BinaryTree<Character>(q.remove().getValue()));
			return ret;
		}
		while (q.size( ) > 1){
			BinaryTree<Character> e1 = q.remove();
			BinaryTree<Character> e2 = q.remove(); 
			BinaryTree<Character> t = new BinaryTree<Character>(null);
			t.setLeft(e1);
			t.setRight(e2);
			q.add(t);
		}

		return q.remove();
		
	}
	
	/**
	 *A method to retrieve the codes contained within the BinaryTree previously contructed.
	 *It makes a single traversal of the tree and inputs all codes within a HashMap (wth key Character and the value
	 *being the code
	 *@param codes the BinaryTree of characters that has been arranged according to the Huffman algorithm
	 *@return Hashmap that maps each character in the file to its code
	 */
	public static HashMap<Character, String> retrieveCodes(BinaryTree<Character> codes){
		if (codes==null)
			return null;
		HashMap<Character, String> codeList = new HashMap<Character, String>();
		retrieveCodesHelper(codeList, "", codes);
		return codeList;
	}
	
	/**
	 *A helper method for the retrieveCodes method that recursively traverses the tree once in order to update the map
	 *of codes.
	 *@param pathSoFar the String that keeps track of the path traversed so far
	 *@param codeList the map of codes that must be updated
	 */
	private static void retrieveCodesHelper(HashMap<Character, String> codeList, String pathSoFar, BinaryTree<Character> codes){
		if (codes.isLeaf()){
			codeList.put(codes.getValue(), pathSoFar);
		}
		if (codes.hasLeft()){
			retrieveCodesHelper(codeList, pathSoFar + "0", codes.getLeft());
		}

		if (codes.hasRight()){
			retrieveCodesHelper(codeList, pathSoFar+"1", codes.getRight());
		}


	}
}


