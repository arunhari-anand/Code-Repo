
import java.util.*;
import java.io.*;
import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import java.util.concurrent.atomic.AtomicReference;
import java.lang.reflect.InvocationTargetException;

/**
 *Decompressor.java
 *A class to decompress a given textfile containing codes derived from the huffman algorithm
 *@author Nitasha Kochar, February 16, 2016
 *@author Arun Hari Anand, February 16, 2016
 */
public class Decompressor {

	/**
	 *A method that decompresses a file and creates a new file that contains the original, decompressed text.
	 *@param inputPathName the path name of the file that contains the compressed text
	 *@param decompressedPathName the path name of the file that is to contain the original, decompressed text
	 *@param code the Binary Tree of characters that was generated as per the huffman algorithm and used to encode 
	 * the original file
	 */
	public static void decompress (String inputPathName, String decompressedPathName, BinaryTree<Character> code) throws IOException{
		BufferedBitReader bitInputFile =  new BufferedBitReader(inputPathName);
		BufferedWriter outputFile = new BufferedWriter(new FileWriter(decompressedPathName));
		try{
			writeToFile(bitInputFile, outputFile, code);
		}	
		finally{
			bitInputFile.close();
			outputFile.close();
		}
	}
	
	/**
	 *A helper method for the decompress method that reads the code in the input file and reconstructs the original
	 *@param bitInputFile the BufferedBitReader that reads the code from the compressed file
	 *@param outputFile the BufferedWriter that writes the reconstructed text onto the new file
	 *@param code the Binary Tree of characters that was generated as per the huffman algorithm and used to encode 
	 * the original file
	 */
	private static void writeToFile(BufferedBitReader bitInputFile, BufferedWriter outputFile, BinaryTree<Character> code) throws IOException{
		int c = bitInputFile.readBit();
		Boolean newChar = true;
		BinaryTree<Character> node = new BinaryTree<Character>(null);
		if (c==-1){
			return;
		}
		while (c != -1){
			if (newChar){
				node = (c == 0? code.getLeft() : code.getRight());
				newChar = false;
			}
			else{
				node = (c == 0? node.getLeft() : node.getRight());
			}
			c = bitInputFile.readBit();
			if (node.isLeaf()){
				outputFile.write(node.getValue());
				newChar = true;
			}
		}
	}

	
	/**
   * Puts up a fileChooser and gets the path name for the file to be opened.
   * Returns an empty string if the user clicks "cancel".
   * @return path name of the file chosen 
   */

public static String getFilePath() {
	final AtomicReference<String> result = new AtomicReference<>();
	try {
		SwingUtilities.invokeAndWait(new Runnable() {
			public void run() {

				JFileChooser fc = new JFileChooser();
				int returnVal = fc.showOpenDialog(null);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();
					String pathName = file.getAbsolutePath();
					result.set(pathName);
				}
				else
					result.set("");
			}
		});
	} catch (InvocationTargetException | InterruptedException e) {
		e.printStackTrace();
	}
	return result.get();
}

/**
 *Main method for the decompressor class. 
 *Opens three filechooser windows, the first one prompting for the file to be compressed and the second prompting for the file that 
 *is to hold the compressed bits, and the third one prompting for the original file, so that a BinaryTree<Character> object can 
 *be constructed using the character frequencies in the original file
 *It then uses Huffman encoding to compress the file
 */
public static void main(String[] args) {
	try{
		String inputFile = getFilePath();
		String decompressedPathName = getFilePath();
		String originalPathName = getFilePath();
		HashMap<Character, Integer> frq = HuffmanEncoder.frequencyTableGenerator(originalPathName);
		BinaryTree<Character> codes = HuffmanEncoder.huffmanAlgorithm(frq);
		decompress(inputFile, decompressedPathName, codes);
	}
	catch (IOException ex){
		System.out.println("caught ioe\n" + ex.toString());
	}
}

}


