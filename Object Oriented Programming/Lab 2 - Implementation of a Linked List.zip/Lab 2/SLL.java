/**
 * SLL.java
 * 
 * Implementation of singly linked list, using a current_pred and dummy list head implementation.
 * WARNING: This implementation is guaranteed to work only if always given
 * immutable objects (or at least ones that do not change).
 * 
 * @author THC
 * @author Scot Drysdale converted to Java
 * @author Scot Drysdale, THC have made a number of modifications.
 * @author Scot Drysdale most recently modified on 1/12/2011
 * @author Prasad Jayanti changed the interface to CS10ListADT
 * @author Arun Hari Anand modified it to create a dummy list head and current_pred implementation
 * Testing of this new implementation has been done in three separate parts, shown in
 *three separate pictures.
 */
public class SLL<T> implements CS10LinkedList<T> {
  // Instance variables.
  private Element<T> current_pred
  ;    //position prior to current position in the list
       //refers to the head in case of an empty list
  private Element<T> head;       // head of list
  
  
  /**
   * A private class inner representing the elements in the list.
   */
  private static class Element<T> {
    // Because this is a private inner class, these can't be seen from outside SLL.
    private T data;         // reference to data stored in this element
    private Element<T> next;   // reference to next item in list
    
    /**
     * Constructor for a linked list element, given an object.
     * @param obj the data stored in the element.
     */
    public Element(T obj) {
      next = null;          // no element after this one, yet
      data = obj;           // OK to copy reference, since obj references an immutable object
    }

    /**
     * @return the String representation of a linked list element.
     */
    public String toString() {
       if (data!= null)
      	return data.toString();
       return "null";
      
    }
  }

  /**
   * Constructor to create an empty singly linked list.
   */
  public SLL() {
    clear();
  }

  /**
   * method to clear the list and revert it back to an empty list
   * sets head to a dummy list head and sets its next variable equal to null
   */
  public void clear() {
    // No elements are in the list except for the head.
  	head = new Element<T>(null);
  	current_pred = head;
  	head.next = null;
   }

  /**
   * method to add an element after the current position in the list
   * adds element right after the current element, or two elements after the current_pred reference
   * @param obj the data that is to be stored in the newly added element  
   */
  public void add(T obj) {
    Element<T> x = new Element<T>(obj);   // allocate a new element

    // There are two distinct cases, depending on whether the new element
    // is to be the new first element or not
    if (!isEmpty()) {
   // The new element is not the new head.
      x.next = current_pred.next.next;  // fix the next reference for the new element
      current_pred.next.next = x;       // fix the next reference for current element
      current_pred = current_pred.next; // new element is current position 
    }
    else{ 
    head.next =x;
    }
    
    
   
  }

  /**
   * method to remove the current element
   * removes the element right after the current_pred reference
   */
  public void remove() {
   
    if (!hasCurrent()) {          // check whether current element exists
      System.err.println("No current item");
      return;
    }
    
    if (!hasNext())  {
      current_pred.next = null;       
      for (Element<T> x=head; x.next!= null; x = x.next){
      	current_pred = x;
      }
    }
    else {
    	current_pred.next = current_pred.next.next; 
    	
    }
  
    
  }

  /**
   * returns the String representation of the data stored in each reference
   * @return a string that represents a list of all the string representations of all the elements in the list
   */
  public String toString() {
    String result = "";
    if (hasCurrent()){
    for (Element<T> x = head; x != null; x = x.next) 
      result += x.toString() + "\n"; 
    
    return result;
    }
    return "null";
  }

  /**
   * checks to see if the list contains the equivalent of a particular instance of an object
   * @param obj the object that the method checks to see if the list contains
   * @return true if the list contains the element, false if it does not
   */
  public boolean contains(T obj) {
    Element<T> x;
  
    for (x = head; x.next != null && !x.next.data.equals(obj); x = x.next);
  
    // We dropped out of the loop either because we ran off the end of the list
    // (in which case x == null) or because we found s (and so x != null).
    if (x.next != null)  
    current_pred = x;
  
    return (x.next != null);
  }

  /**
   * method to check if the list is empty, checks to see if the dummy list head's next reference is another element or null
   * @return returns true if the list is empty, false if not
   */
  public boolean isEmpty() {
    return head.next == null;
  }
  
  /**
   * method to check if the list has a current element
   * returns true if the reference after current_pred is another element and not null.
   */
  public boolean hasCurrent() {
    return current_pred != null && current_pred.next != null;
  }
  
  /**
   * @see mehtod to check if there is another element after the current one.
   * @return true if there is another element two references after current_pred, false if not
   */
  public boolean hasNext() {
    return hasCurrent() && current_pred.next.next != null;
  }
  
  /**
   * method to return the data stored in the element in the list that follows the dummy list head
   * @return the data stored in the first element of the list
   */
  public T getFirst() { 
    if(isEmpty()) {
      System.err.println("The list is empty");
      return null;
    }
    current_pred = head;
    return get();
  }
  
  /**
   *method to return the last element in the list
   *@return the last element in the list that is not null
   */
  public T getLast() {
    if (isEmpty()) {
      System.err.println("The list is empty");
      return null;
    }
    else {
    	for (Element<T> x = head; x.next!=null; x = x.next){
    	current_pred = x;
    	}
      return get();
    }
  }

  /**
   *adds an element containing the given object to the beginning of the list, and sets the current_pred reference to the 
   *dummy list head
   *@param obj the data that is to be stored in the first element of the list
   */
  public void addFirst(T obj) {
  	if (isEmpty()){
  		add(obj);
  		return;
  	}
  		
    Element<T> x = new Element<T>(obj);   // allocate a new element
    x.next= head.next;
    current_pred = head;
    head.next = x;
    
  }

  /**
   * adds an element to the end of the list and sets current_pred to the element right before the new last 
   * element in the list
   * @param obj the data to be stored in the new last element of the list
   */
  public void addLast(T obj) {
    if(isEmpty())
      addFirst(obj);
    else {
      getLast();
      add(obj);
    }
  }
  
  /**
   *returns the data contained within the current element of the list
   *@return the data stored in the element of the list that follows the current_pred reference
   */
  public T get() {
    if (hasCurrent()) {
      return current_pred.next.data;
    }
    else {
      System.err.println("No current item");
      return null;
    }

  }
  
  /**
   * method to set the data stored in the current element of the list to the given object
   * @param obj the new object to be stored in the data variable of the element of the list that follows
   * the current_pred reference
   */
  public void set(T obj) {
    if (hasCurrent())
    	current_pred.next.data = obj;
    else
      System.err.println("No current item");
  }
  
  /**
   *method to move the current_pred reference by one, such that the new current element is the reference in front of the
   *old current element.
   */
  public T next() {
    if (hasNext()) {
      current_pred = current_pred.next;
      return current_pred.next.data;
    }
    else {
      System.err.println("No next item");
      return null;
    }
  }
}